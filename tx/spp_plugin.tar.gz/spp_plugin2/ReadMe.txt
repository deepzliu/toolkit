该工程对spp3.0框架进一步进行封装，便于开发及使用

目前支持的数据包类型
1、视频jce包
2、中转包

目前支持的网络操作包括
1、redis
2、tmem
3、union
4、http
5、tssd
6、本地cache
7、第三方jce服务
8、字符串协议（mt_access_string）

封装后只需用户注册命令字及对应的函数，通过函数来实现所有业务逻辑。

为了方便开发，该框架还封装了单元测试和压力测试的工具

使用说明详见wiki：http://tapd.oa.com/hollywood/markdown_wikis/view/#1010114921005139355

服务示例：
工程需要包含mt_access.h头文件，makefile中指定该工程的include及lib
所有网络操作入口函数为mt_access()
详见实例程序http://tc-svn.tencent.com/isd/isd_liveportalvideo_rep/qqliveSvr_proj/trunk/tenvideo_base/datapp/all_projects/inter_comm/spp_plugin/spp_demo

测试工具示例：
小工具需要包含mt_access.h、func_factory.h，makefile中指定该工程的include及lib
生成两个可执行文件unit_test和pressure_test
注意：由于这里压测工具依赖spp3.0插件框架代码，要求运行该测试工具的机器上安装zkname类库
详见实例程序http://tc-svn.tencent.com/isd/isd_liveportalvideo_rep/qqliveSvr_proj/trunk/tenvideo_base/datapp/all_projects/inter_comm/spp_plugin/test_tool/test_demo


快速创建一个服务和测试工具：
到spp_plugin目录下，执行./create_svr.sh ${spp_dir} ${spp_name}