/*
 *  Created on: date
 *      Author: author
 */

#include "base_svr_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "local_logger.h"
#include "remote_logger.h"
#include "mt_config.h"

CREATE_MSG(base_svr_msg)

extern int g_max_anti_snow;

int work_init(const char * etc)
{
    /*
     *  local logger
     *  example config file: base.ini
     *  [LOG_CONFIG]  
     *  level=3  # level=3 show ELOG (leve=4 show DLOG) refer to spp_plugin/spp_demp/conf/readme.txt
     */

    CConfigFile cConfigFile(etc); 
    cConfigFile.GetConfValue<string>("CONFIG", "redisZkname", "sz.livePraise.redis.com");
     
    //雪崩值 默认为10000
    g_max_anti_snow = 10000;
    return 0;
}

int process_msg(spp_msg* curMsg, const string & curReq, string & curRsp)
{
    int ret = 0;

    _BEGIN_DO_WHILE_FLASE_;

    

    _END_DO_WHILE_FALSE_;

    return 0;
}

BaseFunctor myFunctor(0x01, &process_msg);

