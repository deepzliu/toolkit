/*
 *  Created on: date
 *      Author: author
 */

#ifndef _BASE_SVR_MSG_H_
#define _BASE_SVR_MSG_H_

#include "mt_spp_msg.h"


#ifndef _BEGIN_DO_WHILE_FLASE_
#define _BEGIN_DO_WHILE_FLASE_  do{
#define _END_DO_WHILE_FALSE_    }while(false);
#endif


class base_svr_msg : public spp_msg
{
public:
	base_svr_msg()
	{
		// FUNCTOR !!!
		
		this->SetMsgTimeout(300);
	}
};

#endif

