/*
 *  Created on: date
 *      Author: author
 */

#include "func_factory.h"
#include "mt_access.h"
#include <sstream>
#include <stdlib.h>

using namespace std;

//typedef taf::TC_AutoPtr<JceTcpDataModel<MysqlRequest,MysqlResponse> > TestPtr;

int testBaseSvr(int argc, char *argv[])
{
    int ret = 0;

    TaskList tasklist;

    //TestPtr testPtr = creater<TestPtr>()();

    //testPtr->setIP("10.133.33.49",12345);
    //testPtr->setTimeOut(1500);
    //testPtr->setCmd(0x01);
    //MysqlRequest &stReq = testPtr->mReq;
    //stReq.sql = "select * from table";
    //stReq.conf = "TEST_DB";

    //tasklist.push_back(mysqlPtr);
	
	ret = mt_access(tasklist);

    //testPtr->mRsp.display(std::cout);
    
    return ret;
}

REG_FUNC(testBaseSvr);



