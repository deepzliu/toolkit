#!/bin/bash



dst_dir=$1
svr_name=$2

spp_plugin_path=`pwd`
author=`whoami`
now=`date '+%Y-%m-%d'`


if [ ! -n "$dst_dir" ];then
	echo "error dest dir is empty";
	exit 0;
fi

if [ ! -n "$svr_name" ];then
	echo "error server name is empty";
	exit 0;
fi

echo -e "dest directory=\t"$dst_dir
echo -e "server name=\t"$svr_name

svr_dir=$dst_dir/$svr_name

if [ ! -d $svr_dir ];then
	echo "create directory["$svr_dir"];";
	mkdir $svr_dir;
fi

if [ ! -d $svr_dir ];then
	echo "directory["$svr_dir"] create failure!";
	exit 0;
fi

if [ ! -d $svr_dir/src ];then
	mkdir $svr_dir/src
fi

if [ ! -d "$svr_dir/test" ];then
	mkdir "$svr_dir/test"
fi

if [ ! -d $svr_dir/etc ];then
	mkdir $svr_dir/etc
fi

if [ ! -d $svr_dir/jce_protocol ];then
	mkdir $svr_dir/jce_protocol
fi

test_dir=$svr_dir/test/
svr_dir=$svr_dir/src

cp ./base_svr/Makefile $svr_dir
cp ./base_svr/base_svr_msg.h $svr_dir/$svr_name"_msg.h"
cp ./base_svr/base_svr.cpp $svr_dir/$svr_name".cpp"
cp ./base_svr/test/makefile $test_dir/
cp ./base_svr/test/test_base_svr.cpp $test_dir/"test_"$svr_name".cpp"

sed_path=$(echo "$spp_plugin_path" | sed 's/\//\\\//g')
BIG_SVR_NAME=$(echo $svr_name | tr '[a-z]' '[A-Z]')

sed "s/SPP_PLUGIN_PATH=..\//SPP_PLUGIN_PATH="${sed_path}"/g" -i $svr_dir/Makefile 
sed "s/base_svr/"${svr_name}"/g" -i $svr_dir/Makefile 

sed "s/base_svr_msg/"$svr_name"_msg/g" -i $svr_dir/$svr_name"_msg.h"
sed "s/_BASE_SVR_H/_"$BIG_SVR_NAME"_MSG_H_/g" -i $svr_dir/$svr_name"_msg.h"
sed "s/date/"${now}"/g" -i $svr_dir/$svr_name"_msg.h"
sed "s/author/"${author}"/g" -i $svr_dir/$svr_name"_msg.h"

sed "s/base_svr_msg/"$svr_name"_msg/g" -i $svr_dir/$svr_name".cpp"
sed "s/date/"${now}"/g" -i $svr_dir/$svr_name".cpp"
sed "s/author/"${author}"/g" -i $svr_dir/$svr_name".cpp"

sed "s/SPP_PLUGIN_PATH=..\/../SPP_PLUGIN_PATH="${sed_path}"/g" -i $test_dir/makefile 
sed "s/BaseSvr/"_$svr_name"/g" -i $test_dir/"test_"$svr_name".cpp"
sed "s/date/"${now}"/g" -i $test_dir/"test_"$svr_name".cpp"
sed "s/author/"${author}"/g" -i $test_dir/"test_"$svr_name".cpp"

make -C $svr_dir
make -B -C $test_dir/
