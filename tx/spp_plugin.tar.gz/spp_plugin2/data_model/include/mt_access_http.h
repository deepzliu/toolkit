#ifndef _MT_ACCESS_HTTP_H
#define _MT_ACCESS_HTTP_H

#include "mt_access_base.h"
#include "mt_http_tool.h"
#include "tc_http.h"

class HttpDataModel : public BaseDataModel
{
public:
	HttpDataModel():mConnectType(1)//default 1: short connect 2: long connect
	{}

	int access_http(const string &ip, uint32_t port, taf::TC_HttpRequest &mHttpReq, string &mContent, 
					int mConnectType, int mTimeOut, int mBufMaxLen);

	int access_http(string &httpZkName, taf::TC_HttpRequest &mHttpReq, string &mContent, 
						int mConnectType, int mTimeOut, int mBufMaxLen);

	int access_http(uint32_t m_modid, uint32_t m_cmdid, string &defaultIP, uint32_t defaultPort, taf::TC_HttpRequest &mHttpReq, string &mContent, 
						int mConnectType, int mTimeOut, int mBufMaxLen);
		
	int RealProcess()
	{
		switch(mConnInfo.mType)
		{
		case L5_TYPE:
			mResult = access_http(mConnInfo.mModid, mConnInfo.mCmdid, mConnInfo.mIP, mConnInfo.mPort, mHttpReq, mContent, mConnectType, mTimeOut, mBufMaxLen);
			break;
		case ZKNAME_TYPE:
			mResult = access_http(mConnInfo.mZkname, mHttpReq, mContent, mConnectType, mTimeOut, mBufMaxLen);
			break;
		case IP_PORT_TYPE:
			mResult = access_http(mConnInfo.mIP, mConnInfo.mPort, mHttpReq, mContent, mConnectType, mTimeOut, mBufMaxLen);
			break;
		default:
			SF_ELOG("need connect type!");
			break;
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_HTTP_MODEL_TYPE";
	};

	void setConnectType(int connectType)//1: short connect 2: long connect
	{
		mConnectType = connectType;
	}

	string &getResData()
	{
		return mContent;
	}

	taf::TC_HttpRequest mHttpReq;
	string mContent;
	
	//tcp connect type
	int mConnectType;
};
typedef taf::TC_AutoPtr<HttpDataModel> HttpDMPtr;



#endif
