#ifndef _MT_ACCESS_HTTPS_H
#define _MT_ACCESS_HTTPS_H

#include "mt_access_base.h"
#include "mt_https_client.h"
#include "tc_http.h"

class HttpsDataModel : public BaseDataModel
{
public:
	HttpsDataModel()
	{}
	
	/*
		注意：mTimeOut字段未生效
	*/
	int access_https(const string &ip, uint32_t port, taf::TC_HttpRequest &mHttpReq, string &mContent, 
					int mTimeOut, int mBufMaxLen);

	int access_https(string &httpZkName, taf::TC_HttpRequest &mHttpReq, string &mContent, 
						int mTimeOut, int mBufMaxLen);

	int access_https(uint32_t m_modid, uint32_t m_cmdid, taf::TC_HttpRequest &mHttpReq, string &mContent, 
						int mTimeOut, int mBufMaxLen);
		
	int RealProcess()
	{
		switch(mConnInfo.mType)
		{
		case L5_TYPE:
			mResult = access_https(mConnInfo.mModid, mConnInfo.mCmdid, mHttpReq, mContent, mTimeOut, mBufMaxLen);
			break;
		case ZKNAME_TYPE:
			mResult = access_https(mConnInfo.mZkname, mHttpReq, mContent, mTimeOut, mBufMaxLen);
			break;
		case IP_PORT_TYPE:
			mResult = access_https(mConnInfo.mIP, mConnInfo.mPort, mHttpReq, mContent, mTimeOut, mBufMaxLen);
			break;
		default:
			SF_ELOG("need connect type!");
			break;
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_HTTPS_MODEL_TYPE";
	};

	string &getResData()
	{
		return mContent;
	}

	taf::TC_HttpRequest mHttpReq;
	string mContent;
};
typedef taf::TC_AutoPtr<HttpsDataModel> HttpsDMPtr;



#endif
