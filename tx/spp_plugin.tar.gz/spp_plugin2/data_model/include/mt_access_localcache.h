#ifndef _MT_ACCESS_LOCALCACHE_H
#define _MT_ACCESS_LOCALCACHE_H
#include "mt_access_base.h"
#include "local_cache_jce.h"

using namespace LocalCache;

enum LOCAL_CACHE_TYPE
{
	LOCAL_CACHE_GET		=	1,
	LOCAL_CACHE_SET		=	2,
};


class LocalCacheDataModel : public BaseDataModel
{
public:
	LocalCacheDataModel(){}

	int access_localcache(taf::Char mOpType, vector<LocalCacheNode> &mNodeList, int mExpireTime, int mTimeOut, int mBufMaxLex);

	int RealProcess()
	{
		mResult = access_localcache(mOpType, mNodeList, mExpireTime, mTimeOut, mBufMaxLen);
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_LOCALCACHE_MODEL_TYPE";
	};

	void setNode(taf::Char opType, const LocalCache::LocalCacheNode node, int expireTime = 1000)
	{
		mOpType = opType;
		mNodeList.push_back(node);
		mExpireTime = expireTime;
	}

	void setNodeList(taf::Char opType, const vector<LocalCache::LocalCacheNode> &nodeList, int expireTime = 1000)
	{
		mOpType = opType;
		mNodeList.clear();
		mNodeList.assign(nodeList.begin(),nodeList.end());
		mExpireTime = expireTime;
	}

	taf::Char mOpType; //1,get,2,set
	vector<LocalCache::LocalCacheNode> mNodeList;
	int mExpireTime;
};
typedef taf::TC_AutoPtr<LocalCacheDataModel> LocalCacheDMPtr;


#endif
