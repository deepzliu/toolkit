#ifndef _MT_ACCESS_STRING_H_
#define _MT_ACCESS_STRING_H_

#include "mt_access_base.h"

class StringDataModel : public BaseDataModel
{
public:
	StringDataModel():mConnMode(0),mtComplete(NULL){}
	
	int access_string(const string &ip, uint32_t port, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen);
	
	int access_string(string &zkName, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen);
	
	int access_string(uint32_t m_modid, uint32_t m_cmdid, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		switch(mConnInfo.mType)
		{
		case L5_TYPE:
			mResult = access_string(mConnInfo.mModid, mConnInfo.mCmdid, mReq, mRsp, mTimeOut, mBufMaxLen);
			break;
		case ZKNAME_TYPE:
			mResult = access_string(mConnInfo.mZkname, mReq, mRsp, mTimeOut, mBufMaxLen);
			break;
		case IP_PORT_TYPE:
			mResult = access_string(mConnInfo.mIP, mConnInfo.mPort, mReq, mRsp, mTimeOut, mBufMaxLen);
			break;
		default:
			SF_ELOG("need connect type!");
			break;
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_STRING_MODEL_TYPE";
	};

	void setReq(const string& req)
	{
		mReq = req;
	}

	string &getResData()
	{
		return mRsp;
	}

	void setUdpMode()
	{
		mConnMode = 0;
	}

	void setTcpMode(MtFuncTcpMsgLen func)
	{
		mConnMode = 1;
		mtComplete = func;
	}
	
	string mReq;
	string mRsp;

	int mConnMode; //udp:0 tcp:1; default udp mode
	MtFuncTcpMsgLen mtComplete;	//tcp包完整性检查函数
	
};
typedef taf::TC_AutoPtr<StringDataModel> StringDMPtr;

#endif

