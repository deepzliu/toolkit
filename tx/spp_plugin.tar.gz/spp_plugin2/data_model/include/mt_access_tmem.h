#ifndef _MT_ACCESS_TMEM_H
#define _MT_ACCESS_TMEM_H
#include "mt_access_base.h"
#include "mt_tmem_protocol.h"



class TmemGetDataModel : public BaseDataModel
{
public:
	TmemGetDataModel(){}

	int access_get_tmem(uint32_t m_modid, uint32_t m_cmdid, uint32_t m_bid, vector<ssdasn::TKeyNode> &m_keyValueList, 
						int timeout, int buf_max_len, const string &passwd = "");

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_get_tmem(mConnInfo.mModid, mConnInfo.mCmdid, mBid, mKeyValueList, mTimeOut, mBufMaxLen, mPasswd);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_TMEM_GET_MODEL_TYPE";
	};

	void setBid(uint32_t bid)
	{
		mBid = bid;
	};

	void setPwd(const string& pwd)
	{
		mPasswd = pwd;
	}

	vector<ssdasn::TKeyNode> &getResData()
	{
		return mKeyValueList;
	}
	
	uint32_t mBid;
	string mPasswd;
	vector<ssdasn::TKeyNode> mKeyValueList;
};
typedef taf::TC_AutoPtr<TmemGetDataModel> TmemGetDMPtr;

class TmemSetDataModel : public BaseDataModel
{
public:
	TmemSetDataModel(){}
	
	int access_set_tmem(uint32_t m_modid, uint32_t m_cmdid, uint32_t m_bid, vector<ssdasn::TKeyNode> &m_keyValueList, 
						int timeout, int buf_max_len, const string& passwd = "");

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_set_tmem(mConnInfo.mModid, mConnInfo.mCmdid, mBid, mKeyValueList, mTimeOut, mBufMaxLen, mPasswd);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_TMEM_SET_MODEL_TYPE";
	};
	
	void setBid(uint32_t bid)
	{
		mBid = bid;
	};

	vector<ssdasn::TKeyNode> &getResData()
	{
		return mKeyValueList;
	}
	
	void setPwd(const string& pwd)
	{
		mPasswd = pwd;
	}
	
	uint32_t mBid;
	string mPasswd;
	vector<ssdasn::TKeyNode> mKeyValueList;
};
typedef taf::TC_AutoPtr<TmemSetDataModel> TmemSetDMPtr;

class TmemDelDataModel : public BaseDataModel
{
public:
	TmemDelDataModel(){}
	
	int access_del_tmem(uint32_t m_modid, uint32_t m_cmdid, uint32_t m_bid, vector<ssdasn::TKeyNode> &m_keyValueList, 
						int timeout, int buf_max_len, const string& passwd = "");

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_del_tmem(mConnInfo.mModid, mConnInfo.mCmdid, mBid, mKeyValueList, mTimeOut, mBufMaxLen, mPasswd);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_TMEM_DEL_MODEL_TYPE";
	};
	
	void setBid(uint32_t bid)
	{
		mBid = bid;
	};

	vector<ssdasn::TKeyNode> &getResData()
	{
		return mKeyValueList;
	}
	
	void setPwd(const string& pwd)
	{
		mPasswd = pwd;
	}
	
	uint32_t mBid;
	string mPasswd;
	vector<ssdasn::TKeyNode> mKeyValueList;
};
typedef taf::TC_AutoPtr<TmemDelDataModel> TmemDelDMPtr;


#endif
