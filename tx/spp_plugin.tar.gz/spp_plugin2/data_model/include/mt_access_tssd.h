#ifndef _MT_ACCESS_TSSD_H
#define _MT_ACCESS_TSSD_H
#include "mt_access_base.h"
#include "mt_tdb_handle_base.h"
#include "mt_kv_packager.h"

using namespace tdb::api;

class TssdGetDataModel : public BaseDataModel
{
public:
	TssdGetDataModel(){}

	int access_get_tssd(const string &ip, uint32_t port, uint32_t mBid, uint32_t mCid, vector<string> &mKeys, 
						map<string,RspRecord> &mRspRecord, int &mServerRet, int mTimeOut, int mBufMaxLen);
						
	int access_get_tssd(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, uint32_t mCid, vector<string> &mKeys, 
						map<string,RspRecord> &record_map, int &mServerRet, int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_get_tssd(mConnInfo.mModid, mConnInfo.mCmdid, mBid, mCid, mKeys, mRspRecord, mServerRet, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_get_tssd(mConnInfo.mIP, mConnInfo.mPort, mBid, mCid, mKeys, mRspRecord, mServerRet, mTimeOut, mBufMaxLen);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_TSSD_GET_MODEL_TYPE";
	};

	void setBidCid(uint32_t bid, uint32_t cid)
	{
		mBid = bid;
		mCid = cid;
	};

	int getServerRet()
	{
		return mServerRet;
	}

	map<string,RspRecord> &getResData()
	{
		return mRspRecord;
	}
	
	uint32_t mBid;
	uint32_t mCid;
	int mServerRet;
	vector<string> mKeys;
	map<string,RspRecord> mRspRecord;
};
typedef taf::TC_AutoPtr<TssdGetDataModel> TssdGetDMPtr;

class TssdSetDataModel : public BaseDataModel
{
public:
	TssdSetDataModel(){}
	
	int access_set_tssd(const string &ip, uint32_t port, uint32_t mBid, uint32_t mCid, const string &mKey, 
							string &mValue, int &mServerRet, int mTimeOut, int mBufMaxLen);
	
	int access_set_tssd(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, uint32_t mCid, const string &mKey, 
							string &mValue, int &mServerRet, int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_set_tssd(mConnInfo.mModid, mConnInfo.mCmdid, mBid, mCid, mKey, mValue, mServerRet, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_set_tssd(mConnInfo.mIP, mConnInfo.mPort, mBid, mCid, mKey, mValue, mServerRet, mTimeOut, mBufMaxLen);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_TSSD_SET_MODEL_TYPE";
	};
	
	void setBidCid(uint32_t bid, uint32_t cid)
	{
		mBid = bid;
		mCid = cid;
	};

	int getServerRet()
	{
		return mServerRet;
	}

	void setKeyValue(const string &key, const string &value)
	{
		mKey = key;
		mValue = value;
	}

	const string &getKey()
	{
		return mKey;
	}

	const string &getValue()
	{
		return mValue;
	}
	
	uint32_t mBid;
	uint32_t mCid;
	int mServerRet;
	string mKey;
	string mValue;
};
typedef taf::TC_AutoPtr<TssdSetDataModel> TssdSetDMPtr;



#endif
