#ifndef _MT_ACCESS_UNION_H
#define _MT_ACCESS_UNION_H
#include "mt_access_base.h"
#include "unionapi.h"

class UnionDataModel : public BaseDataModel
{
public:
	UnionDataModel():mPlatform(0){}

	int access_union(const string &ip, uint32_t port, const string &mAppID, const string &mAppKey, uint32_t mSrcType, const vector<string>& mIDs, const vector<string> &mFields, 
                    tv::DSGetRsp &mRsp, int mTimeOut, int mBufMaxLen);
	
	int access_union(uint32_t mModid, uint32_t mCmdid, const string &mAppID, const string &mAppKey, uint32_t mSrcType, const vector<string>& mIDs, const vector<string> &mFields, 
                    tv::DSGetRsp &stRsp, int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_union(mConnInfo.mModid, mConnInfo.mCmdid, mAppID, mAppKey, mSrcType, mIDs, mFields, mRsp, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_union(mConnInfo.mIP, mConnInfo.mPort, mAppID, mAppKey, mSrcType, mIDs, mFields, mRsp, mTimeOut, mBufMaxLen);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_UNION_MODEL_TYPE";
	};

	void setType(const string& appID, const string &appKey, uint32_t srcType)
	{
		mAppID = appID;
		mAppKey = appKey;
		mSrcType = srcType;
	}

	void setIDs(vector<string> &ids)
	{
		mIDs = ids;
	}

	void setFields(vector<string> &fields)
	{
		mFields = fields;
	}

	void setPlatform(int platform, const string& appver)
	{
		mPlatform = platform;
		mAppver = appver;
	}

	tv::DSGetRsp &getResData()
	{
		return mRsp;
	}
	
	string mAppID;
	string mAppKey;
	uint32_t mSrcType;
	vector<string> mIDs;
	vector<string> mFields; 
	int mPlatform;
	string mAppver;
    tv::DSGetRsp mRsp;
};
typedef taf::TC_AutoPtr<UnionDataModel> UnionDMPtr;


#endif
