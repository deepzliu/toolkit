/*
 *  Created on: 2016-04-05
 *      Author: allenhuai
 */
#ifndef _MT_HIPPO_PRODUCER_H
#define _MT_HIPPO_PRODUCER_H
#include "mt_access_base.h"
//#include "UserMessage.h"
//#include "HippoClient.h"
#include "hippo_producer_agent.h"

class HippoProducerDataModel : public BaseDataModel
{
public:
	HippoProducerDataModel(){}
	
	int sendData2Agent(const string &ip, uint32_t port, HippoProducer::st_produceragent_req &stProducerReq, HippoProducer::st_produceragent_rsp &stProducerRsp, int mTimeOut, int mBufMaxLen);
	int sendData2Agent(uint32_t mModid, uint32_t mCmdid, HippoProducer::st_produceragent_req &stProducerReq, HippoProducer::st_produceragent_rsp &stProducerRsp, int mTimeOut, int mBufMaxLen);
	int RealProcess()
	{		
//		mResult = sendData2Agent(stProducerReq, stProducerRsp, mTimeOut, mBufMaxLen, strIP, uiPort);		

		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = sendData2Agent(mConnInfo.mModid, mConnInfo.mCmdid, stProducerReq, stProducerRsp, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = sendData2Agent(mConnInfo.mIP, mConnInfo.mPort, stProducerReq, stProducerRsp, mTimeOut, mBufMaxLen);
		}
		return mResult;
	}

	string GetModelType() const
	{
		return "HIPPO_PRODUCER_MODEL_TYPE";
	}

	void setSeqKey(const string &strSeqKey)
	{
		stProducerReq.strSeqKey = strSeqKey;
	}

	void setData(const string &strData)
	{
		stProducerReq.strData = strData;
	}

	void setExtData(const string &strExtData)
	{
		stProducerReq.strExtData = strExtData;
	}	

//	void setLocalIP(string &strLocalIP)
//	{
//		strIP = strLocalIP;
//	}
//
//	void setPort(uint32_t &uiPort)
//	{
//		uiPort = uiPort;
//	}

	void setTopic(const string &strTopic)
	{
		stProducerReq.strTopic = strTopic;
	}

	HippoProducer::st_produceragent_rsp getRsp()const
	{
		return stProducerRsp;
	}

	HippoProducer::st_produceragent_req getReq()const
	{
		return stProducerReq;
	}

private:
	HippoProducer::st_produceragent_req stProducerReq; //hippo producer agent req
	HippoProducer::st_produceragent_rsp stProducerRsp; //hippo producer agent rsp
//	string strIP;
//	uint32_t uiPort;
};
	
typedef taf::TC_AutoPtr<HippoProducerDataModel> HippoProducerDMPtr;


#endif
