/*
 * http_tool.h
 *
 *  Created on: 2015-05-18
 *      Author: carinwang   carinwang@tencent.com
 *  Copyright(c) 2015 Tencent. All rights reserved.
 *
 */

#ifndef __HTTP__TOOL__
#define __HTTP__TOOL__
#include <string>
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <stdint.h>
#include <cassert>
#include <zlib.h>

using namespace std;


//构造http请求相关
enum HttpType
{
	HTTP_GET_TYPE = 0,
	HTTP_POST_TYPE = 1
};

void ConstructHttp(const string &str_param,const string &str_api,const string &str_host
					,HttpType http_type,string &str_http_req,string str_cookie = string(""),string str_refer = string(""));
int CheckHttpPacket(const char *buf,int len);
int DecodeHttpPkt(const char* buf,int len,string &strHttpPkg,int &iHttpLen);
int CheckHttpTrunkPacket(char *buf, int len);
int DecodeHttpTrunkPkt(const char* buf,int len,string &strHttpPkg,int &iHttpLen);//chunk的解包是不通用的，各个业务上不同的

//url 编解码相关
string UrlEncode(const string& str);
string UrlDecode(const string& str);
unsigned char ToHex(unsigned char x);
unsigned char FromHex(unsigned char x);

//http gzip解压
int httpgzdecompress(Byte *zdata, uLong nzdata, Byte *data, uLong *ndata);

//图片url的缩放
/*
 * input:
 * strSize:待缩放的尺寸eg:_120x120,_big
 * strInitUrl:原始url
 *
 * output:
 * strFinallyUrl:最终替换的url
 *
 *
 */
int ChangePicUrl(const string &strSize,const string &strInitUrl,string &strFinallyUrl);

#endif


