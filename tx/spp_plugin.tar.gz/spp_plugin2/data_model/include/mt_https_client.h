/*-------------------------------------------------------------------------
 *    File Name : https_client.h
 *    Desc      :
 *    Author    : jackshi,dylanzheng
 *    Date      : 2016-6-23 
 *    History   :
 *                1)
 *-------------------------------------------------------------------------*/

#ifndef HTTPS_CLIENT_H__
#define HTTPS_CLIENT_H__

#include <inttypes.h>
#include <string>

#include "openssl/bio.h"
#include "openssl/ssl.h"

// 请不要使用全局变量，基本用法
// HttpsClient hc;
// hc.Init(myip);
// hc.SendAndRecv(...);

namespace spp
{
namespace http
{

class HttpsClient
{
public:
    HttpsClient();

    ~HttpsClient();

    // 初始化 https 连接
    // 返回值：成功返回 0；失败返回 -1
    int Init(const std::string& ip, uint16_t port = 443);

    // 发送 https 请求，接收 https 响应；https 包体内容存储在 recvbuf 中。
    // 在接收的时候需要检测 http 的完整性，在这个函数中接收缓存，当 http 完整时
    // 才会返回结果；如果出现异常，会返回错误，这时用户需要立即销毁对象！
    // 返回值：成功返回 0；失败返回 -1
    int SendAndRecv(const char *sendbuf, size_t sendlen, char *recvbuf, size_t *recvlen, int max_recvlen);

    // 销毁连接
    void Close();

	std::string getErrLog()
	{
		return strerr_;
	}

private:
    // 创建 socket，设置了 TCP 的保活特性
    // 返回值：成功返回 0；失败返回 -1
    int CreateSocket();

    // 内部的 SendAndRecv
    // 返回值：成功返回 0；失败返回 -1
    int SslSendAndRecv(const char *sendbuf, size_t sendlen, char *recvbuf, size_t *recvlen, int max_recvlen);

    void ClearLog()
    {
        strlog_.clear();
        strerr_.clear();
    }

private:
    int fd_;
    static SSL_CTX *ctx_;
    BIO *bio_;
    SSL *ssl_;

    std::string strlog_;
    std::string strerr_;

    int max_recvlen;
	static const int bio_connect_timeout = 800;
};

}
}

#endif
