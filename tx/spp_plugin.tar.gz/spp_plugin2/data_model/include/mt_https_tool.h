/*-------------------------------------------------------------------------
 *    File Name : http_tool.h
 *    Desc      :
 *    Author    : dylanzheng
 *    Date      : 2015-11-19 11:14:22
 *    History   :
 *                1)
 *-------------------------------------------------------------------------*/

#ifndef HTTPS_TOOL__
#define HTTPS_TOOL__

#include <string>
#include <sstream>
#include <inttypes.h>

using namespace std;

namespace spp
{
namespace http
{
inline string u2s(uint16_t uint)
{
	ostringstream ostr;
	ostr << uint;
	return ostr.str();
}

inline string u2s(uint32_t uint)
{
	ostringstream ostr;
	ostr << uint;
	return ostr.str();
}

inline string i2s(int iNum)
{
	ostringstream ostr;
	ostr << iNum;
	return ostr.str();
}

class HttpParser {
public:
    enum HttpParseCode
    {
        HPC_OK = 0,
        HPC_NOT_HTTP = -1,
        HPC_NOT_COMPLETE_HTTP = -2,
        HPC_UNKNOWN,
    };

    HttpParser ()
    {
    }

    virtual ~HttpParser ()
    {

    }

    // 解析 http 请求
    // 成功返回 0；失败返回 -1
    //virtual int ParseHttpRequest(const std::string &httpbuf, HttpRequest *http_request) = 0;

    // 解析 http 响应
    // 成功返回 0；失败返回 -1
    //virtual int ParseHttpResponse(const std::string &httpbuf, HttpResponse *http_response) = 0;

    virtual int CheckHttp(const std::string &httpbuf) = 0;
    virtual int CheckHttp(const void *httpbuf, size_t size) = 0;

private:
    HttpParser(const HttpParser &);
    void operator = (const HttpParser &);
};

class HttpParserImpl : public HttpParser {
public:
    HttpParserImpl () {}
    virtual ~HttpParserImpl () {}

    // 解析 http 请求
    // 成功返回 0；失败返回 -1
    //virtual int ParseHttpRequest(const std::string &httpbuf, HttpRequest *http_request);

    // 解析 http 响应
    // 成功返回 0；失败返回 -1
    //virtual int ParseHttpResponse(const std::string &httpbuf, HttpResponse *http_response);

    virtual int CheckHttp(const std::string &httpbuf);
    virtual int CheckHttp(const void *httpbuf, size_t size);
};

}
}

#endif
