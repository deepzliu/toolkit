
#ifndef _kv_packager_H_
#define _kv_packager_H_

#include <string>
#include <vector>

#include "mt_tdb_handle_base.h"

using namespace tdb::api;
using namespace std;

class StorageMessage;


enum RSP_TYPE
{
	EN_RSP_GET	 = 1, 
	EN_RSP_SET	 = 2, 
	EN_RSP_DEL	 = 3,
	EN_RSP_GETMUTL	 = 4
};

class KvPackager
{
public: 
    enum ERROR_CODE
    {
        E_ENCODE_DECODE         = -1001, /*编码错误*/
        E_PACKAGE_INTEGRALITY   = -1002, /*包不完整*/
        E_BUF                   = -1003  /*Buf不足*/
    };
	

    /*
        *   encode get request 
        *   @msg_seq[IN] 
        *     系列号，服务端会返回相同的系列号
        *   @bid [IN]    
        *      区分不同仓库
        *   @cid [IN]
        *      区分不同仓库，仅TDB需要,tmem,tssd不需要，传0即可。
        *   @key [IN]
        *      key
        *   @value[IN]
        *      value,在set接口才使用
        *   @buf [OUT]
        *      外部传进来的buf，存放编码后的数据
        *   @buf_size [IN/OUT]
        *      外部传进来时，标识buf的大小。函数返回时，修改为encode后数据大小
        */
    int encode_get_req(unsigned msg_seq, unsigned bid, unsigned cid, const string &key, 
        char *buf, int &buf_size);

    /*
        *   decode get response 
        *
        *   @buf [IN]
        *     服务端数据
        *   @buflen [INT]
        *     数据大小
        *   @msg_seq[OUT] 
        *     系列号，服务端请求时的系列号    
        *   @value [OUT]
        *      服务端返回的值。get接口才有        
        *   @svr_ret_code [OUT]
        *      服务端返回码，如果为0，其它值才有效。
        *   @buf [OUT]
        *      外部传进来的buf，存放编码后的数据
        */
    int decode_get_rsp(char* buf, int buflen, 
        unsigned& msg_seq, int &svr_ret_code, string &value);

    int encode_set_req(unsigned msg_seq, unsigned bid, unsigned cid, const string &key, string &value, 
        char *buf, int &buf_size);
    int decode_set_rsp(char* buf, int buflen, 
        unsigned& msg_seq, int &svr_ret_code);

    int encode_del_req(unsigned msg_seq, unsigned bid, unsigned cid, const string &key, 
        char *buf, int &buf_size);
    int decode_del_rsp(char* buf, int buflen,
        unsigned& msg_seq, int &svr_ret_code);        
	
	int encode_get_muti_req(unsigned msg_seq, unsigned bid, unsigned cid, vector<std::string>& key_vec, char *buf, int &buf_size);
   
	int decode_get_muti_rsp(char* buf, int buflen, 
	   unsigned& msg_seq, int &svr_ret_code, map<std::string,RspRecord>& record_map);

    /**
        * 从缓冲区中获取完整的数据包
        *
        * @buf: 检测是否有完整的数据包的起始地址
        * @buf_size: 已收到的数据的大小
        * @datalen: 检测到的完整的数据包的长度
        * @msg_seq:服务端返回的系列号
        * @rsp_type:返回包的类型[见RSP_TYPE ]
        * return:    
        *            =0 - if data_len = 0, 需要继续接收数据，包暂时不完整, 
        *                    if data_len > 0, 从buf开始的datalen个字节为一个完整的数据包 
        *            <0 - 有错发生. 
        **/
    int is_pkt_complete(char *buf, int buf_size, int &datalen, unsigned& msg_seq,int &rsp_type );


    /**
        *打印包，测试使用
        *
        * @buf: 包数据指针
        * @buflen:包大小
        */
    void print_package(char* buf, int buflen);

private:
    int decode_pkg(unsigned &msg_seq, char *buf, int buf_size, StorageMessage *rsp);
    int encode_pkg(StorageMessage &msg, char *buf, int &buf_size);

};

#endif //_kv_packager_H_

