#ifndef _MT_SEND_CSPACKET_H
#define _MT_SEND_CSPACKET_H
#include "mt_access_base.h"

class SendCsPacketDataModel : public BaseDataModel
{
public:
	SendCsPacketDataModel():mDestIP("127.0.0.1"),mDestPort(28810),mCommand(0xff), mCsCommand(0xf1){}

	int send_cspacket();

	int RealProcess()
	{
		mResult = send_cspacket();
		return mResult;
	};

	string GetModelType() const
	{
		return "SEND_CSPACKET_MODEL_TYPE";
	};

	void setSendBuf(int cmd, const string& strData)
	{
		mCmd = cmd;
		mHeader.BasicInfo.Command = cmd;
		mHeader.body = strData;
	}

	void setDestIP(const string &ip, uint32_t port)
	{
		mDestIP = ip;
		mDestPort = port;
	}

	string mDestIP;
	uint32_t mDestPort;
	int mCommand;		//setCommand(0xff);
	int mCsCommand;		//setCsCommand(0xf1);
	int mCmd;			//setCsSubCommand();
	videocomm::VideoCommHeader mHeader;

};
typedef taf::TC_AutoPtr<SendCsPacketDataModel> SendCsPacketDMPtr;


#endif
