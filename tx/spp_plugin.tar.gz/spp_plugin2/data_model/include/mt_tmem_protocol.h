#ifndef _MT_TMEM_PROTOCOL_H_
#define _MT_TMEM_PROTOCOL_H_

#include <map>
#include <stdio.h>
#include "buffer.h"
#include "common_define.h"
#include "coder_define.h"
#include <iostream>


int tmem_encode_list(int op,int bid,uint32_t seq,vector<ssdasn::TKeyNode> &node
                    ,const uint32_t & pass_id
                    ,string & ret_sbuffer);

int tmem_encode_list(int op,int bid,uint32_t seq ,vector<ssdasn::TKeyNode> &node
                    ,const uint32_t & pass_id
                    ,char * ret_sbuffer, int & buf_len);


int tmem_decode_list(int op ,const string & sbuffer,uint32_t &seq, vector<ssdasn::TKeyNode> &node);


int tmem_decode_list(int op ,const char * sbuffer,const uint32_t buf_len,uint32_t &seq, vector<ssdasn::TKeyNode> &node);


int tmem_encode(int op, int bid, uint32_t seq, ssdasn::TKeyNode &node, int &expire, 
                    const uint32_t & pass_id, string & ret_sbuffer);


int tmem_encode(int op, int bid, uint32_t seq, ssdasn::TKeyNode &node, int &expire, 
                    const uint32_t & pass_id,char * ret_sbuffer, int & buf_len);

int tmem_decode(int op, int bid, uint32_t &seq, const string & sbuffer, ssdasn::TKeyNode &node);


int tmem_decode(int op, int bid, uint32_t &seq, const char * sbuffer,const uint32_t buf_len, ssdasn::TKeyNode &node);


#endif


