#include "mt_access_http.h"

int httpComplete(void * buffer, int len)
{
	int rLen = CheckHttpPacket((const char*)buffer,len);
    if(rLen < 0)
    {
        rLen = CheckHttpTrunkPacket((char*)buffer,len);
    }
	if(len >= rLen)
		return rLen;
	return 0;
}

int HttpDataModel::access_http(const string &ip, uint32_t port, taf::TC_HttpRequest &mHttpReq, string &mContent, int mConnectType, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string strbuffer = mHttpReq.encode();

    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    
    int buf_size = mBufMaxLen;
    
    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip.c_str());
    dst.sin_port = htons(port);

    iRet = mt_tcpsendrcv_ex(&dst, (char*)strbuffer.c_str(), strbuffer.size(), (char*)rcv_buf, &buf_size, mTimeOut, httpComplete, NS_MICRO_THREAD::MT_TCP_CONN_TYPE(mConnectType));  
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to http error! iRet:%d\tip:%s\tport:%d", iRet, ip.c_str(), port); 
        return iRet;
    }

    taf::TC_HttpResponse httpRsp;
    bool bRet = httpRsp.decode((const char*)rcv_buf, buf_size);
    if(bRet == false)
    {
        SF_ELOG("http decode error! iRet:%d\tip:%s\tport:%d", iRet, ip.c_str(), port); 
        return DECODE_ERROR;
    }

    mContent = httpRsp.getContent();
    int httpRet = httpRsp.getStatus();
    if(httpRet != 200)
    {
        iRet = -httpRet;
    }
    return iRet;
}

int HttpDataModel::access_http(string &httpZkName, taf::TC_HttpRequest &mHttpReq, string &mContent, int mConnectType, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;
 
    iRet = getHostByZkName(httpZkName.c_str(), ip, port);
    if(iRet != 0)
    {
        SF_ELOG("get http host by zkname error! zkname:[%s] iRet:%d\tip:%s\tport:%d", httpZkName.c_str(), iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_http(ip, port, mHttpReq, mContent, mConnectType, mTimeOut, mBufMaxLen);

    return iRet;
}

int HttpDataModel::access_http(uint32_t m_modid, uint32_t m_cmdid, string &defaultIP, uint32_t defaultPort, taf::TC_HttpRequest &mHttpReq, string &mContent, int mConnectType, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(m_modid, m_cmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("http get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", m_modid, m_cmdid, iRet, ip.c_str(),port);
        if(defaultIP != "" && defaultPort != 0)
		{
			ip = defaultIP;
			port = defaultPort;
			SF_ELOG("GET HOST ERROR! use defaultIP:%s\tport:%d",iRet, ip.c_str(),port);
		}
		else
		{
        	return GET_HOST_ERROR;
		}
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_http(ip, port, mHttpReq, mContent, mConnectType, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}


