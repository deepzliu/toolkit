#include "mt_access_https.h"

int HttpsDataModel::access_https(const string &ip, uint32_t port, taf::TC_HttpRequest &mHttpReq, string &mContent, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string strbuffer = mHttpReq.encode();

    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    
    size_t buf_size = mBufMaxLen;
    spp::http::HttpsClient httpsClient;
    
    httpsClient.Init(ip, port);

    iRet = httpsClient.SendAndRecv(strbuffer.c_str(), strbuffer.size(), rcv_buf, &buf_size, mBufMaxLen);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to https error! iRet:%d\tip:%s\tport:%d,err:%s", iRet, ip.c_str(), port, httpsClient.getErrLog().c_str()); 
        return iRet;
    }
    httpsClient.Close();
    taf::TC_HttpResponse httpRsp;
    bool bRet = httpRsp.decode((const char*)rcv_buf, buf_size);
    if(bRet == false)
    {
        SF_ELOG("http decode error! iRet:%d\tip:%s\tport:%d", iRet, ip.c_str(), port); 
        return DECODE_ERROR;
    }

    mContent = httpRsp.getContent();
    int httpRet = httpRsp.getStatus();
    if(httpRet != 200)
    {
        iRet = -httpRet;
    }
    return iRet;
}

int HttpsDataModel::access_https(string &httpZkName, taf::TC_HttpRequest &mHttpReq, string &mContent, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;
 
    iRet = getHostByZkName(httpZkName.c_str(), ip, port);
    if(iRet != 0)
    {
        SF_ELOG("get http host by zkname error! zkname:[%s] iRet:%d\tip:%s\tport:%d", httpZkName.c_str(), iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_https(ip, port, mHttpReq, mContent, mTimeOut, mBufMaxLen);

    return iRet;
}

int HttpsDataModel::access_https(uint32_t m_modid, uint32_t m_cmdid, taf::TC_HttpRequest &mHttpReq, string &mContent, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(m_modid, m_cmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("http get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", m_modid, m_cmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_https(ip, port, mHttpReq, mContent, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}


