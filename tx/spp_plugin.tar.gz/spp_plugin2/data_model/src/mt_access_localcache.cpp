#include "mt_access_localcache.h"

using namespace NS_MICRO_THREAD;
    
static int localCacheComplete(void * buffer, int len)
{
    if(len < 4)
        return 0;
    uint32_t packLen = ntohl(*((uint32_t *)(buffer)));
    if(static_cast<int>(packLen) <= len)
        return packLen ;
    else
        return 0;
}

int LocalCacheDataModel::access_localcache(taf::Char mOpType, vector<LocalCacheNode> &mNodeList, int mExpireTime, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip = "127.0.0.1";
    uint32_t port = 8500;

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip.c_str());
    dst.sin_port = htons(port);

    string strbuffer;

    ShmContextNodeList jceNodeList;
    jceNodeList.opType = mOpType;
    jceNodeList.nodeList.assign(mNodeList.begin(), mNodeList.end());
    jceNodeList.ExpiredTime = mExpireTime;
    jceNodeList.seq = 0;
    jceNodeList.ret = 0;
    
    taf::JceOutputStream<taf::BufferWriter> osJceNodeList; 
    jceNodeList.writeTo(osJceNodeList);

    LocalCacheJceHead jceHead;
    jceHead.BodyType = BODY_TYPE_SOCKET_DATA_LIST;
    jceHead.StrBody.assign(osJceNodeList.getBuffer(), osJceNodeList.getLength());;

    taf::JceOutputStream<taf::BufferWriter> osJceHead; 
    jceHead.writeTo(osJceHead);

    uint32_t packetLen = htonl(sizeof(uint32_t) + osJceHead.getLength());
    strbuffer.assign((char *)&packetLen, sizeof(uint32_t));
    strbuffer.append(osJceHead.getBuffer(),osJceHead.getLength());

    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    int buf_size = mBufMaxLen;
    
    iRet = mt_tcpsendrcv(&dst, (char*)strbuffer.c_str(), strbuffer.size(), (char*)rcv_buf, buf_size, mTimeOut, localCacheComplete);    
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to local cache error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }

    taf::JceInputStream<taf::BufferReader> isJce_c;
    isJce_c.setBuffer(rcv_buf + 4, buf_size - 4);
    LocalCache::LocalCacheJceHead curRspHead;
    curRspHead.readFrom(isJce_c);

    taf::JceInputStream<taf::BufferReader> isJce_d;
    isJce_d.setBuffer(curRspHead.StrBody.c_str(), curRspHead.StrBody.size());
    LocalCache::ShmContextNodeList curRsp;
    curRsp.readFrom(isJce_d);

    mNodeList.clear();
    mNodeList.assign(curRsp.nodeList.begin(), curRsp.nodeList.end());

    iRet = curRsp.ret;
    return iRet;
}


