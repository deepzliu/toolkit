#include "mt_access_string.h"

int StringDataModel::access_string(const string &ip, uint32_t port, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
    
    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    
    int buf_size = mBufMaxLen;
    if(mConnMode == 0)
    {
        iRet = mt_access_udp(ip, port, (char*)mReq.c_str(), mReq.size(), (char*)rcv_buf, buf_size, mTimeOut);
    }
    else
    {
        if(mtComplete != NULL)
        {
            iRet = mt_access_tcp(ip, port, (char*)mReq.c_str(), mReq.size(), (char*)rcv_buf, buf_size, mtComplete, mTimeOut);
        }
        else
        {
            SF_ELOG("tcp mt_access_string error! packet complete functory is null!");
            return MT_COMPLETE_NULL;
        }
    }
  
    if(iRet < 0)
    {
        SF_ELOG("mt_access_string error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }
    
    mRsp.assign(rcv_buf, buf_size); 
    
    return iRet;
}

int StringDataModel::access_string(string &zkName, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;
 
    iRet = getHostByZkName(zkName.c_str(), ip, port);
    if(iRet != 0)
    {
        SF_ELOG("get host by zkname error! zkname:[%s] iRet:%d\tip:%s\tport:%d", zkName.c_str(), iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_string(ip, port, mReq, mRsp, mTimeOut, mBufMaxLen);

    return iRet;
}

int StringDataModel::access_string(uint32_t m_modid, uint32_t m_cmdid, string &mReq, string &mRsp, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(m_modid, m_cmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("union get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", m_modid, m_cmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_string(ip, port, mReq, mRsp, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}


