#include "mt_access_tmem.h"
#include "mt_route.h"

using namespace NS_MICRO_THREAD;

extern void HexStr2Bin(char *p, string&s);

static int tmemComplete(void * buffer, int len)
{
	int rLen = ssdasn::trmem_pkt_complete((char*)buffer,len);
	if(len >= rLen)
		return rLen;
	return 0;
}

int access_tmem(const string &ip, uint32_t port, uint32_t mBid, vector<ssdasn::TKeyNode> &mKeyValueList, int op, int mTimeOut, int mBufMaxLen, const string &passwd = "")
{
    if(mKeyValueList.size() == 0)
    {
        SF_ELOG("TMEM require size is zero");
        return REQ_SIZE_ZERO;
    }

    int iRet = 0;
    uint32_t seq = 0;
    
    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    int len = mBufMaxLen;

    int ipasswd = 0;
    std::string pwd;
    HexStr2Bin(const_cast<char*>(passwd.c_str()), pwd);
    memcpy((char*)&ipasswd, pwd.c_str(), 4);

    iRet = tmem_encode_list(op, mBid, seq, mKeyValueList, ipasswd, buf, len);
    if( iRet != 0)
    {
        SF_ELOG("tmem encode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return ENCODE_ERROR;
    }
    
    int buf_size = mBufMaxLen;
    iRet = mt_access_tcp(ip, port, (char*)buf, len, (char*)rcv_buf, buf_size, tmemComplete, mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to tmem error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }

    seq = 0;
    iRet = tmem_decode_list(op, rcv_buf, buf_size, seq, mKeyValueList);
    if(iRet < 0)
    {
        SF_ELOG("tmem decode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return DECODE_ERROR;
    }

    return iRet;

}

int TmemGetDataModel::access_get_tmem(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, vector<ssdasn::TKeyNode> &mKeyValueList, int mTimeOut, int mBufMaxLen, const string &passwd)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("tmem get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_tmem(ip, port, mBid, mKeyValueList, ssdasn::cache_op_getlist, mTimeOut, mBufMaxLen, passwd);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}

int TmemSetDataModel::access_set_tmem(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, vector<ssdasn::TKeyNode> &mKeyValueList, int mTimeOut, int mBufMaxLen, const string &passwd)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("tmem get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_tmem(ip, port, mBid, mKeyValueList, ssdasn::cache_op_setlist, mTimeOut, mBufMaxLen, passwd);
   if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}

int TmemDelDataModel::access_del_tmem(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, vector<ssdasn::TKeyNode> &mKeyValueList, int mTimeOut, int mBufMaxLen, const string &passwd)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("tmem get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_tmem(ip, port, mBid, mKeyValueList, ssdasn::cache_op_dellist, mTimeOut, mBufMaxLen, passwd);
   if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}

