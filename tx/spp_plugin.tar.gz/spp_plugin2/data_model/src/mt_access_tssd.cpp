#include "mt_access_tssd.h"
#include "mt_route.h"

using namespace NS_MICRO_THREAD;
using namespace tdb::api;

static int tssdComplete(void * buffer, int len)
{
    KvPackager kp;
    int dataLen = 0; 
    unsigned seq = 0;
    int rspType;
    int iRet;
    
    iRet = kp.is_pkt_complete((char*)buffer, len, dataLen, seq, rspType);
    if (iRet < 0)
    {
        return 0;
    }
    
    return dataLen;
}

int TssdGetDataModel::access_get_tssd(const string &ip, uint32_t port, uint32_t mBid, uint32_t mCid, vector<string> &mKeys, map<string,RspRecord> &mRspRecord, int &mServerRet, int mTimeOut, int mBufMaxLen)
{
    if(mKeys.size() == 0)
    {
        SF_ELOG("tssd get require size is zero");
        return REQ_SIZE_ZERO;
    }

    int iRet = 0;
    
    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    int len = mBufMaxLen;

    KvPackager kp;
    volatile static uint32_t dwReqSeq = 0;
    unsigned seq = dwReqSeq++;
    
    iRet = kp.encode_get_muti_req(seq, mBid, mCid, mKeys, buf, len);
    if (iRet)
    {
       SF_ELOG("tssd get encode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
       return ENCODE_ERROR;
    }
    
    int buf_size = mBufMaxLen;
    iRet = mt_access_tcp(ip, port, (char*)buf, len, (char*)rcv_buf, buf_size, tssdComplete, mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to tssd error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }
     
    //seq = 0;
    iRet = kp.decode_get_muti_rsp(rcv_buf, buf_size, seq, mServerRet, mRspRecord);
    if(iRet < 0)
    {
        SF_ELOG("tssd get decode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return DECODE_ERROR;
    }

    return iRet;

}

int TssdGetDataModel::access_get_tssd(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, uint32_t mCid, vector<string> &mKeys, map<string,RspRecord> &mRspRecord, int &mServerRet, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("tssd get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_get_tssd(ip, port, mBid, mCid, mKeys, mRspRecord, mServerRet, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}


int TssdSetDataModel::access_set_tssd(const string &ip, uint32_t port, uint32_t mBid, uint32_t mCid, const string &mKey, string &mValue, int &mServerRet, int mTimeOut, int mBufMaxLen)
{
    if(mKey.size() == 0)
    {
        SF_ELOG("tssd set require size is zero");
        return REQ_SIZE_ZERO;
    }

    int iRet = 0;
    
    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
    int len = mBufMaxLen;

    KvPackager kp;
    volatile static uint32_t dwReqSeq = 0;
    uint32_t seq = dwReqSeq++;
    
    iRet = kp.encode_set_req(seq, mBid, mCid, mKey, mValue, buf, len);
    if (iRet)
    {
        SF_ELOG("tssd set encode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return ENCODE_ERROR;
    }
       
    int buf_size = mBufMaxLen;
    iRet = mt_access_tcp(ip, port, (char*)buf, len, (char*)rcv_buf, buf_size, tssdComplete, mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to tssd error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }

    iRet = kp.decode_set_rsp(rcv_buf, buf_size, seq, mServerRet);
    if(iRet < 0)
    {
        SF_ELOG("tssd set decode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return DECODE_ERROR;
    }

    return iRet;
}


int TssdSetDataModel::access_set_tssd(uint32_t mModid, uint32_t mCmdid, uint32_t mBid, uint32_t mCid, const string &mKey, string &mValue, int &mServerRet, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("tssd get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_set_tssd(ip, port, mBid, mCid, mKey, mValue, mServerRet, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}



