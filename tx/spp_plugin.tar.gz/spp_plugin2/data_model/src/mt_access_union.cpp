#include "mt_access_union.h"

using namespace UnionApi;
using namespace NS_MICRO_THREAD;

static int unionComplete(void * buffer, int len)
{
	int rLen = UnionCoder::CheckRspPktComplete((const char*)buffer, len);
	if(len >= rLen)
		return rLen;
	return 0;
}

int UnionDataModel::access_union(const string &ip, uint32_t port, const string &mAppID, const string &mAppKey, uint32_t mSrcType, const vector<string>& mIDs, const vector<string> &mFields, 
                    tv::DSGetRsp &mRsp, int mTimeOut, int mBufMaxLen)
{
    if(mFields.size() == 0 || mIDs.size() == 0)
    {
        SF_ELOG("get union field size is zero");
        return REQ_SIZE_ZERO;
    }

    int iRet = 0;
    int seq = 0;
    
    UnionCoder coder;
    coder.SetAppInfo(mAppID, mAppKey);
    string strbuffer;
    
#ifdef UNION_V2
    iRet = coder.GetFieldsEncode(strbuffer, seq, mSrcType, mIDs, mFields, false, mPlatform, mAppver);
#else    
    iRet = coder.GetFieldsEncode(strbuffer, seq, mSrcType, mIDs, mFields);
#endif

    if(iRet != 0)
    {
        SF_ELOG("union encode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return ENCODE_ERROR;
    }

    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)

    int buf_size = mBufMaxLen;
    iRet = mt_access_tcp(ip, port, (char*)strbuffer.c_str(), strbuffer.size(), (char*)rcv_buf, buf_size, unionComplete, mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to union error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return iRet;
    }

    seq = 0;
    iRet = coder.GetFieldsDecode(rcv_buf, buf_size, mRsp, seq);

    if(iRet != 0)
    {
        SF_ELOG("union decode error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(), port);
        return DECODE_ERROR;
    }

    return iRet;

}

int UnionDataModel::access_union(uint32_t mModid, uint32_t mCmdid, const string &mAppID, const string &mAppKey, uint32_t mSrcType, const vector<string>& mIDs, const vector<string> &mFields, 
                    tv::DSGetRsp &stRsp, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
 
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("union get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_union(ip, port, mAppID, mAppKey, mSrcType, mIDs, mFields, stRsp, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }
    
    return iRet;
}


