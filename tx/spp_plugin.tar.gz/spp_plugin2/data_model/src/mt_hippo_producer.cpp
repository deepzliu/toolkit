/*
 *  Created on: 2016-04-05
 *      Author: allenhuai
 */
#include "mt_hippo_producer.h"
#include "time.h"
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <stdio.h>
#include <stdlib.h>
#include "tc_common.h"
#include "video_packet.h"

//check packet
static int hippoProducerComplete(void * buffer, int len)
{
    int rLen = CVideoPacket::checkPacket((const char*)buffer, len);
	if(len >= rLen)
		return rLen;
	return 0;
}

//get local ip
int getLocalip(string &strIP)
{
	int iRet = 0;

	struct ifreq ifr;
	char ip[32]={NULL};
	
	int iInetSoket = socket(AF_INET, SOCK_DGRAM, 0);
	if(iInetSoket < 0)
	{
		SF_ELOG("socket error!");
		return -1;
	}
	
	strncpy(ifr.ifr_name, "eth1", 5);  
	iRet = ioctl(iInetSoket, SIOCGIFADDR, &ifr);
	if(iRet < 0)
	{
		SF_ELOG("ioctl error! iRet=%d\n",iRet);
		return iRet;
	}
	
	strncpy(ip, inet_ntoa(((struct sockaddr_in *)&ifr.ifr_addr)->sin_addr), 32);  
	strIP = string(ip);

	if(strIP.empty())
	{
		SF_ELOG("strIP empty!");
		return -2;
	}

	close(iInetSoket);
	return iRet;
}

static long g_preTime = 0;
static int g_autoincrementID = 1;
//generate unique id
//unique id = micro second timestamps + ip + pid + autoincrement id
static void generateUinqueID(const string &strIP, string &strUniqueID)
{
	//micro timestamps
	struct timeval tv;    
   	gettimeofday(&tv,NULL);
	long lMicroTimestamps = tv.tv_sec * 1000 + tv.tv_usec / 1000;
    string strMicroTimestamps = taf::TC_Common::tostr<long>(lMicroTimestamps);

	//pid
	pid_t pid = getpid(); //These functions are always successful.
	string strPid = taf::TC_Common::tostr<int>(pid);

	//autoincrement id
	if(lMicroTimestamps - g_preTime > 0)
	{
		g_autoincrementID = 1;
	}
	else
	{
		++g_autoincrementID;
	}
	g_preTime = lMicroTimestamps;
	string strautoincrementID = taf::TC_Common::tostr<int>(g_autoincrementID);
	
	strUniqueID = strMicroTimestamps + "_" + strIP + "_"+ strPid + "_" + strautoincrementID;	
}

//HippoProducerDataModel
int HippoProducerDataModel::sendData2Agent(const string &m_ip, uint32_t m_port, HippoProducer::st_produceragent_req &stProducerReq, HippoProducer::st_produceragent_rsp &stProducerRsp, int mTimeOut, int mBufMaxLen)
{
    
    int iRet = 0;	
	
    struct sockaddr_in stDst;
    stDst.sin_family = AF_INET;
    stDst.sin_addr.s_addr = inet_addr(m_ip.c_str());
    stDst.sin_port = htons(m_port);

	//generate unique id
	generateUinqueID(m_ip, stProducerReq.strUniqueID);

	//generate randkey
	if(stProducerReq.strSeqKey.empty())
	{
		struct timeval tv;    
	   	gettimeofday(&tv,NULL);
		long lMicroTimestamps = tv.tv_sec * 1000 + tv.tv_usec / 1000;
		srand(lMicroTimestamps);
		stProducerReq.strSeqKey = taf::TC_Common::tostr<int>(rand());
	}

	//packet req
    string strbuffer;
	iRet = jcePack<>(stProducerReq, strbuffer);
	if(iRet < 0)
    {
		stProducerRsp.iRet = iRet;
		stProducerRsp.strMsg = "packet error!";
		return iRet;
    }

    char *buf = NULL;
	char *rcv_buf = NULL;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)
	int buf_size = mBufMaxLen;

	int buf_len = mBufMaxLen;
	videocomm::VideoCommHeader mHeader;
	mHeader.BasicInfo.Command = 0xef69;
	mHeader.body = strbuffer;
	iRet = packJceVideoComm(buf, buf_len, mHeader);
	if(iRet < 0)
    {
		stProducerRsp.iRet = iRet;
		stProducerRsp.strMsg = "packet error!";
		return iRet;
    }

	//send data
    iRet = mt_tcpsendrcv(&stDst, buf, buf_len, (char*)rcv_buf, buf_size, mTimeOut, hippoProducerComplete);    
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to local cache error! iRet:%d\tip:%s\tport:%d",iRet, m_ip.c_str(), m_port);
        return iRet;
    }

	//unpacket rsp
	iRet = unpackJceVideoComm(rcv_buf, buf_size, mHeader);
	if(iRet < 0)
    {
		stProducerRsp.iRet = iRet;
		stProducerRsp.strMsg = "unpacket error!";
		return iRet;
    }
	
	iRet = jceUnPack(mHeader.body, stProducerRsp);	
    iRet = stProducerRsp.iRet;	
	
    return iRet;
}

int HippoProducerDataModel::sendData2Agent(uint32_t mModid, uint32_t mCmdid, HippoProducer::st_produceragent_req &stProducerReq, HippoProducer::st_produceragent_rsp &stProducerRsp, int mTimeOut, int mBufMaxLen)
{
	int iRet = 0;
 
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;

    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    if(iRet != 0)
    {
        SF_ELOG("hippo get host error! L5:[%d:%d] iRet:%d\tip:%s\tport:%d", mModid, mCmdid, iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = sendData2Agent(ip, port, stProducerReq, stProducerRsp, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
        l_l5_factory.uploadResult(iRet);
    }
    
    return iRet;
}


