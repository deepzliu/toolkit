/*
 * http_tool.cpp
 *
 *  Created on: 2015-05-08
 *      Author: carinwang   carinwang@tencent.com
 *  Copyright(c) 2015 Tencent. All rights reserved.
 *
 */

#include "mt_http_tool.h"

void ConstructHttp(const string &str_param,const string &str_api,const string &str_host
					,HttpType http_type,string &str_http_req,string str_cookie,string str_refer)
{
	uint32_t param_len = str_param.size();
	char tmp[64]={'\0'};
	snprintf(tmp, sizeof(tmp), "%u", param_len);

	if(http_type == HTTP_POST_TYPE)
	{
		str_http_req.append("POST " + str_api + " HTTP/1.1\r\n");

		str_http_req.append("Host: " + str_host + "\r\n");
        if(!str_refer.empty()){str_http_req.append("Referer:" + str_refer + "\r\n");}
		str_http_req.append("Accpet: */*\r\n");
		str_http_req.append("Content-Type: application/x-www-form-urlencoded\r\n");
		if(!str_cookie.empty()){str_http_req.append("Cookie:" + str_cookie + "\r\n");}
		str_http_req.append("Content-Length: " + std::string(tmp) + "\r\n");
		str_http_req.append("\r\n");
		str_http_req.append(str_param);
	}
	else if(http_type == HTTP_GET_TYPE)
	{
		str_http_req.append("GET " + str_api + "?" + str_param + " HTTP/1.1\r\n");
		str_http_req.append("User-Agent: Wget/1.12 (linux-gnu) \r\n");
		str_http_req.append("Host: " + str_host + "\r\n");
        if(!str_refer.empty()){str_http_req.append("Referer:" + str_refer + "\r\n");}
		str_http_req.append("Accpet: */*\r\n");
		str_http_req.append("Connection: Keep-Alive\r\n");
		if(!str_cookie.empty()){str_http_req.append("Cookie:" + str_cookie + "\r\n");}
		str_http_req.append("\r\n");
	}
}

int CheckHttpPacket(const char *buf,int len)
{
	const char *pHead = NULL;
	const char *pBody = NULL;
	const char *pHeadTail = NULL;

    if((pHead = strstr(buf, "Transfer-Encoding: chunked")) != NULL)
	{
		return -1;
	}

	if((pHead = strstr(buf, "Content-Length: ")) == NULL)
	{
		return 0;
	}

	pHead += strlen("Content-Length: ");

	if((pBody = strstr(buf, "\r\n\r\n")) == NULL)
	{
		return 0;
	}

	if((pHeadTail = strstr(pHead, "\r\n")) == NULL)
	{
		return 0;
	}

	char acTmp[20] = {0};
	memcpy(acTmp, pHead, pHeadTail - pHead);

	int iLen = pBody + strlen("\r\n\r\n") - buf;
	iLen += atoi(acTmp);

	if(iLen > len)
		return 0;

	return iLen;

}

//检查http trunked模式响应包体的合法性
int CheckHttpTrunkPacket(char *buf, int len)
{
    char *pEnd = NULL;

    if(len < 5)
    {
        return -1;
    }
    pEnd = buf+len-5;
    if(!strncmp(pEnd,"0\r\n\r\n",5))
    {
        return len;
    }
    else
    {
        return 0;
    }

}

int DecodeHttpPkt(const char* buf,int len,string &strHttpPkg,int &iHttpLen)
{
	const char *pHead = NULL;
	const char *pBody = NULL;
	const char *pHeadTail = NULL;

	if((pHead = strstr(buf, "Content-Length: ")) == NULL)
		return -1;
	pHead += strlen("Content-Length: ");

	if((pBody = strstr(buf, "\r\n\r\n")) == NULL)
		return -2;
	if((pHeadTail = strstr(pHead, "\r\n")) == NULL)
		return -3;

	char acTmp[20] = {0};
	memcpy(acTmp, pHead, pHeadTail - pHead);
	iHttpLen = atoi(acTmp);

	pBody += strlen("\r\n\r\n");
	strHttpPkg.append(pBody,iHttpLen);

    //判断是http回包中否有gzip压缩
    if((pHead = strstr(buf, "Content-Encoding: ")) != NULL)
    {
        pHead += strlen("Content-Encoding: ");
        if((pHeadTail = strstr(pHead, "\r\n")) != NULL)
        {
            char acTmp[20] = {0};
            memcpy(acTmp, pHead, pHeadTail - pHead);
            if(string("gzip").compare(acTmp) == 0 )
            {
                uLong ulBodyLen = 2000000;
                char* LocalZipBuf = new char[ulBodyLen];//申请2M内存 用于存储gzip解压后的数据
                int iRet = httpgzdecompress(reinterpret_cast<unsigned char*>(const_cast<char*>(strHttpPkg.c_str()))
                            , static_cast<uLong>(iHttpLen)
                            , reinterpret_cast<unsigned char*>(LocalZipBuf)
                            , &ulBodyLen);
                if( 0 == iRet)
                {
                    strHttpPkg.assign(LocalZipBuf,ulBodyLen);
                    iHttpLen = ulBodyLen;
                }
                else
                {
                    strHttpPkg = "gzip error";
                    iHttpLen = strHttpPkg.length();
                }

                delete[] LocalZipBuf;//释放内存
            }
        }
    }

	return 0;
}

//chunk的解包是不通用的，各个业务上不同的;
int DecodeHttpTrunkPkt(const char* buf,int len,string &strHttpPkg,int &iHttpLen)
{
	string strHttpRsp= "";
	strHttpRsp.assign(buf, len);

	string strHttpPkgTemp="";

	string::size_type stPos = strHttpRsp.find_first_of('{');
	if(stPos == string::npos)
    {
        return -1;
    }
    string::size_type stEndPos;
    while(stPos < strHttpRsp.length())
    { //去掉包体中 "\r\n1500\r\n" 这样的字符
        stEndPos=strHttpRsp.find("\r\n",stPos);
        if(stEndPos == string::npos || strHttpRsp.length() <= stEndPos+2)
        {
            strHttpPkgTemp+=strHttpRsp.substr(stPos);
            break;
        }
        else
        {
            strHttpPkgTemp+=strHttpRsp.substr(stPos,stEndPos-stPos);
            stPos=strHttpRsp.find("\r\n",stEndPos+2);
            if(stPos != string::npos && stPos < strHttpRsp.length()-2)
            {
                stPos+=2;
            }
            else
            {
                break;
            }
        }
    }
	stEndPos = strHttpRsp.find_last_of('}');
	if(stEndPos == string::npos)
        return -1;

	iHttpLen = stEndPos+1;
    strHttpPkg = strHttpPkgTemp.substr(0,iHttpLen);

	return 0;
}

unsigned char ToHex(unsigned char x)
{
    return  x > 9 ? x + 55 : x + 48;
}

unsigned char FromHex(unsigned char x)
{
    unsigned char y;
    if (x >= 'A' && x <= 'Z') y = x - 'A' + 10;
    else if (x >= 'a' && x <= 'z') y = x - 'a' + 10;
    else if (x >= '0' && x <= '9') y = x - '0';
    else assert(0);
    return y;
}

string UrlEncode(const string& str)
{
    string strTemp = "";

    size_t length = str.length();
    for (size_t i = 0; i < length; i++)
    {
        if (isalnum((unsigned char)str[i]) ||
                (str[i] == '-') ||
                (str[i] == '_') ||
                (str[i] == '.') ||
                (str[i] == '~'))
            strTemp += str[i];
        else if (str[i] == ' ')
            strTemp += "+";
        else
        {
            strTemp += '%';
            strTemp += ToHex((unsigned char)str[i] >> 4);
            strTemp += ToHex((unsigned char)str[i] % 16);
        }
    }
    return strTemp;
}

string UrlDecode(const string& str)
{
    string strTemp = "";

    size_t length = str.length();
    for (size_t i = 0; i < length; i++)
    {
        if (str[i] == '+') strTemp += ' ';
        else if (str[i] == '%')
        {
            assert(i + 2 < length);
            unsigned char high = FromHex((unsigned char)str[++i]);
            unsigned char low = FromHex((unsigned char)str[++i]);
            strTemp += high*16 + low;
        }
        else strTemp += str[i];
    }
    return strTemp;
}


int ChangePicUrl(const string &strSize,const string &strInitUrl,string &strFinallyUrl)
{
	strFinallyUrl = strInitUrl;

	size_t pos = strFinallyUrl.find_last_of(".");
	string strSux = strFinallyUrl.substr(pos);
	strFinallyUrl.erase(pos);

	strFinallyUrl.append(strSize);
	strFinallyUrl.append(strSux);

	return 0;
}

//http gzip解压
int httpgzdecompress(Byte *zdata, uLong nzdata, Byte *data, uLong *ndata)
{
    int err = 0;
    z_stream d_stream = {0};
    static char dummy_head[2] =
    {
        0x8 + 0x7 * 0x10,
        (((0x8 + 0x7 * 0x10) * 0x100 + 30) / 31 * 31) & 0xFF,
    };
    d_stream.zalloc = (alloc_func)0;
    d_stream.zfree = (free_func)0;
    d_stream.opaque = (voidpf)0;
    d_stream.next_in = zdata;
    d_stream.avail_in = 0;
    d_stream.next_out = data;
    if(inflateInit2(&d_stream, 47) != Z_OK)
        return -1;
    while (d_stream.total_out < *ndata && d_stream.total_in < nzdata)
     {
        d_stream.avail_in = d_stream.avail_out = 1;
        if((err = inflate(&d_stream, Z_NO_FLUSH)) == Z_STREAM_END)
            break;
        if(err != Z_OK )
        {
            if(err == Z_DATA_ERROR)
            {
                d_stream.next_in = (Byte*) dummy_head;
                d_stream.avail_in = sizeof(dummy_head);
                if((err = inflate(&d_stream, Z_NO_FLUSH)) != Z_OK)
                    return -1;
            }
            else
                return -1;
        }
    }
    if(inflateEnd(&d_stream) != Z_OK)
        return -1;
    *ndata = d_stream.total_out;
    return 0;
}


