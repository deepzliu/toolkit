/*-------------------------------------------------------------------------
 *    File Name : https_client.cpp
 *    Desc      :
 *    Author    : jackshi
 *    Date      : 2016-6-23 
 *    History   :
 *                1)
 *-------------------------------------------------------------------------*/

#include "mt_https_client.h"

#include <netinet/in.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>

#include "sppincl.h"
#include "micro_thread.h"
#include "mt_https_tool.h"

using namespace NS_MICRO_THREAD;
namespace spp
{
namespace http
{

static const int bio_read_timeout = 2500;
static const int bio_write_timeout = 2500;

static int mt_write(BIO *h, const char *buf, int num);
static int mt_read(BIO *h, char *buf, int size);
static long mt_ctrl(BIO *h, int cmd, long arg1, void *arg2);
static int mt_new(BIO *h);
static int mt_free(BIO *data);

static BIO_METHOD methods_mt =
{
    BIO_TYPE_SOCKET,
    "socket_mt",
    mt_write,
    mt_read,
    NULL,
    NULL,
    mt_ctrl,
    mt_new,
    mt_free,
    NULL
};

BIO_METHOD *BIO_s_socket_mt(void)
{
    return (&methods_mt);
}

BIO *BIO_new_socket_mt(int fd, int close_flag)
{
    BIO *ret;

    ret = BIO_new(BIO_s_socket_mt());
    if (ret == NULL)
        return (NULL);
    BIO_set_fd(ret, fd, close_flag);
    return (ret);
}

static int mt_new(BIO *bi)
{
    bi->init = 0;
    bi->num = 0;
    bi->ptr = NULL;
    bi->flags = 0;
    return (1);
}

static int mt_free(BIO *a)
{
    if (a == NULL)
        return (0);
    if (a->shutdown)
    {
        if (a->init)
        {
            shutdown(a->num, SHUT_RDWR);
            close(a->num);
        }
        a->init = 0;
        a->flags = 0;
    }
    return (1);
}

static int mt_read(BIO *b, char *out, int outl)
{
    int ret = 0;

    if (out != NULL)
    {
        errno = 0;
        ret = MtFrame::read(b->num, out, outl, bio_read_timeout);
    }
    return (ret);
}

static int mt_write(BIO *b, const char *in, int inl)
{
    int ret = 0;

    if (in != NULL)
    {
        errno = 0;
        ret = MtFrame::write(b->num, in, inl, bio_write_timeout);
    }
    return (ret);
}

static long mt_ctrl(BIO *b, int cmd, long num, void *ptr)
{
    long ret = 1;
    int *ip;

    switch (cmd)
    {
    case BIO_C_SET_FD:
        mt_free(b);
        b->num= *((int *)ptr);
        b->shutdown = (int)num;
        b->init = 1;
        break;
    case BIO_C_GET_FD:
        if (b->init)
        {
            ip = (int *)ptr;
            if (ip != NULL)
                *ip = b->num;
            ret = b->num;
        } else
            ret = -1;
        break;
    case BIO_CTRL_GET_CLOSE:
        ret = b->shutdown;
        break;
    case BIO_CTRL_SET_CLOSE:
        b->shutdown = (int)num;
        break;
    case BIO_CTRL_DUP:
    case BIO_CTRL_FLUSH:
        ret = 1;
        break;
    default:
        ret = 0;
        break;
    }
    return (ret);
}

SSL_CTX *HttpsClient::ctx_ = NULL;

HttpsClient::HttpsClient() : fd_(-1), bio_(NULL), ssl_(NULL)
{
}

HttpsClient::~HttpsClient()
{
    Close();
}

int HttpsClient::CreateSocket()
{
    // 开启保活机制
    // 有效性探测之间的时间间隔
    // 两个探测的时间间隔
    // 有效性探测的最大次数
    int keepalive = 1;
    int keepidle = 20;
    int keepinterval = 3;
    int keepcount = 3;
    int val = 0;

    if ((fd_ = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        strerr_.append("socket error");
        return -1;
    }

    if ((val = fcntl(fd_, F_GETFL, 0)) < 0)
    {
        strerr_.append("fcntl F_GETFL error");
        close(fd_);
        return -1;
    }

    val |= O_NONBLOCK;
    if (fcntl(fd_, F_SETFL, val) == -1)
    {
        strerr_.append("fcntl F_SETFL error");
        close(fd_);
        return -1;
    }

    if (setsockopt(fd_, SOL_SOCKET, SO_KEEPALIVE, (void *)&keepalive,
        sizeof(keepalive)) != 0)
    {
        strerr_.append("setsockopt SO_KEEPALIVE error");
        close(fd_);
        return -1;
    }

    if (setsockopt(fd_, SOL_TCP, TCP_KEEPIDLE, (void *)&keepidle,
        sizeof(keepidle)) != 0)
    {
        strerr_.append("setsockopt TCP_KEEPIDLE error");
        close(fd_);
        return -1;
    }

    if (setsockopt(fd_, SOL_TCP, TCP_KEEPINTVL, (void*)&keepinterval,
        sizeof(keepinterval)) != 0)
    {
        strerr_.append("setsockopt TCP_KEEPINTVL error");
        close(fd_);
        return -1;
    }

    if (setsockopt(fd_, SOL_TCP, TCP_KEEPCNT, (void *)&keepcount,
        sizeof(keepcount)) != 0)
    {
        strerr_.append("setsockopt TCP_KEEPCNT error");
        close(fd_);
        return -1;
    }

    return fd_;
}

int HttpsClient::Init(const string &ip, uint16_t port)
{
    ClearLog();

    struct sockaddr_in addr = {0};
    fd_ = CreateSocket();
    int ret = 0;

    if (fd_ < 0)
    {
        strerr_.append("CreateSocket error");
        return -1;
    }

    if ((bio_ = BIO_new_socket_mt(fd_, 1)) == NULL) goto end;
    if (ctx_ == NULL)
    {
        SSL_library_init();
        if ((ctx_ = SSL_CTX_new(TLSv1_client_method())) == NULL)
        {
            strerr_.append("SSL_CTX_new error");
            goto end;
        }
    }

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = inet_addr(ip.c_str());

    strlog_.append("HttpsClient connect to ")
           .append(ip)
           .append(":")
           .append(u2s(port));

    if (MtFrame::connect(fd_, (struct sockaddr *)&addr, sizeof(addr), bio_connect_timeout) < 0)
    {
        strerr_.append("MtFrame::connect error: ")
               .append("strerror(errno)");
        goto end;
    }

    if ((ssl_ = SSL_new(ctx_)) == NULL)
    {
        strerr_.append("SSL_new error");
        goto end;
    }

    SSL_set_bio(ssl_, bio_, bio_);

    if ((ret = SSL_connect(ssl_)) <= 0)
    {
        strerr_.append("SSL_connect error, error code = ")
               .append(i2s(SSL_get_error(ssl_, ret)));
        goto end;
    }

    return 0;

end:
    Close();
    return -2;
}

int HttpsClient::SendAndRecv(const char *sendbuf, size_t sendlen, char *recvbuf, size_t *recvlen, int max_recvlen)
{
    ClearLog();

    if (fd_ < 0 || NULL == ssl_ || NULL == bio_)
    {
        strerr_.append("ssl or bio invalid");
        return -1;
    }

    if (NULL == sendbuf || 0 == sendlen || NULL == recvbuf || NULL == recvlen)
    {
        strerr_.append("send or recv buf invalid");
        return -2;
    }

    return SslSendAndRecv(sendbuf, sendlen, recvbuf, recvlen, max_recvlen);
}

int HttpsClient::SslSendAndRecv(const char *sendbuf, size_t sendlen, char *recvbuf, size_t *recvlen, int max_recvlen)
{
    size_t recvpos = 0;
    bool http_done = false;
    int ret = 0;

    size_t left = sendlen;
    while (left)
    {
        // <=0 包含两种情况：
        // 1. <0 表示发送错误
        // 2. =0 表示服务器重启或宕机了
        if ((ret = SSL_write(ssl_, sendbuf+sendlen-left, left)) <= 0)
        {
            strerr_.append("SSL_write error, error code = ")
                   .append(i2s(SSL_get_error(ssl_, ret)))
                   .append("|ret = ")
                   .append(i2s(ret))
                   .append("|errno = ")
                   .append(i2s(errno))
                   .append("|strerror = ")
                   .append(strerror(errno));
            return -1;
        }

        if ((int)left < ret)
        {
            strerr_.append("SSL_write error, left = ")
                   .append(i2s(left))
                   .append("|ret = ")
                   .append(i2s(ret));
            return -1;
        }

        left -= ret;
    }

    while (true)
    {
        int recvlen_ = 0;

        // <=0 包含两种情况：
        // 1. <0 表示发送错误
        // 2. =0 表示服务器重启或宕机了
        recvlen_ = SSL_read(ssl_, recvbuf+recvpos, (int)max_recvlen-recvpos);
        if (recvlen_ <= 0)
        {
            strerr_.append("SSL_read error, error code = ")
                   .append(i2s(SSL_get_error(ssl_, recvlen_)))
                   .append("|ret = ")
                   .append(i2s(ret))
                   .append("|errno = ")
                   .append(i2s(errno))
                   .append("|strerror = ")
                   .append(strerror(errno));
            break;
        }

        // out of memory, stop receiving http and stop going down
        if (recvpos + (size_t)recvlen_ >= static_cast<uint32_t>(max_recvlen))
        {
            strerr_.append("recvbuf_ out of memory");
            break;
        }

        recvpos += recvlen_;

        // pay attention to oom
        spp::http::HttpParserImpl parser;
        int ret = parser.CheckHttp(recvbuf, recvpos);
        if (spp::http::HttpParserImpl::HPC_OK == ret)
        {
            http_done = true;
            // if (status) *status = parser.status_code;
            break;
        }
        else if (spp::http::HttpParserImpl::HPC_NOT_COMPLETE_HTTP == ret)
        {
            continue;
        }
        else if (spp::http::HttpParserImpl::HPC_NOT_HTTP == ret)
        {
            recvpos = 0; break;
        }
        else
        {
            recvpos = 0;
            break;
        }

    }

    assert(static_cast<int>(recvpos) < max_recvlen);
    recvbuf[recvpos] = '\0'; // in order to print log and recvpos is safe
    strlog_.append("response = \n")
           .append(recvbuf);

    if (http_done)
    {
        *recvlen = recvpos;
        recvpos = 0;
        return 0;
    }

    return -1;
}

void HttpsClient::Close()
{
    if (ssl_)
    {
        SSL_shutdown(ssl_);
        SSL_free(ssl_);
        bio_ = NULL;
    }

    if (bio_)
    {
        BIO_free(bio_);
    }

    if (fd_ != -1) close(fd_);

    fd_ = -1;
    ssl_ = NULL;
    bio_ = NULL;
}

}
}
