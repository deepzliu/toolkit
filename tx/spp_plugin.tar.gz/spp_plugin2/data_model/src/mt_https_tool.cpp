/*-------------------------------------------------------------------------
 *    File Name : http_tool.cc
 *    Desc      :
 *    Author    : dylanzheng
 *    Date      : 2015-11-19 11:14:22
 *    History   :
 *                1)
 *-------------------------------------------------------------------------*/

#include "mt_https_tool.h"

#include <string>
#include <vector>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#include "http_parser.h"

namespace spp
{
namespace http
{

template<class T>
struct HttpParserParam
{
    T *http_struct;
    std::vector<std::string> headers;
};

// Use template here inorder to reuse function definition.
template<class T>
static int header_field_cb(http_parser *parser, const char *at, size_t length)
{
    if(NULL == parser->data) return 0;

    T *t = static_cast<T *>(parser->data);
    t->headers.push_back(std::string(at, length));
    return 0;
}

template<class T>
static int header_value_cb(http_parser *parser, const char *at, size_t length)
{
    if(NULL == parser->data) return 0;

    T *t = static_cast<T *>(parser->data);
    t->headers.push_back(std::string(at, length));
    return 0;
}

template<class T>
static int request_url_cb(http_parser *parser, const char *at, size_t length)
{
    if(NULL == parser->data) return 0;

    T *t = static_cast<T *>(parser->data);
    t->http_struct->SetUrl(std::string(at, length));
    return 0;
}

template<class T>
static int request_body_cb(http_parser *parser, const char *at, size_t length)
{
    if(NULL == parser->data) return 0;

    T *t = static_cast<T *>(parser->data);
    t->http_struct->SetContent(std::string(at, length));
    return 0;
}
/*
int HttpParserImpl::ParseHttpRequest(const std::string &httpbuf, HttpRequest *http_request)
{
    if (!http_request) return 0;

    http_parser_settings settings = {0, 0, 0, 0, 0, 0, 0, 0};
    http_parser parser;

    memset(&parser, 0, sizeof(parser));
    http_parser_init(&parser, HTTP_REQUEST);
    HttpParserParam<HttpRequest> hpp;
    hpp.http_struct = http_request;
    parser.data = &hpp;
    settings.on_header_field = &header_field_cb<HttpParserParam<HttpRequest> >;
    settings.on_header_value = &header_value_cb<HttpParserParam<HttpRequest> >;
    settings.on_url = request_url_cb<HttpParserParam<HttpRequest> >;
    settings.on_body = request_body_cb<HttpParserParam<HttpRequest> >;
    size_t nparsed = http_parser_execute(&parser, &settings, httpbuf.data(), httpbuf.size());
    if (nparsed != httpbuf.size())
        return -1;

    // assert(hpp.headers.size() % 2 == 0);

    uint32_t size = hpp.headers.size();
    if ((size & 0x01) != 0)
        return -2;
    
    for (uint32_t i = 0; i < size; i+=2)
    {
        http_request->SetHeader(hpp.headers[i], hpp.headers[i+1]);
    }

    switch (parser.method)
    {
    case HTTP_GET:
        http_request->SetMethod(HttpRequest::HTTP_REQUEST_METHOD_GET); break;
    case HTTP_POST:
        http_request->SetMethod(HttpRequest::HTTP_REQUEST_METHOD_POST); break;
    default:
        http_request->SetMethod(HttpRequest::HTTP_REQUEST_METHOD_UNKNOWN); break;
    }
    return 0;
}
*/
/*int HttpParserImpl::ParseHttpResponse(const std::string &httpbuf, HttpResponse *http_response)
{
    if (!http_response) return 0;

    http_parser_settings settings = {0, 0, 0, 0, 0, 0, 0, 0};
    http_parser parser;

    memset(&parser, 0, sizeof(parser));
    http_parser_init(&parser, HTTP_RESPONSE);
    HttpParserParam<HttpResponse> hpp;
    hpp.http_struct = http_response;
    parser.data = &hpp;
    settings.on_header_field = header_field_cb<HttpParserParam<HttpResponse> >;
    settings.on_header_value = header_value_cb<HttpParserParam<HttpResponse> >;
    settings.on_body = request_body_cb<HttpParserParam<HttpResponse> >;
    size_t nparsed = http_parser_execute(&parser, &settings, httpbuf.data(), httpbuf.size());
    if (nparsed != httpbuf.size())
        return -1;

    assert(hpp.headers.size() % 2 == 0);

    uint32_t size = hpp.headers.size();
    for (uint32_t i = 0; i < size; i+=2)
    {
        http_response->SetHeader(hpp.headers[i], hpp.headers[i+1]);
    }

    http_response->SetStatus(parser.status_code);
    return 0;
}
*/
// http_parser 辅助函数
static int http_complete(http_parser *parser)
{
    *(int *)(parser->data) = 1;
    return -1; // 返回非零，终止解析
}

int HttpParserImpl::CheckHttp(const std::string &httpbuf)
{
    return CheckHttp(httpbuf.c_str(), httpbuf.size());
}

int HttpParserImpl::CheckHttp(const void *httpbuf, size_t size)
{
    int complete = 0;
    http_parser_settings settings = {0, 0, 0, 0, 0, 0, 0, 0};
    http_parser parser;
    http_parser_init(&parser, HTTP_BOTH);
    parser.data = &complete;
    settings.on_message_complete = http_complete;

    int nparsed = http_parser_execute(&parser, &settings, static_cast<const char *>(httpbuf), size);
    if ((static_cast<uint32_t>(nparsed) <= size) && (1 == complete))
    {
        return HPC_OK;
    }
    else if (nparsed == 0) // not http, shutdown
    {
        return HPC_NOT_HTTP;
    }
    else if ((static_cast<uint32_t>(nparsed) <= size) && (0 == complete))
    {
        return HPC_NOT_COMPLETE_HTTP;
    }
    else
    {
        return HPC_UNKNOWN;
    }
}

}
}
