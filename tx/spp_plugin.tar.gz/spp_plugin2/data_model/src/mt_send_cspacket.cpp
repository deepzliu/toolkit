#include "mt_send_cspacket.h"

using namespace NS_MICRO_THREAD;
   
int SendCsPacketDataModel::send_cspacket()
{
    int iRet = 0;

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(mDestIP.c_str());
    dst.sin_port = htons(mDestPort);

    char * sndbuf = NULL;
    char * rcvbuf = NULL;
    int buflen = mBufMaxLen;
    GET_BUFFER(buflen, sndbuf, rcvbuf);

    mHeader.BasicInfo.Command = mCmd;
    iRet = packJceVideoComm(sndbuf, buflen, mHeader);
    if(iRet < 0)
    {
        return JCE_PACK_ERROR;
    }
    
    CCsPacket oPacket;
    oPacket.setCommand(mCommand);
    oPacket.setCsCommand(mCsCommand);
    oPacket.setCsSubCommand(mCmd); 
    oPacket.setBody((uint8_t *)sndbuf, buflen);
    oPacket.encode();
    memcpy(sndbuf, (const char *)oPacket.getPacket(), oPacket.getPacketLen());
    buflen = oPacket.getPacketLen();

    static int sockfd = 0;
    if(sockfd == 0)
    {
        sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    }
    
    if(sockfd < 0)
    {
        SF_ELOG("create socket failed!");
        return -1001;
    }

    iRet = mt_sendto(sockfd, sndbuf, buflen, 0, (struct sockaddr *)&dst, sizeof(dst), mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("send cs packet failed!");
        return -1002;
    }

    return 0;
}


