#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <stdio.h>
using namespace std;
#include "buffer.h"
#include "common_define.h"
#include "coder_define.h"


int tmem_encode_list(int op,int bid,uint32_t seq
                    ,vector<ssdasn::TKeyNode> &node
                    ,const uint32_t & pass_id
                    ,string & ret_sbuffer)
{
    char *pkt = NULL;
    int   len = 0;
	ssdasn::TReqExt req;
	char szbuffer[512 * 1024];
    	
    if (pass_id > 0) 
    {
		req.passwd = pass_id;
		req.clientflg |= ssdasn::em_cli_flg_use_passwd;
	}

	if (node.size() <= 0)
		return ssdasn::cache_err_illegal;

	int size = 256;
	for (size_t i = 0; i < node.size(); ++i) 
	{
		if (node[i].key.size() <= 1) 
		{
			return ssdasn::err_args;
		}
		size += node[i].key.size();
		size += node[i].data.size();
	}

	if (size > MAX_PACKET_SIZE) 
		return ssdasn::err_packet_too_big;

	int ret = ssdasn::trmem_encode_list(bid, op, seq, node, const_cast<char*>(szbuffer), sizeof(szbuffer), pkt, len, &req);
    if (ret != 0)
    {
        return ret;
    }
    assert(pkt != NULL);
    assert(len > 0);

    ret_sbuffer.assign(pkt,pkt + len);
    
    return ret;
}


int tmem_encode_list(int op,int bid,uint32_t seq
                    ,vector<ssdasn::TKeyNode> &node
                    ,const uint32_t & pass_id
                    ,char * ret_sbuffer, int & buf_len)
{
    char *pkt = NULL;
    int   len = 0;
	ssdasn::TReqExt req;
	char szbuffer[512 * 1024];
    	
    if (pass_id > 0) 
    {
		req.passwd = pass_id;
		req.clientflg |= ssdasn::em_cli_flg_use_passwd;
	}

	if (node.size() <= 0)
		return ssdasn::cache_err_illegal;

	int size = 256;
	for (size_t i = 0; i < node.size(); ++i) 
	{
		if (node[i].key.size() <= 1) 
		{
			return ssdasn::err_args;
		}
		size += node[i].key.size();
		size += node[i].data.size();
	}

	if (size > MAX_PACKET_SIZE) 
		return ssdasn::err_packet_too_big;

	int ret = ssdasn::trmem_encode_list(bid, op, seq, node, const_cast<char*>(szbuffer), sizeof(szbuffer), pkt, len, &req);
    if (ret != 0)
    {
        return ret;
    }
    assert(pkt != NULL);
    assert(len > 0);
    if(len >= buf_len )
        return -__LINE__;

    memcpy(ret_sbuffer ,pkt,len);
    buf_len = len;
    
    return ret;
}


int tmem_decode_list(int op ,const string & sbuffer,uint32_t &seq, vector<ssdasn::TKeyNode> &node)
{
    int rop = 0; 
    int tmp_seq;
	int ret = ssdasn::trmem_decode_list(const_cast<char*>(sbuffer.data()), sbuffer.size(), rop, tmp_seq, node);
	if (ret < 0)
	{
		return ret;
    }
    seq = tmp_seq;
    
    return ret;
}

int tmem_decode_list(int op ,const char * sbuffer,const uint32_t buf_len,uint32_t &seq, vector<ssdasn::TKeyNode> &node)
{
    int rop = 0; 
    int tmp_seq;
	int ret = ssdasn::trmem_decode_list(const_cast<char*>(sbuffer), buf_len, rop, tmp_seq, node);
	if (ret < 0)
	{
		return ret;
    }
    seq = tmp_seq;
    
    return ret;
}


int tmem_encode(int op, int bid, uint32_t seq, ssdasn::TKeyNode &node, int &expire,
                    const uint32_t & pass_id, string & ret_sbuffer)
{
    char *pkt = NULL;
    int   len = 0;
	ssdasn::TReqExt req;
	char szbuffer[512 * 1024];
    	
    if (pass_id > 0) 
    {
		req.passwd = pass_id;
		req.clientflg |= ssdasn::em_cli_flg_use_passwd;
	}


	int size = 256;

    if(node.key.size() < 1)
    {
        return ssdasn::err_args;
    }
    size += node.key.size();
    size += node.data.size();


	if (size > MAX_PACKET_SIZE) 
		return ssdasn::err_packet_too_big;

    //std::cout << "key=" << node.key << "|data=" << node.data << std::endl;
    int ret = ssdasn::trmem_encode(bid, op, seq, node.key, node.data, const_cast<char*>(szbuffer), sizeof(szbuffer), pkt, len, -1, expire, 0, -1, &req);

    
    if (ret != 0)
    {
        return ret;
    }
    assert(pkt != NULL);
    assert(len > 0);

    ret_sbuffer.assign(pkt,pkt + len);
    
    return ret;
}



int tmem_encode(int op, int bid, uint32_t seq, ssdasn::TKeyNode &node, int &expire, 
                    const uint32_t & pass_id,char * ret_sbuffer, int & buf_len)
{
    char *pkt = NULL;
    int   len = 0;
	ssdasn::TReqExt req;
	char szbuffer[512 * 1024];
    	
    if (pass_id > 0) 
    {
		req.passwd = pass_id;
		req.clientflg |= ssdasn::em_cli_flg_use_passwd;
	}


	int size = 256;
	if(node.key.size() < 1)
    {
        return ssdasn::err_args;
    }
    size += node.key.size();
    size += node.data.size();

	if (size > MAX_PACKET_SIZE) 
		return ssdasn::err_packet_too_big;

	int ret = ssdasn::trmem_encode(bid, op, seq, node.key, node.data, const_cast<char*>(szbuffer), buf_len, pkt, len, -1, expire, 0, -1, &req);
    if (ret != 0)
    {
        return ret;
    }
    assert(pkt != NULL);
    assert(len > 0);
    if(len >= buf_len )
        return -__LINE__;

    memcpy(ret_sbuffer ,pkt,len);
    buf_len = len;
    
    return ret;
}


int tmem_decode(int op, int bid, uint32_t &seq, const string & sbuffer, ssdasn::TKeyNode &node)
{
    int tmp_seq;
    ssdasn::TRspExt rsp;
    int cas = -1;
    
	int ret = ssdasn::trmem_decode(const_cast<char*>(sbuffer.data()), sbuffer.size(), bid, op, tmp_seq, node.key, node.data, node.retcode, cas, &rsp);
	if (ret < 0)
	{
		return ret;
    }
    seq = tmp_seq;
    return ret;
}



int tmem_decode(int op, int bid, uint32_t &seq, const char * sbuffer,const uint32_t buf_len, ssdasn::TKeyNode &node)
{
    int tmp_seq;
    ssdasn::TRspExt rsp;
    int cas = -1;
    
	int ret = ssdasn::trmem_decode(const_cast<char*>(sbuffer), buf_len, bid, op, tmp_seq, node.key, node.data, node.retcode, cas, &rsp);
	if (ret < 0)
	{
		return ret;
    }
    seq = tmp_seq;
    return ret;

}




