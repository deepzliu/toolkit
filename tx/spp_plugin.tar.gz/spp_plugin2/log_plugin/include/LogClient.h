#ifndef _LOG_CLIENT_H_
#define _LOG_CLIENT_H_



#include <string>
#include "tc_clientsocket.h"
#include <iostream>
#include <vector>

using namespace std;



class LogClient
{
public:
    LogClient()
        :_uPort(0)
        ,_isInit(false)
    {
    
    }
    
    void logger(const string & sApp
               ,const string & sServer
               ,const string & sFile
               , const string & sFormat
               ,const vector<string> &v);

    void setLogInfo(const string & strIp, uint32_t port)
    {
        _sIp = strIp;
        _uPort = port;
    }
    
protected:

    string _sIp;

    uint32_t _uPort;

    taf::TC_UDPClient _udpClient;

    bool _isInit;
};


#endif


