#ifndef _REMOTE_LOGGER_H_
#define _REMOTE_LOGGER_H_

#include "tc_logger.h"
#include <string>
#include <deque>

#include "LogClient.h"


using namespace std;


namespace taf
{


class TimeWriteT;

/**
 * 远程的Log写操作类
 */
class RemoteTimeWriteT
{
public:
    ~RemoteTimeWriteT();

    /**
     * 构造函数
     */
    void setTimeWriteT(TimeWriteT *pTimeWrite);

    /**
     * 具体调用
     * @param of
     * @param buffer
     */
    void operator()(ostream &of, const deque<pair<int, string> > &buffer);

protected:
    /**
     * 同步到远程
     */
    void sync2remote(const vector<string> &buffer);

protected:
    /**
     * 指针
     */
    TimeWriteT          *_pTimeWrite;

};


////////////////////////////////////////////////////////////////////////////
/**
 * 写Logger
 */
class TimeWriteT
{
public:
    typedef TC_Logger<RemoteTimeWriteT, TC_RollByTime> RemoteTimeLogger;

    /**
     * 构造
     */
    TimeWriteT();

    /**
     * 析够
     */
    ~TimeWriteT();

    /**
     * 设置基本信息
     * @param app, 应用名称
     * @param server, 服务名称
     * @param file, 日志文件名
     * @param sFormat, 格式
     */
    void setLogInfo(const string &sApp, const string &sServer, const string &sFile, const string &sLogpath, const string &sFormat);

    /**
     * 设置代理
     * @param logPrx 代理信息
     */
    void setLogPrx(const string &ip,const uint32_t uport);

    /**
     * 远程日志功能打开或关闭
     * @param bEnable
     */
    void enableRemote(bool bEnable)         { _bRemote = bEnable; }

    /**
     * 本地日志功能功能打开或关闭
     * @param bEnable
     */
    void enableLocal(bool bEnable);

    /**
     * 设置时间格式("%Y%m%d")
     * @param sFormat
     */
    void setFormat(const string &sFormat)   { _sFormat = sFormat; }

    /**
     * 具体调用
     * @param of
     * @param buffer
     */
    void operator()(ostream &of, const deque<pair<int, string> > &buffer);

    
    RemoteTimeLogger * getRemoteLogger() 
    {
        return _pRemoteTimeLogger;
    }
protected:

    /**
     * 友元
     */
    friend class RemoteTimeWriteT;

    /**
     * 记录错误文件
     * @param buffer
     */
    void writeError(const vector<string> &buffer);

    /**
     * 记录错误文件
     * @param buffer
     */
    void writeError(const deque<pair<int, string> > &buffer);

    /**
     * 初始化logger
     */
    void initError();


protected:
    
    /**
     * 远程时间日志
     */
    RemoteTimeLogger    *_pRemoteTimeLogger;

    /**
     * 远程功能
     */
    bool                _bLocal;

    /**
     * 远程功能
     */
    bool                _bRemote;

    /**
     * 远程服务句柄
     */
    LogClient*              _logPrx;

    /**
     * app名称
     */
    string              _sApp;

    /**
     * 服务名称
     */
    string              _sServer;

    /**
     * 日志文件名称
     */
    string              _sFile;

    /**
     * 时间格式
     */
    string              _sFormat;

    /**
     * 具体文件
     */
    string              _sFilePath;

    /**
     * 错误文件
     */
    TC_DayLogger        _elogger;

    /**
     * 缺省写模式
     */
    TC_DefaultWriteT    _wt;
    

    string              _logPrxInfo;
};


typedef TC_Logger<TimeWriteT, TC_RollByTime> RemoteDayLogger; 



};
#endif



