#ifndef LOCAL_LOGGER_H_
#define LOCAL_LOGGER_H_

#include <iostream>
#include "tc_singleton.h"
#include "tc_logger.h"
#include "tc_file.h"
#include "sys/time.h"
#include "mt_config.h"

#ifndef DEFAULT_CONF_FILE
#define DEFAULT_CONF_FILE "../etc/base.ini"
#endif

class ThreadGroup : public taf::TC_LoggerThreadGroup
{
public:
    void stop()
    {
        _bTerminate = true;
    }
	
	int getSize()
	{
		return _logger.size();
	}
};


class NoneLogger;
extern NoneLogger g_nonelogger;
class NoneLogger
{
public:
    static NoneLogger & instance()
    {
        return g_nonelogger;
    }
    typedef ios_base& (*I)(ios_base& os);
	NoneLogger& operator << (I f){  return g_nonelogger; }

	template <typename P>
	NoneLogger& operator << (const P &t){   return g_nonelogger; }

	typedef ostream& (*F)(ostream& os);
	NoneLogger& operator << (F f){  return g_nonelogger;}
    
};

class LocalLogger
{
public:
    static void initLogger(const string & confFile = DEFAULT_CONF_FILE);
	static void destroyLogger();
};

//extern taf::TC_DayLogger         g_dlogger;
extern taf::TC_RollLogger         g_dlogger; //滚动日志

string getSppExeDir(const string &path, const string &defaultName);

#define ALOG    g_dlogger.any() << __FILE__ << "(" << __LINE__ << "):"
#define ELOG    g_dlogger.error() << __FILE__ << "(" << __LINE__ << "):"
#define DLOG    g_dlogger.debug() << __FILE__ << "(" << __LINE__ << "):"
#define TLOG    g_dlogger.info() << __FILE__ << "(" << __LINE__ << "):"
#define NLOG 	g_nonelogger


#endif



