#ifndef REMOTE_LOGGER_H_
#define REMOTE_LOGGER_H_

#include "tc_singleton.h"
#include "tc_logger.h"
#include "tc_file.h"
#include <iostream>
#include "sys/time.h"
#include "RemoteLogger.h"
#include "mt_comm.h"

#ifndef DEFAULT_CONF_FILE
#define DEFAULT_CONF_FILE "../etc/base.ini"
#endif

extern taf::RemoteDayLogger g_remoteLogger;

class RemoteLogger
{
public:
	static void initLogger(const string &confFile);
	static void destroyLogger();
};

#define RLOG   g_remoteLogger.any() 


#define SET_REMOTE_LOG \
	log_register remote_log(&RemoteLogger::initLogger, &RemoteLogger::destroyLogger)

#endif



