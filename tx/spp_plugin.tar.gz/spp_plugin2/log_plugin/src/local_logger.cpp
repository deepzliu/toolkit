#include "local_logger.h"
#include "mt_comm.h"

using namespace taf;

#define MAX_FILE_SIZE       500 * 1024 * 1024 
#define MAX_RECORD_NUM      0x0fffffff

ThreadGroup g_mt_threadgroup;

NoneLogger g_nonelogger;
TC_RollLogger g_dlogger;

string getSppExeDir(const string &path, const string &defaultName)
{
    if(path.length() <= 0)
    {
        return defaultName;
    }

    string::size_type posEnd = path.rfind('-');
    if(posEnd == string::npos)
    {
        return defaultName;
    }
    string dirPath = path.substr(0,posEnd);

    string::size_type posBegin = dirPath.rfind('/');
    if(posBegin == string::npos)
    {
        return defaultName;
    }
    
    return path.substr(posBegin + 1, posEnd-posBegin-1);
}

void LocalLogger::initLogger(const string & confFile)
{
    CConfigFile cConfigFile(confFile.c_str()); 
	int logLevel = cConfigFile.GetConfValue<int>("LOG_CONFIG", "level", "3");
    string logPath = "../log/";
    string logName = getSppExeDir(TC_File::getExePath(), "spp_proj");
    if(g_mt_threadgroup.getSize() == 0)
    {
        g_mt_threadgroup.start(1);
    }
    g_dlogger.init(logPath + logName);
    g_dlogger.modFlag(0x02, true);
    g_dlogger.setupThread(&g_mt_threadgroup);
    g_dlogger.setLogLevel(logLevel);
}

void LocalLogger::destroyLogger()
{
    g_mt_threadgroup.stop();
}

log_register local_log(&LocalLogger::initLogger, &LocalLogger::destroyLogger);



