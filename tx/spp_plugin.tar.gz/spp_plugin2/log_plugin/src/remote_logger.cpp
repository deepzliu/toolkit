#include "remote_logger.h"
#include "local_logger.h"
#include "qos_client.h"

using namespace taf;

TC_LoggerThreadGroup g_threadgroup;
extern ThreadGroup g_mt_threadgroup;
taf::RemoteDayLogger g_remoteLogger;

void RemoteLogger::initLogger(const string & confFile)
{
    CConfigFile cConfigFile(confFile.c_str()); 
    int logLevel = cConfigFile.GetConfValue<int>("REMOTE_LOGGER_CONF", "level", "3");
    string loggerIp = cConfigFile.GetConfValue<string>("REMOTE_LOGGER_CONF", "logger_ip", "10.133.34.10"); //"10.136.14.42"
    int loggerPort = cConfigFile.GetConfValue<int>("REMOTE_LOGGER_CONF", "logger_port", "7900");
    uint32_t remoteModid = cConfigFile.GetConfValue<uint32_t>("REMOTE_LOGGER_CONF", "logger_modid", "730625");
    uint32_t remoteCmdid = cConfigFile.GetConfValue<uint32_t>("REMOTE_LOGGER_CONF", "logger_cmdid", "458752");

    QOSREQUEST m_stQosReq;
    m_stQosReq._modid = remoteModid;
    m_stQosReq._cmd = remoteCmdid;
    int retry = 3;
    string errMsg;
    while(retry-->0)
    {
        int ret = ApiInitRoute(remoteModid, remoteCmdid, 200, errMsg);
        ret = ApiGetRoute(m_stQosReq, 100, errMsg);
        if(ret < 0 || m_stQosReq._host_ip.empty() || m_stQosReq._host_port <= 0)
        {
            continue;
        }
        else
        {
            break;
        }
    }
    if(!m_stQosReq._host_ip.empty() && m_stQosReq._host_port > 0)
    {
        loggerIp = m_stQosReq._host_ip;
        loggerPort = m_stQosReq._host_port;
    }

    string logPath = "../log/";
    string logName = getSppExeDir(TC_File::getExePath(), "spp_proj");
    if(g_mt_threadgroup.getSize() == 0)
    {
        g_mt_threadgroup.start(1);
    }
    g_remoteLogger.init(logPath + logName);
    g_remoteLogger.modFlag(0x02, true);
    g_remoteLogger.setupThread(&g_mt_threadgroup);
    g_remoteLogger.setLogLevel(logLevel);
    TimeWriteT * curWrite = (TimeWriteT * )&(g_remoteLogger.getWriteT());
    curWrite->setLogInfo("", logName, "", logPath, "%Y%m%d%H");
    curWrite->getRemoteLogger()->setupThread(&g_mt_threadgroup);
	
    curWrite->setLogPrx(loggerIp, loggerPort);
    curWrite->enableRemote(true);
}

void RemoteLogger::destroyLogger()
{
    g_mt_threadgroup.stop();
}

log_register remote_log(&RemoteLogger::initLogger, &RemoteLogger::destroyLogger);





