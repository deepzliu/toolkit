#ifndef __SPP_VERSION_H__
#define __SPP_VERSION_H__

__attribute__((weak)) char SPP_VERSION[64] = "spp version: spp_3.0.1_release_0002";
__attribute__((weak)) char MT_VERSION[64] = "mt version: mt_0.2.1";
__attribute__((weak)) char L5_VERSION[64] = "l5 version: l5_5.1.0";

#endif
