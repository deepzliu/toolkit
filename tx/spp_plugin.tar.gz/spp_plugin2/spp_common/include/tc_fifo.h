#ifndef __TC_FIFO_H
#define __TC_FIFO_H
#include <string>

/////////////////////////////////////////////////
// 说明: FIFO封装类
// Author : kevintian@tencent.com              
/////////////////////////////////////////////////

namespace taf
{

class TC_Fifo
{
public:
	enum ENUM_RW_SET
	{
		EM_WRITE = 1,	//写管道
		EM_READ  = 2	//读管道
	};

public:
	TC_Fifo(bool bOwener = true);

	~TC_Fifo();

public:
	/**
	 * 打开FIFO
	 * @param sPath:	fifo路径
	 * @param rorw: 	
	 */
	int open(const std::string & sPath, ENUM_RW_SET enRW, mode_t mode = 0777);

	/**
	 * 关闭fifo
	 */
	void close();

	/**
	 * 获取FIFO的文件描述符
	 * 
	 * @return int 
	 */
	int fd() const { return _fd; }

	/**
	 * 读数据
	 * @param buffer
	 * @param max_size		buffer的大小
	 * @return 				读到的数据长度
	 */
	int read(char * szBuff, const size_t sizeMax);

	/**
	 * 向管道写数据
	 * 
	 * @author kevintian (11-01-05)
	 * 
	 * @return int 
	 */
	int write(const char * szBuff, const size_t sizeBuffLen);

private:
	std::string		_sPathName;
	bool			_bOwner;
	ENUM_RW_SET		_enRW;
	int 			_fd;
};

}
#endif

