[LOG_CONFIG]为框架定义设置日志级别的接口，日志打印在../Log目录下，在发布服务时，需要在赤兔中制定好该配置文件的目录

参数
level=

1,	//所有的log都不写 
2,	//写错误log (ERROR_LOG)
3,	//写错误,警告log (WARN_LOG)
4,	//写错误,警告,调试log (DEBUG_LOG)
5	//写错误,警告,调试,Info log (INFO_LOG)

示例：

[LOG_CONFIG]
level=4

打印DEBUG级别日志