#ifndef _DEMO_MSG_H
#define _DEMO_MSG_H

#include "mt_spp_msg.h"
#include "live_online.h"

using namespace live_online;

class demo_msg : public spp_msg
{
public:
	demo_msg()
	{
		this->SetMsgTimeout(300);
	}

};

#endif
