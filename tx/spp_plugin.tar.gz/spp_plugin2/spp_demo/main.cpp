#include "demo_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "local_logger.h"
#include "remote_logger.h"
#include "user_data.h"
#include "attent_adapter.h"
#include "mt_config.h"
#include "mt_access_https.h"

using namespace live_online;
using namespace UserData;
using namespace helloredis;
using namespace jceAttent;

#define CMD_GET_USER_DATA 0xfe9
#define CMD_CS_PACKET 0xe980

CREATE_MSG(demo_msg)

typedef struct {
    string redisZkname;
}stRedisConf;
stRedisConf redisConf;

extern int g_max_anti_snow;

///////////////
//结束释放资源 若无资源释放 可忽略my_fini函数和work_init中的work_fini = &my_fini;
extern WorkFini work_fini;
int my_fini()
{
    if(mt_get_servertype() == SERVER_TYPE_PROXY)
    {
        cout << "my proxy fini..." << endl;
    }
    else if(mt_get_servertype() == SERVER_TYPE_WORKER)
    {
        cout << "my work fini..." << endl;
    }
    return 0;
}
//////////////

int work_init(const char * etc)
{
    /*
       common logger
       
       example config file: base.ini
       [LOG_CONFIG]
       level=3

       refer to readme.txt in spp_demo/conf directory
    */

    CConfigFile cConfigFile(etc); 
    redisConf.redisZkname = cConfigFile.GetConfValue<string>("CONFIG", 
        "redisZkname", "sz.livePraise.redis.com");
    //雪崩值 默认为10000
    g_max_anti_snow = 100000;
    
////////////////
    //结束释放资源设置回调函数 若无资源释放 可不写
    work_fini = &my_fini;
///////////////
    
    return 0;
}



typedef taf::TC_AutoPtr<JceTcpDataModel<UserDataRequest, UserDataResponse> > JceTcpDMPtr;

//多任务并发程序
//将任务放置到 TaskList task_list;
//通过mt_access(task_list)执行所有操作
//
//#define TEST_ALL 1
int process_GET_ONLINE_TOTAL_COUNT(spp_msg* curMsg,const string & curReq, string & curRsp)
{
    int ret = 0;

    curMsg->SetMsgTimeout(300);
    DLOG << "get cur msg TimeOut:" << curMsg->GetMsgTimeout() << endl;
    RLOG << "remote logger...." << endl;
    TaskList task_list;
    
#ifdef TEST_ALL   

    SF_ELOG("test SF_ELOG"); 
    ///////// video packet tcp ///////////////需要提前声明JceTcpDMPtr
    JceTcpDMPtr jceTcpPtr = creater<JceTcpDMPtr>()();
    jceTcpPtr->setL5(441089, 458752);
    
    UserData::UserDataRequest &stUserDataReq = jceTcpPtr->mReq;
    stUserDataReq.lNeedMap = 0x03;
    UserData::UserItem item;
    item.iUserType = 1;
    item.strUserID = "545891183";
    stUserDataReq.items.push_back(item);
    item.iUserType = 6;
    item.strUserID = "34175000";
    stUserDataReq.items.push_back(item);
    
    videocomm::VideoCommHeader &mHeader = jceTcpPtr->mHeader;
    videocomm::HLoginToken qqToken;
    qqToken.TokenUin = 545891183;
	qqToken.TokenKeyType = 7;
	mHeader.LoginTokens.push_back(qqToken);
	mHeader.BasicInfo.Command = CMD_GET_USER_DATA;
    
    task_list.push_back(jceTcpPtr);
    ///////// video packet tcp ///////////////
#endif    

    ///////// redis ///////////////
    GetOnlineTotalCountRequest stReq;
    ret = jceUnPack<GetOnlineTotalCountRequest>(curReq, stReq);
    
    GetOnlineTotalCountResponse stRsp;
    RedisDMPtr redisPtr = creater<RedisDMPtr>()();
    redisPtr->setZkname(redisConf.redisZkname);
    redisPtr->configCommand("GET 2060_LIVE_ONLINE_TOTAL_1_545891183");
    
    task_list.push_back(redisPtr);

    RedisDMPtr redisPtr2 = creater<RedisDMPtr>()();
    redisPtr2->setZkname("sz.gift_package.redis.com");
    redisPtr2->configCommand("ZREVRANGE 2014_RANK_1_201601 0 9 WITHSCORES");
    task_list.push_back(redisPtr2);
    ///////// redis ///////////////

#ifdef TEST_ALL 

    ///////// tmem get ///////////////
    TmemGetDMPtr tmemGetDMPtr = creater<TmemGetDMPtr>()();
    tmemGetDMPtr->setL5(154049, 589824);
    tmemGetDMPtr->setBid(100100065);
  
    vector<ssdasn::TKeyNode> &vecKeyList = tmemGetDMPtr->mKeyValueList;
	ssdasn::TKeyNode node;
	string strKey = "2016_package_";
	strKey.append("2");
	node.key = strKey;
	vecKeyList.push_back(node);
    
    task_list.push_back(tmemGetDMPtr);
    ///////// tmem get ///////////////
    
    ///////// tmem set ///////////////
    TmemSetDMPtr tmemSetDMPtr = creater<TmemSetDMPtr>()();
    tmemSetDMPtr->setL5(154049, 589824);
    tmemSetDMPtr->setBid(100100065);
    
    vector<ssdasn::TKeyNode> &vecKeyList1 = tmemSetDMPtr->mKeyValueList;
    ssdasn::TKeyNode node1;
    string strKey1 = "test";
    node1.key = strKey1;
    node1.data = "test set tmem";
    vecKeyList1.push_back(node1);
    
    task_list.push_back(tmemSetDMPtr);
    ///////// tmem set ///////////////
    
    ///////// union ///////////////
    UnionDMPtr unionDMPtr = creater<UnionDMPtr>()();
    unionDMPtr->setL5(256961, 65536);
    unionDMPtr->setType("10001068","fb6ac84880a9e6a5", 2003);
    
    vector<string> &ids = unionDMPtr->mIDs;
    ids.push_back("ayo3eem2ddjxot2");
    ids.push_back("nwpc69jp1freit0");
    
    vector<string> &fields = unionDMPtr->mFields;;
    fields.push_back("c_title");
    fields.push_back("type");
    fields.push_back("cover_id");
    task_list.push_back(unionDMPtr);
    ///////// union ///////////////

#endif

    ret = mt_access(task_list, curMsg);
    if(ret != 0)
    {
        DLOG << "mt_access error!ret:" << ret << endl;
        return ret;
    }

    /////////  redis  ///////////
    DLOG << "---------------------- redis begin --------------------------" << endl;
    DLOG << "access redis iRet:" << redisPtr->getResult() << "\tcosttime:" << redisPtr->getCostTime() << endl;
    if (redisPtr->mResData.size() > 0 && redisPtr->mResData[0].m_type == REDIS_REPLY_STRING)
    {
        DLOG << "Redis:" <<redisPtr->mResData[0].getStrValue() << endl;
        stRsp.onlineCount = atoi(redisPtr->mResData[0].getStrValue().c_str());
    }

    ret = jcePack<GetOnlineTotalCountResponse>(stRsp, curRsp);  
    if(ret != 0)
    {
        DLOG << "access_video_packet_tcp error!ret:" << ret << endl;
        return ret;
    }
    
    DLOG << "access redis2(ZREVRANGE) iRet:" << redisPtr2->getResult() << "\tcosttime:" << redisPtr2->getCostTime() << endl;
    vector<helloredis::DataUnit> &res = redisPtr2->getResData();
    for(size_t i = 0; i < res.size(); i++)
    {
        DLOG << "type:" << res[i].getType() << endl;
        DLOG << "int val:" << res[i].getIntValue() << endl;
        DLOG << "str val:" << res[i].getStrValue() << endl;
    }
    DLOG << "---------------------- redis end --------------------------" << endl;
    /////////  redis  ///////////
#ifdef TEST_ALL  
    //////// jce packet ////////
    DLOG << "---------------------- jce packet begin--------------------------" << endl;
    DLOG << "access jce packet iRet:" << jceTcpPtr->getResult() << "\tcosttime:" << jceTcpPtr->getCostTime() << endl;
    jceTcpPtr->mRsp.display(DLOG);
    DLOG << "---------------------- jce packet end--------------------------" << endl;
    //////// jce packet ////////


    /////////  tmem get  ///////////
    DLOG << "---------------------- tmem get begin--------------------------" << endl;
    DLOG << "access tmem get iRet:" << tmemGetDMPtr->getResult() << "\tcosttime:" << tmemGetDMPtr->getCostTime() << endl;
    const vector<ssdasn::TKeyNode> &vecTmemGet = tmemGetDMPtr->getResData();
    for(size_t i = 0; i < vecTmemGet.size(); i++)
    {
        DLOG << "key:" << vecTmemGet[i].key << endl;
        DLOG << "data:" << vecTmemGet[i].data << endl;
        DLOG << "ret:" << vecTmemGet[i].retcode << endl;
    }
    DLOG << "---------------------- tmem get end--------------------------" << endl;
    /////////  tmem get  ///////////

    /////////  tmem set  ///////////
    DLOG << "---------------------- tmem set begin--------------------------" << endl;
    DLOG << "access tmem set iRet:" << tmemSetDMPtr->getResult() << "\tcosttime:" << tmemSetDMPtr->getCostTime() << endl;
    const vector<ssdasn::TKeyNode> &vecTmemSet = tmemSetDMPtr->getResData();
    for(size_t i = 0; i < vecTmemSet.size(); i++)
    {
        DLOG << "key:" << vecTmemSet[i].key << endl;
        DLOG << "data:" << vecTmemSet[i].data << endl;
        DLOG << "ret:" << vecTmemSet[i].retcode << endl;
    }
    DLOG << "---------------------- tmem set end--------------------------" << endl;
    /////////  tmem set  ///////////
    
    /////////  union  ///////////
    DLOG << "---------------------- union begin--------------------------" << endl;
    DLOG << "access union get iRet:" << unionDMPtr->getResult() << "\tcosttime:" << unionDMPtr->getCostTime() << endl;
    const tv::DSGetRsp& dsRet = unionDMPtr->getResData();
    for (int i = 0; i < dsRet.results_size(); i++)
    {
        const tv::DataSet & set = dsRet.results(i);
        for (int j = 0; j < set.fields_size(); j++) 
        {
            const tv::KeyValue &kv = set.fields(j);
            if(kv.key() == "cover_id" && kv.value().type() == tv::Value::VT_STRING)
            {   
                DLOG << "cover_id:" << kv.value().strval() << endl;
            }
            if(kv.key() == "c_title" && kv.value().type() == tv::Value::VT_STRING)
            {
                DLOG << "c_title:" << kv.value().strval() << endl;
            }
             if(kv.key() == "type" && kv.value().type() == tv::Value::VT_INT)
            {
                DLOG << "type:" << kv.value().intval() << endl;
            }
        }
    }
    DLOG << "---------------------- union end --------------------------" << endl;
    /////////  union  ///////////

    task_list.clear();
    map<string,string> mapTssd;
    mapTssd["test1"] = "test11";
    mapTssd["test2"] = "test22";
    map<string,string>::iterator iter = mapTssd.begin();
    while(iter != mapTssd.end())
    {
        TssdSetDMPtr tssdSetDMPtr = creater<TssdSetDMPtr>()();
        tssdSetDMPtr->setL5(299713, 1900544);
        tssdSetDMPtr->setBidCid(100331, 1);
        tssdSetDMPtr->setKeyValue(iter->first, iter->second);
        task_list.push_back(tssdSetDMPtr);
        iter ++;
    }
       
    ret = mt_access(task_list, curMsg);
    if(ret != 0)
    {
       DLOG << "mt_access tssd set error!ret:" << ret << endl;
       return 0;
    }

    DLOG << "---------------------- tssd set begin--------------------------" << endl;
    const vector<CommonTask> & res_task_list = task_list.getlist(); 
    for(size_t i = 0 ; i < res_task_list.size(); i++)
    {
        TssdSetDMPtr setResPtr = TssdSetDMPtr::dynamicCast(res_task_list[i].basePtr);
        if(ret == 0 && setResPtr->getServerRet() == 0)
        {
            DLOG << "set " << setResPtr->getKey() << " ok" << endl;
        }
        else
        {
            DLOG << "set " << setResPtr->getKey() << " error!" << endl;
        }
    }
    DLOG << "---------------------- tssd set end--------------------------" << endl;

    task_list.clear();

    DLOG << "---------------------- tssd get begin--------------------------" << endl;
    TssdGetDMPtr tssdGetDMPtr = creater<TssdGetDMPtr>()();
    tssdGetDMPtr->setL5(299713, 1900544);
    tssdGetDMPtr->setBidCid(100331, 1);
    
    vector<string> &mkeys = tssdGetDMPtr->mKeys;
    mkeys.push_back("test1");
    mkeys.push_back("test2");
    
    task_list.push_back(tssdGetDMPtr);
    ret = mt_access(task_list, curMsg);
    if(ret != 0)
    {
        DLOG << "mt_access tssd get error!ret:" << ret << endl;
        return 0;
    }

    int server_ret = tssdGetDMPtr->getServerRet();
    const map<string, RspRecord> &record_map = tssdGetDMPtr->getResData();
    map<string, RspRecord>::const_iterator r_iter = record_map.begin();

    DLOG << "ret:" << ret << "\tserver_ret:" << server_ret << endl;
    if ((0 == ret && -21006 == server_ret) ||  (ret < 0 || 0 != server_ret))  //读取的记录不存在
    {
        DLOG << "record is not exist!" << endl;
    }
    else
    {
        while(r_iter != record_map.end())
        {
            DLOG << r_iter->first << "\t" << r_iter->second.value.size() << "\tret:" << r_iter->second.retcode
                     << "\tretmsg:" << r_iter->second.retmsg << "\ttimestamp:" << r_iter->second.stamp <<endl;
            if(r_iter->second.retcode == 0)
            {
                DLOG << "key:" << r_iter->first << "\tvalue:" <<r_iter->second.value << endl;;
            }
            else
            {
                DLOG << "key:" << "get error, ret:" << r_iter->second.retcode << endl;
            }
            r_iter++;
        }
    }
    DLOG << "---------------------- tssd get end--------------------------" << endl;

    DLOG << "---------------------- http begin--------------------------" << endl;
    //http短连接测试

	task_list.clear();

    string hostUrl = "http://like.video.qq.com/fcgi-bin/like?otype=json&callback=func&uin=0&playright=2&pidx=0&msgtype=222&tablist=9&id=a0018o7baob&size=3";
	
	HttpDMPtr httpDMPtr = creater<HttpDMPtr>()();
    httpDMPtr->setIP("10.219.143.106", 80);
    httpDMPtr->setTimeOut(400);

    taf::TC_HttpRequest &httpReq = httpDMPtr->mHttpReq;
	httpReq.setGetRequest(hostUrl, true);
	httpReq.setHost("like.video.qq.com");
	httpReq.setCookie("uin=545891183;skey=@82k0YlMef;main_login=qq;");
    
	task_list.push_back(httpDMPtr);
	
    httpDMPtr->initModCall(210100914, 0, 210100915, 110301845);
    
	ret = mt_access(task_list, curMsg);
    
    httpDMPtr->endModCall(ret);
	
	DLOG << httpDMPtr->mContent << endl;
	
    DLOG << "---------------------- http end--------------------------" << endl;

    task_list.clear();
     ///////// local cache get/////////////// 需要发布机安装localcache_service服务(赤兔搜索localcache_service)
    LocalCacheDMPtr localCacheDMGetPtr = creater<LocalCacheDMPtr>()();
    localCacheDMGetPtr->setBufMaxLen(1024*1024);
    LocalCache::LocalCacheNode node_get;
    node_get.strKey = "test_local_cache";
    localCacheDMGetPtr->setNode(LOCAL_CACHE_GET, node_get);
    task_list.push_back(localCacheDMGetPtr);
    ///////// local cache get///////////////

    ret = mt_access(task_list, curMsg);
    if(ret != 0)
    {
        DLOG << "mt_access local cache get error! ret:" << ret << endl;
        return 0;
    }

    DLOG << "---------------------- local cache get begin--------------------------" << endl;
    const vector<LocalCache::LocalCacheNode> &vecLC = localCacheDMGetPtr->mNodeList;
    for(size_t i = 0; i < vecLC.size(); i++)
    {
        DLOG << "key:" << vecLC[i].strKey << endl;
        DLOG << "value.size:" << vecLC[i].strValue.size() << endl;
        DLOG << "retcode:" << vecLC[i].code << endl;
    }    
    DLOG << "---------------------- local cache get end--------------------------" << endl;

    task_list.clear();
     ///////// local cache set///////////////
    LocalCacheDMPtr localCacheDMSetPtr = creater<LocalCacheDMPtr>()();
    localCacheDMSetPtr->setBufMaxLen(1024*1024);

    LocalCache::LocalCacheNode node_set;
    node_set.strKey = "test_local_cache";
    ostringstream ostr;
    uint32_t timeNow = time(NULL);
    for(int t = 0; t < 800000; t++)
        ostr << "a";
    node_set.strValue = ostr.str();
    localCacheDMSetPtr->setNode(LOCAL_CACHE_SET, node_set, 10);//超时时间为10s
    task_list.push_back(localCacheDMSetPtr);
    ///////// local cache set///////////////
    
    ret = mt_access(task_list);
    if(ret != 0)
    {
        DLOG << "mt_access local cache set error! ret:" << ret << endl;
        return 0;
    }
    ///////// local cache set///////////////
    DLOG << "---------------------- local cache set begin--------------------------" << endl;
    DLOG << "localcache set result:" << localCacheDMSetPtr->getResult() << endl;
    const vector<LocalCache::LocalCacheNode> &vecLCSet = localCacheDMSetPtr->mNodeList;
    for(size_t i = 0; i < vecLCSet.size(); i++)
    {
        DLOG << "key:" << vecLCSet[i].strKey << endl;
        DLOG << "retcode:" << vecLCSet[i].code << endl;
    }
    DLOG << "---------------------- local cache set end--------------------------" << endl;
    ///////// local cache set///////////////
    
    DLOG << "check cur TimeOut:" << curMsg->CheckMsgTimeout() << endl;

    DLOG << "get cur TimeOut:" << curMsg->GetMsgCost() << endl;
  
 
 
    string ip = "183.61.49.149";
    uint16_t port = 443;

    HttpsDMPtr httpsPtr = creater<HttpsDMPtr>()();
    taf::TC_HttpRequest& mHttpReq = httpsPtr->mHttpReq;
    mHttpReq.setGetRequest("https://api.weixin.qq.com/cgi-bin/menu/get?access_token=aa");
    mHttpReq.setHost("api.weixin.qq.com");
    httpsPtr->setIP(ip, port);

    TaskList tasklist;
    tasklist.push_back(httpsPtr);

    ret = mt_access(tasklist);
    if(ret != 0)
    {
        ELOG << "access https error! ret:" << ret << endl;
    }
    DLOG << "https return-->" << httpsPtr->getResData() << endl;
 #endif 
    return ret;
}

int process_CS_PACKET(spp_msg* curMsg,const string & curReq, string & curRsp)
{
    int iRet = 0;
    
    jceAttent::AttentReq stReq;

    iRet = jceUnPack<AttentReq>(curReq, stReq);

    stReq.display(DLOG);

    return iRet;
}


BaseFunctor myFunctor(LO_CMD_GET_ONLINE_TOTAL_COUNT,&process_GET_ONLINE_TOTAL_COUNT);
BaseFunctor myCSFunctor(CMD_CS_PACKET, &process_CS_PACKET);






