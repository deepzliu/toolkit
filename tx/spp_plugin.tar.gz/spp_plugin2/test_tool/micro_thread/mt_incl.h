/**
 *  @file mt_incl.h
 *  @info 微线程提供给spp_plugin的头文件
 *  @time 20130924
 */

#ifndef _MT_INCL_EX__
#define _MT_INCL_EX__

#include "mt_version.h"
#include "mt_msg.h"
#include "mt_api.h"

using namespace std;
using namespace NS_MICRO_THREAD;

#endif

