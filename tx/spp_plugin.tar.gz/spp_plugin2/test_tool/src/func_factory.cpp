#include "func_factory.h"

func_factory::func_factory()
{
    
}

void func_factory::reg( const string & func_name ,TEST_FUNC func)
{
    if(m_funcs.find(func_name) == m_funcs.end())
    {
        m_funcs.insert(make_pair<string ,TEST_FUNC>( func_name, func));
    }
}
void func_factory::print_func() const
{
    for(map<string ,TEST_FUNC >::const_iterator citer = m_funcs.begin();
        citer != m_funcs.end();citer++)
    {
        cout << "\t" << citer->first << endl;
    }
}
bool func_factory::is_valid_funcname(const string & func_name)
{
    return m_funcs.find(func_name) != m_funcs.end();
}

    
int func_factory::route(const string & func_name,int argc, char *argv[] )
{
    int ret = 0;
    map<string ,TEST_FUNC>::iterator iter = m_funcs.find(func_name);
    if(iter != m_funcs.end())
    {
        TEST_FUNC func = (TEST_FUNC)iter->second;
        ret = (*func)(argc , argv);
    }
    else
    {
        cout << "func not found" << endl;
        ret = -10;
    }
    return ret ;
}


FuncRegister::FuncRegister(const string & funcName,TEST_FUNC func)
{
    if(p_factory == NULL)
    {
        p_factory = new func_factory();
    }
    p_factory->reg(funcName, func);
}





func_factory * p_factory = NULL;



