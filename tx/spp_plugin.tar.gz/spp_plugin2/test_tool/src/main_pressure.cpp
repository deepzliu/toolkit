#include "micro_thread.h"
#include "mt_access.h"
#include <map>
#include <iostream>
#include <vector>
#include <string.h>
#include "heap_timer.h"
#include "func_factory.h"

using namespace std;
using namespace NS_MICRO_THREAD;

string g_funcName;
char ** g_paramList;
int g_paramNum = 0;
int g_loop_per_times = 1;
ObjCache g_ObjCache;
int g_worker = 3;
int g_interval = 10;
uint32_t req_per_second = 0;
uint32_t succ_times = 0;
uint32_t fail_times = 0;
uint32_t avg_time = 0;
uint32_t max_time = 0;
uint32_t pre_time = 0;

void MyTask(void*)
{
    uint32_t curtime = time(NULL);
    int total_req_per_second = 0;
    int total_cost_time_per_second = 0;
    if(curtime > pre_time)
    {
        std::cerr << "req_per_second=" << req_per_second 
                  << "qps\tsucc=" << succ_times 
                  << "\tfail=" << fail_times 
                  << "\tavg_time=" << avg_time
                  << "ms\tmax_time=" << max_time 
                  << "ms"
                  << std::endl;
        pre_time = curtime;
        req_per_second = 0;
        succ_times = 0;
        fail_times = 0;
        avg_time = 0;
        max_time = 0;
        total_req_per_second = 0;
    }
    req_per_second++;

    struct timeval start_time;
	gettimeofday(&start_time, NULL);
	
    int ret = p_factory->route(g_funcName.c_str(),g_paramNum, g_paramList);
    if(ret == 0)
        succ_times++;
    else
        fail_times++;
        
    struct timeval end_time;
	gettimeofday(&end_time, NULL);

    uint32_t interval =  (end_time.tv_sec - start_time.tv_sec) * 1000 \
               + (end_time.tv_usec - start_time.tv_usec) / 1000; 
    if(interval > max_time)
        max_time = interval;

    total_req_per_second++;
    total_cost_time_per_second += interval;
    
    if(avg_time == 0)
        avg_time = interval;
    else
        avg_time = total_cost_time_per_second / total_req_per_second;
	
}


class MyTimer : public CTimerNotify
{
public:
    virtual void timer_notify() 
    { 
        for(int i = 0;i < g_loop_per_times;i++)
        {
            if (MtFrame::CreateThread(MyTask, NULL) == NULL) 
            {
                std::cout << "CreateThread fail" << std::endl;
            }
        }
        this->set_expired_time(g_interval);
        MtFrame::Instance()->GetTimerMng()->start_timer(this,this->get_expired_time());
    };
};


int main(int argc, char *argv[])
{
    if(p_factory == NULL)
        p_factory = new func_factory;
    func_factory & g_factory = *p_factory;

    MtFrame::Instance()->SetDefaultThreadNum(20000);
    MtFrame::Instance()->InitFrame();
    MtFrame::Instance()->InitWaitNum();
    if (argc < 4) 
    {
        std::cout << "usage: ./xxx {times_per_second} {func_name} {param}" << std::endl;
        std::cout << "all func_name:" << std::endl;
        g_factory.print_func();
        
        MtFrame::Instance()->Destroy();
        
        return 0;
    }
    else
    {
        int fd = open( "/dev/null", O_RDWR );
        close(1);
        dup2(fd,1);
        MyTimer * timer = new MyTimer;
        timer->set_expired_time(g_interval);
        MtFrame::Instance()->GetTimerMng()->start_timer(timer,timer->get_expired_time());
        
        int times_per_second = 1000;
        int curtimes = atoi(argv[1]);
        //if(curtimes < times_per_second)
        //    curtimes = times_per_second;
        int mo_times = curtimes % (times_per_second/g_interval);
        if(mo_times > 0)
            g_loop_per_times = curtimes / (times_per_second/g_interval) + 1;
        else
            g_loop_per_times = curtimes / (times_per_second/g_interval);
        g_funcName = argv[2];
        g_paramList = &argv[3];
        g_paramNum = argc - 3;

        while(true)
        {
            int run_cnt = MtFrame::Instance()->RunWaitNum();
            if(run_cnt > 0)
            {
                MtFrame::sleep(0);
            }
            else
            {
                MtFrame::sleep(0);
                usleep(5);
            }
            
        }
    }
    
    return 0;
}




