#include "micro_thread.h"
#include "mt_access.h"
#include <map>
#include <iostream>
#include <vector>
#include <string.h>
#include "func_factory.h"


using namespace std;
using namespace NS_MICRO_THREAD;

int main(int argc, char *argv[])
{
    if(p_factory == NULL)
        p_factory = new func_factory;
    func_factory & g_factory = *p_factory;
    int ret = 0;
    ret = MtFrame::Instance()->InitFrame();
    if (argc < 3) 
    {
        std::cout << "usage: ./xxx func_name param" << std::endl;
        std::cout << "all func_name:" << std::endl;
        g_factory.print_func();
        MtFrame::Instance()->Destroy();
        
        return 0;
    }
    else
    {
        //同步请求
        ret = g_factory.route(argv[1],argc - 2, &argv[2]);
    }
    
    return ret;
}

ObjCache g_ObjCache;
int g_worker = 3;


