#include "func_factory.h"
#include "mt_access.h"
#include "live_online.h"

using namespace live_online;

typedef taf::TC_AutoPtr<JceTcpDataModel<GetOnlineTotalCountRequest,GetOnlineTotalCountResponse> > TestOnlinePtr;

int testLiveOnline(int argc, char *argv[])
{
    int ret = 0;
    TaskList tasklist;
	
	TestOnlinePtr testOnlinePtr = creater<TestOnlinePtr>()();
	//testOnlinePtr->setIP("10.120.129.81",18001);
	testOnlinePtr->setIP("10.175.133.145",18001);	
testOnlinePtr->setTimeOut(500);
	live_online::GetOnlineTotalCountRequest &stReq = testOnlinePtr->mReq;
    stReq.user.userType = '1';
    stReq.user.uin = 545891183;
	
	videocomm::VideoCommHeader &curHead = testOnlinePtr->mHeader;
	videocomm::HLoginToken qqToken;
	qqToken.TokenUin = 545891183;
	qqToken.TokenKeyType = 7;
	curHead.LoginTokens.push_back(qqToken);
	
	testOnlinePtr->setCmd(LO_CMD_GET_ONLINE_TOTAL_COUNT);
	
	curHead.AccessInfo.QUAInfo.versionName ="aphone";
	curHead.AccessInfo.Guid ="cd4fa6bd97e911e3b068abcd0496bb0a";
	curHead.AccessInfo.QUAInfo.versionCode ="3.9.0";
	curHead.AccessInfo.QUAInfo.platform = 5;
	
	tasklist.push_back(testOnlinePtr);
	
	ret = mt_access(tasklist);
	if(argc < 2)
	{
	    testOnlinePtr->mRsp.display(std::cout);
	}
	
    return ret;
}

REG_FUNC(testLiveOnline);


