#ifndef _MT_ACCESS_H_
#define _MT_ACCESS_H_

#include "mt_spp_msg.h"
#include "mt_access_redis.h"
#include "mt_access_services.h"

int mt_access(TaskList &tasklist, spp_msg* curMsg = NULL);

int mt_get_servertype();

#endif
