#ifndef _MT_ACCESS_BASE_H
#define _MT_ACCESS_BASE_H
#include "mt_comm.h"
#include "mt_task_base.h"

class BufferDataModel : public BaseDataModel
{
public:
	int RealProcess(){return 0;}
	string GetModelType() const
	{
		return "BUFFER_MODEL_TYPE";
	};
	
	char send_buf[BUF_LEN_DEFAULT];
	char recv_buf[BUF_LEN_DEFAULT];
};
typedef taf::TC_AutoPtr<BufferDataModel> BufferDataModelPtr;

class Buffer100kDataModel : public BaseDataModel
{
public:
	int RealProcess(){return 0;}
	string GetModelType() const
	{
		return "BUFFER_100K_MODEL_TYPE";
	};
	
	char send_buf[102400];
	char recv_buf[102400];
};
typedef taf::TC_AutoPtr<Buffer100kDataModel> Buffer100kDataModelPtr;

class Buffer1MDataModel : public BaseDataModel
{
public:
	int RealProcess(){return 0;}
	Buffer1MDataModel(){}
	string GetModelType() const
	{
		return "BUFFER_1M_MODEL_TYPE";
	};
	
	char send_buf[BUF_LEN_MAX];
	char recv_buf[BUF_LEN_MAX];
};
typedef taf::TC_AutoPtr<Buffer1MDataModel> Buffer1MDataModelPtr;


#define GET_BUFFER(buf_max_len, buf, rcv_buf) \
    \
    BaseDataModelPtr baseBufferPtr;                           \
    if(buf_max_len >= 0 && buf_max_len <= BUF_LEN_DEFAULT)             \
    {                                                        \
        BufferDataModelPtr bufferDataModelPtr = creater<BufferDataModelPtr>()("BUFFER_MODEL_TYPE");   \
        buf = bufferDataModelPtr->send_buf;              \
        rcv_buf = bufferDataModelPtr->recv_buf;          \
        baseBufferPtr = bufferDataModelPtr;              \
    }                                                       \
    else if(buf_max_len > BUF_LEN_DEFAULT && buf_max_len <= 102400)  \
    {                                                       \
        Buffer100kDataModelPtr buffer100kDataModelPtr = creater<Buffer100kDataModelPtr>()("BUFFER_100K_MODEL_TYPE");    \
        buf = buffer100kDataModelPtr->send_buf;             \
        rcv_buf = buffer100kDataModelPtr->recv_buf;         \
        baseBufferPtr = buffer100kDataModelPtr;             \
    }                                                       \
    else                                                    \
    {                                                       \
        Buffer1MDataModelPtr buffer1MDataModelPtr = creater<Buffer1MDataModelPtr>()("BUFFER_1M_MODEL_TYPE");\
        buf = buffer1MDataModelPtr->send_buf;                 \
        rcv_buf = buffer1MDataModelPtr->recv_buf;             \
        baseBufferPtr = buffer1MDataModelPtr;                 \
    }      													  \
    TaskList task_list; \
	task_list.push_back(baseBufferPtr);

int mt_access_tcp(const string &ip, uint32_t port, const char* req, int reqLen, char* rsp, int &rspLen, MtFuncTcpMsgLen checkComplete, int timeout);

int mt_access_udp(const string &ip, uint32_t port, const char* req, int reqLen, char* rsp, int &rspLen, int timeout);

#endif


