#ifndef _ACCESS_REDIS_H
#define _ACCESS_REDIS_H
#include "mt_access_base.h"
#include "mt_helloredis.h"
#include "tc_common.h"

class RedisDataModel : public BaseDataModel
{
public:
	RedisDataModel(){}
	
	int access_redis(const string &mIP, uint32_t mPort, RedisCommand &mCommand, vector<helloredis::DataUnit> &mResData, int mTimeOut, int mBufMaxLen);
	
	int access_redis(string &zkName, RedisCommand &mCommand, vector<helloredis::DataUnit> &mResData, int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		if(mConnInfo.mType == ZKNAME_TYPE)
		{
			mResult = access_redis(mConnInfo.mZkname, mCommand, mResData, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_redis(mConnInfo.mIP, mConnInfo.mPort, mCommand, mResData, mTimeOut, mBufMaxLen);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return "ACCESS_REDIS_MODEL_TYPE";
	};

	//类似redis客户端，把命令元素放到一个string类型的数组中，需保证至少有两个元素
	int configCommand(const vector<string> &key_list)
	{
		if(key_list.size() <= 1)
		{
			SF_ELOG("config Command error! need more params");
			return -1;
		}
		mCommand.cmd = key_list[0];
		mCommand.key = key_list[1];
		for(size_t i = 2; i < key_list.size(); i++)
		{
			mCommand.extkey.push_back(key_list[i]);
		}
		return 0;
	};

	//类似redis客户端的命令输入方式，默认以空格为间隔符(多空格算作一个)，需保证至少有两个元素
	int configCommand(const string &strCommand, string split = " ")
	{
		vector<string> keys = taf::TC_Common::sepstr<string>(strCommand.c_str(), split, false);
		return configCommand(keys);
	}

	vector<helloredis::DataUnit> &getResData()
	{
		return mResData;
	}
	
	RedisCommand mCommand;
	vector<helloredis::DataUnit> mResData;
};
typedef taf::TC_AutoPtr<RedisDataModel> RedisDMPtr;


#endif
