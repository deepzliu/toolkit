#ifndef _MT_ACCESS_SERVICES_H
#define _MT_ACCESS_SERVICES_H
#include "mt_access_base.h"
#include "video_packet.h"

template<typename jceReq, typename jceRsp>
class JceUdpDataModel : public BaseDataModel
{
public:
	JceUdpDataModel(){}

	int access_jce_udp(string &ip, uint32_t port, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
            				    int mTimeOut, int mBufMaxLen);

	int access_jce_udp(uint32_t modid, uint32_t cmdid, string &defaultIP, uint32_t defaultPort, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen);
	
	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_jce_udp(mConnInfo.mModid, mConnInfo.mCmdid, mConnInfo.mIP, mConnInfo.mPort, mReq, mRsp, mHeader, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_jce_udp(mConnInfo.mIP, mConnInfo.mPort, mReq, mRsp, mHeader, mTimeOut, mBufMaxLen);
		}
		return mResult;
	};

	string GetModelType() const
	{
		return mReq.className();
	};

	void setCmd(int cmd)
	{
    	mHeader.BasicInfo.Command = cmd;
	};

	jceReq mReq;
	jceRsp mRsp;
	videocomm::VideoCommHeader mHeader;
	
};

template<typename jceReq, typename jceRsp>
class JceTcpDataModel : public BaseDataModel
{
public:
	JceTcpDataModel(){}

	
	int access_jce_tcp(string &ip, uint32_t port, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen);

	int access_jce_tcp(uint32_t mModid, uint32_t mCmdid, string &defaultIP, uint32_t defaultPort, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen);

	int RealProcess()
	{
		if(mConnInfo.mType == L5_TYPE)
		{
			mResult = access_jce_tcp(mConnInfo.mModid, mConnInfo.mCmdid, mConnInfo.mIP, mConnInfo.mPort, mReq, mRsp, mHeader, mTimeOut, mBufMaxLen);
		}
		else if(mConnInfo.mType == IP_PORT_TYPE)
		{
			mResult = access_jce_tcp(mConnInfo.mIP, mConnInfo.mPort, mReq, mRsp, mHeader, mTimeOut, mBufMaxLen);
		} 
		return mResult;
	};

	string GetModelType() const
	{
		return mReq.className();
	};

	void setCmd(int cmd)
	{
    	mHeader.BasicInfo.Command = cmd;
	};

	jceReq mReq;
	jceRsp mRsp;
	videocomm::VideoCommHeader mHeader;
};

static int videoPacketComplete(void * buffer, int len)
{
    int rLen = CVideoPacket::checkPacket((const char*)buffer, len);
	if(len >= rLen)
		return rLen;
	return 0;
}

template<typename jceReq, typename jceRsp>
int JceUdpDataModel<jceReq, jceRsp>::access_jce_udp(string &ip, uint32_t port, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
            				    int mTimeOut, int mBufMaxLen)
{
	int iRet = 0;
    
	char *buf = NULL;
	char *rcv_buf = NULL;
	int len = mBufMaxLen;
    int buf_size = mBufMaxLen;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)

	iRet = jcePack<jceReq>(stReq, mHeader.body);
	if(iRet < 0)
	{
		SF_ELOG("video packet encode error!iRet:%d",iRet);
		return ENCODE_ERROR;
	}

	iRet = packJceVideoComm(buf, len, mHeader);
	if(iRet != 0)
    {
		SF_ELOG("video packet encode error!iRet:%d",iRet);
        return ENCODE_ERROR;
    }

    iRet = mt_access_udp(ip, port, buf, len, (char*)rcv_buf, buf_size, mTimeOut);
    if(iRet != 0)
    {
		SF_ELOG("video packet send udp error!iRet:%d",iRet);
        return iRet;
    }

    iRet = unpackJceVideoComm(rcv_buf, buf_size, mHeader);
    if(iRet != 0)
    {
		SF_ELOG("video packet decode error!iRet:%d",iRet);
        return DECODE_ERROR;
    }

	iRet = jceUnPack<jceRsp>(mHeader.body, stRsp);
	if(iRet < 0)
	{
		SF_ELOG("video packet decode error!iRet:%d",iRet);
        return DECODE_ERROR;
    }

    return iRet;
}

template<typename jceReq, typename jceRsp>
int JceUdpDataModel<jceReq, jceRsp>::access_jce_udp(uint32_t modid, uint32_t cmdid, string &defaultIP, uint32_t defaultPort, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;
    iRet = l_l5_factory.getHostAndPort(modid, cmdid, ip, port);
    
    if(iRet != 0)
    {
        SF_ELOG("GET HOST ERROR! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(),port);
		if(defaultIP != "" && defaultPort != 0)
		{
			ip = defaultIP;
			port = defaultPort;
			SF_ELOG("GET HOST ERROR! use defaultIP:%s\tport:%d",iRet, ip.c_str(),port);
		}
		else
		{
        	return GET_HOST_ERROR;
		}
    }
	mConnInfo.setDestIP(ip, port);
    iRet = access_jce_udp(ip, port, stReq, stRsp, mHeader, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
    	l_l5_factory.uploadResult(iRet);
    }
    return iRet;
}

template<typename jceReq, typename jceRsp>
int JceTcpDataModel<jceReq, jceRsp>::access_jce_tcp(string &ip, uint32_t port, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;

	char *buf = NULL;
	char *rcv_buf = NULL;
	int len = mBufMaxLen;
	int buf_size = mBufMaxLen;
	GET_BUFFER(mBufMaxLen, buf, rcv_buf)

	iRet = jcePack<jceReq>(stReq, mHeader.body);
	if(iRet < 0)
	{
        SF_ELOG("video packet encode error!iRet:%d",iRet);
        return ENCODE_ERROR;
    }

	iRet = packJceVideoComm(buf, len, mHeader);
	if(iRet != 0)
    {
        SF_ELOG("video packet encode error!iRet:%d",iRet);
        return ENCODE_ERROR;
    }
	
	iRet = mt_access_tcp(ip, port, (char*)buf, len, rcv_buf, buf_size, videoPacketComplete, mTimeOut);
    if(iRet != 0)
    {
		SF_ELOG("video packet send tcp error!iRet:%d",iRet);
        return iRet;
    }

	iRet = unpackJceVideoComm(rcv_buf, buf_size, mHeader);
    if(iRet != 0)
    {
        SF_ELOG("video packet decode error!iRet:%d",iRet);
        return DECODE_ERROR;
    }

	iRet = jceUnPack<jceRsp>(mHeader.body, stRsp);
	if(iRet < 0)
	{
        SF_ELOG("video packet decode error!iRet:%d",iRet);
        return DECODE_ERROR;
    }
    
    return iRet;
}

template<typename jceReq, typename jceRsp>
int JceTcpDataModel<jceReq, jceRsp>::access_jce_tcp(uint32_t mModid, uint32_t mCmdid, string &defaultIP, uint32_t defaultPort, const jceReq& stReq, jceRsp& stRsp, videocomm::VideoCommHeader &mHeader,
                                int mTimeOut, int mBufMaxLen)
{
	int iRet = 0;
    
    string ip;
    uint32_t port = 0;

    l5_factory l_l5_factory;
    iRet = l_l5_factory.getHostAndPort(mModid, mCmdid, ip, port);
    
    if(iRet != 0)
    {
        SF_ELOG("GET HOST ERROR! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(),port);
		if(defaultIP != "" && defaultPort != 0)
		{
			ip = defaultIP;
			port = defaultPort;
			SF_ELOG("GET HOST ERROR! use defaultIP:%s\tport:%d",iRet, ip.c_str(),port);
		}
		else
		{
        	return GET_HOST_ERROR;
		}
    }
	mConnInfo.setDestIP(ip, port);
    iRet = access_jce_tcp(ip, port, stReq, stRsp, mHeader, mTimeOut, mBufMaxLen);
    if(mReportL5 == true)
    {
    	l_l5_factory.uploadResult(iRet);
    }

    return iRet;
}

#endif
