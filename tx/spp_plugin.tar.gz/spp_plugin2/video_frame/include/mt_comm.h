#ifndef _MT_COMM_H_
#define _MT_COMM_H_
#include <string>
#include <vector>

extern "C" 
{
	int spp_handle_init(void* arg1, void* arg2);
	int spp_handle_input(unsigned flow, void* arg1, void* arg2);
	int spp_handle_route(unsigned flow, void* arg1, void* arg2);
	int spp_handle_process(unsigned flow, void* arg1, void* arg2);
	void spp_handle_fini(void* arg1, void* arg2);

	typedef int (*func_spp1)(void* arg1, void* arg2);
	typedef int (*func_spp2)(unsigned flow, void* arg1, void* arg2);
	typedef void (*func_spp3)(void* arg1, void* arg2);
};


#ifdef _MT_LOG_		//define _MT_LOG_ in makefile to show log 
/*
#ifndef SF_LOG//(lvl, fmt, args...) 
#define SF_LOG(lvl, fmt, args...)                                           \
do {                                                                        \
    register CServerBase *base = CSyncFrame::Instance()->GetServerBase();   \
    if ((base) && (lvl >= base->log_.log_level(-1))) {                      \
        base->log_.LOG_P_ALL(lvl, fmt"\n", ##args);                         \
    }                                                                       \
} while (0)
#endif*/

#ifndef SF_DLOG
#define SF_DLOG(fmt, args...)                                           \
do {																		\
	register CServerBase *base = CSyncFrame::Instance()->GetServerBase();	\
	if (base) {						\
		base->log_.LOG_P_ALL(LOG_DEBUG, fmt"\n", ##args); 						\
	}																		\
} while (0)
#endif

#ifndef SF_ELOG
#define SF_ELOG(fmt, args...)     \
		do {																		\
			register CServerBase *base = CSyncFrame::Instance()->GetServerBase();	\
			if (base) {						\
				base->log_.LOG_P_ALL(LOG_ERROR, fmt"\n", ##args); 						\
			}																		\
		} while (0)	
#endif

#else

/*

#ifndef SF_LOG//(lvl, fmt, args...) 
#define SF_LOG(lvl, fmt, args...)                                           \
	do {} while (0) 
#endif
*/
#ifndef SF_DLOG
#define SF_DLOG(fmt, args...)                                           \
	do {} while (0)
#endif

#ifndef SF_ELOG
#define SF_ELOG(fmt, args...)     \
	do {} while (0)
#endif


#endif



#ifndef SF_NLOG
#define SF_NLOG(fmt, args...)                                           \
do {} while (0);
#endif


typedef void (*MT_INIT_LOG)(const std::string& configFile);
typedef void (*MT_DESTROY_LOG)();


extern std::vector<MT_INIT_LOG> * g_pLogInitList;
extern std::vector<MT_DESTROY_LOG> * g_pLogDestroyList;

#ifndef REG_LOG_FUNC
#define REG_LOG_FUNC(init_func, destroy_func)   		\
	if(g_pLogInitList == NULL)							\
	{													\
		g_pLogInitList = new std::vector<MT_INIT_LOG>;	\
	}													\
	g_pLogInitList->push_back(init_func);				\
	if(g_pLogDestroyList == NULL)						\
	{	                                                \
		g_pLogDestroyList = new std::vector<MT_DESTROY_LOG>;	\
	}	                                                \
	g_pLogDestroyList->push_back(destroy_func);
#endif

class log_register
{
public:
	log_register(MT_INIT_LOG init_func, MT_DESTROY_LOG destroy_func)
	{
		REG_LOG_FUNC(init_func, destroy_func);
	}
};

void log_init(const std::string& configFile);
void log_destroy();

enum ERROR_NO
{
	JCE_UNPACK_ERROR	=	-1000,
	JCE_PACK_ERROR		= 	-1001,
	JCE_COMPLETE_ERROR	=	-1002,
	UNPACK_JCE_VIDEO_COMM	=	-1003,
	CSPACKET_COMPLETE_ERROR	=	-1004,
	VIDEO_PACKET_HEAD_ENCODE_ERROR	=	-1005,
	VIDEO_PACKET_HEAD_DECODE_ERROR	=	-1006,
	
	
	GET_HOST_ERROR	=	-10000,
	ENCODE_ERROR	=	-10001,
	DECODE_ERROR	=	-10002,
	REQ_SIZE_ZERO	=	-10003,
	
	SERVICE_CMD_FUNC_NOT_FIND	=	-60000,
	SERVICE_EXE_FUNC_ERROR		=	-60001,
	SERVICE_ENCODE_PACKET_ERROR	=	-60002,
	SERVICE_DECODE_PACKET_ERROR	=	-60003,
	SERVICE_NOT_HANDLE_PACKET	=	-60004,
	SERVICE_NO_TASK_EXEC		=	-60005,
	MSG_TIME_OUT				=	-60006,	

	MT_COMPLETE_NULL	=	-70000,		//包完整性检查函数为空
};

#endif



