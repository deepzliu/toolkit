#ifndef _MT_HELLO_REDIS_H_
#define _MT_HELLO_REDIS_H_

#include <string>
#include <vector>
#include <iostream>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
using namespace std;

#define REDIS_REPLY_STRING  1
#define REDIS_REPLY_ARRAY   2
#define REDIS_REPLY_INTEGER 3
#define REDIS_REPLY_NIL     4
#define REDIS_REPLY_STATUS  5
#define REDIS_REPLY_ERROR   6

struct RedisCommand
{
    string cmd;
	string key;
	vector<string> extkey;
};

#define REDIS_BR        "\r\n"

namespace helloredis
{
    class DataUnit
    {
    public:
        DataUnit() : m_type(0), m_intdata(0), m_stringdata("")
        {}
        ~DataUnit()
        {}
		
		int getType() const
		{
			return m_type;
		}

		int64_t getIntValue() const
		{
			return m_intdata;
		}

		const string &getStrValue()
		{
			return m_stringdata;
		}
		
        int m_type;
        int64_t m_intdata;	//64bit int value
        string m_stringdata;
    };

	int pack(const RedisCommand &redisCommand, char *buffer, int &len);
    int unpack(const char * buffer, int len, vector<DataUnit> &resdata);

} // namespace helloredis

#endif

