#ifndef _MT_JCE_PROTOCOL_H_
#define _MT_JCE_PROTOCOL_H_

#include "mt_comm.h"
#include "VideoCommHead.h"
#include <string>
#include <exception>

using namespace std;

///////////////////////////////////////////////////////////////

typedef int (*MtComplete)(const char * buf, int buflen);

#pragma pack(1)

class VideoFixHead
{
public:
    uint8_t cStx;
    uint32_t uLen;
    uint8_t cVer;
    char cReserved[10];

    VideoFixHead()
        :cStx(0x26)
        ,uLen(0)
        ,cVer(0x01)
    {
        cReserved[0] = '\0';
    }

    int Encode(char * buffer, uint32_t buf_len)
    {
        if(buf_len < sizeof(VideoFixHead))
            return VIDEO_PACKET_HEAD_ENCODE_ERROR;

        *buffer = cStx;
        buffer += sizeof(cStx);
        *((uint32_t *)buffer) = htonl(uLen);
        buffer += sizeof(uLen);
        *buffer = cVer;
        buffer += sizeof(cVer);
        //暂时不支持cReserved
        *buffer = cReserved[0];
        buffer += sizeof(cReserved);
        //外部需要自行移位指针
        return 0;
    }

    int Decode(const char * buffer, uint32_t buf_len)
    {
        if(buf_len < sizeof(VideoFixHead))
            return VIDEO_PACKET_HEAD_DECODE_ERROR;
        cStx = *buffer;
        buffer += sizeof(cStx);
        uLen = htonl(*((uint32_t *)buffer));
        buffer += sizeof(uLen);
        cVer = *buffer;
        buffer += sizeof(cVer);
        //暂时不支持cReserved
        return 0;
    }
};

#ifndef JCE_STX
#define JCE_STX 0x26
#endif
#ifndef JCE_ETX
#define JCE_ETX 0x28
#endif

#pragma pack()

static int packJceVideoComm(char * buffer, int & buf_len
                    ,videocomm::VideoCommHeader & curHead)
{
    int ret = 0;
    int curBufLen = buf_len;
    
    taf::JceOutputStream<taf::BufferWriter> osJce; 
	curHead.writeTo(osJce);

    //VideoFixHead
    VideoFixHead curFixHead;
    curFixHead.uLen = osJce.getLength() + sizeof(curFixHead) + 1;
    if(curBufLen < static_cast<int>(curFixHead.uLen) )
        return -10;
    ret = curFixHead.Encode(buffer,curBufLen);
    if(ret != 0)
        return -11;
    buffer += sizeof(curFixHead);

    memcpy(buffer ,osJce.getBuffer(),osJce.getLength());
    buffer += osJce.getLength();

    *buffer = JCE_ETX;
    buffer += 1;

    buf_len = osJce.getLength() + sizeof(curFixHead) + 1;

    return ret;
}
                    
static int unpackJceVideoComm(const char * buffer, int buf_len 
                      ,videocomm::VideoCommHeader & curHead)
{
    int ret = 0;
    try
    {
        VideoFixHead curFixHead;
        ret = curFixHead.Decode(buffer,buf_len);
        if(ret != 0)
            return -10;
        if(buf_len != static_cast<int>(curFixHead.uLen))
            return -11;
            
        buffer += sizeof(curFixHead);
        buf_len -= sizeof(curFixHead);

        taf::JceInputStream<taf::BufferReader> isJce;
        isJce.setBuffer(buffer, buf_len);
        curHead.readFrom(isJce);
    }
    catch(std::exception &e)
    {
        SF_ELOG("%d\t%s", buf_len, e.what());
        ret = UNPACK_JCE_VIDEO_COMM;
    }
    return ret;
}

inline int jceComplete(const char * buf, int buflen)
{
    if(buflen <= 0)
        return 0;
    char flag = *buf;
    if(JCE_STX == flag)
    {
        if(buflen < static_cast<int>(sizeof(VideoFixHead)))
            return 0;
        VideoFixHead curFixHead;
        curFixHead.Decode(buf,buflen);
        if(buflen >= static_cast<int>(curFixHead.uLen))
            return curFixHead.uLen;
        return 0;
    }
    else
    {
        return JCE_COMPLETE_ERROR;
    }
    return 0;
}

inline int csPacketComplete(const char * buf, int buflen)
{
    if(buflen <= 0)
        return 0;
    char flag = *buf;
    if(0x0a == flag)
    {
        if(buflen < 2 + 1)
            return 0;
        int packLen = ntohs(*((uint16_t*)(buf + 1)));
        if(packLen < 0)
            return CSPACKET_COMPLETE_ERROR;
        else if(buflen < packLen)
            return 0;
        else 
            return packLen;
    }
    else
    {
        return CSPACKET_COMPLETE_ERROR;
    }
    return 0;
}

template<typename T> 
int jceUnPack(const string & strData, T & curJce)
{
    int ret = 0;
    try
    {
        taf::JceInputStream<taf::BufferReader> isJce;
        isJce.setBuffer(strData.c_str(), strData.size());
        curJce.readFrom(isJce);
    }
    catch(std::exception & e)
    {
        ret = JCE_UNPACK_ERROR;    
    }
    return ret;
}

template<typename T>
int jcePack(const T & curJce, string & strData)
{
    int ret = 0;
    try
    {
        taf::JceOutputStream<taf::BufferWriter> osJce; 
    	curJce.writeTo(osJce);
    	strData.assign(osJce.getBuffer(),osJce.getLength());
    }
    catch(std::exception & e)
    {
        ret = JCE_PACK_ERROR;    
    }
    return ret;
}

#endif


