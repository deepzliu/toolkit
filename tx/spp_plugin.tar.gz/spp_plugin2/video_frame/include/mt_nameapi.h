#ifndef _MT_NAME_API_H__
#define _MT_NAME_API_H__

//created by ronniechen 2011-2-12
//version 4.0    2011-06-06
#ifdef __cplusplus
extern "C" {
#endif

enum{
	ZKNAMES_API_UNPACK_ERR = -105,
	ZKNAMES_API_PARAM_ERR = -104,
	ZKNAMES_API_RECV_ERR = -103,
	ZKNAMES_API_SEND_ERR = -102,
	ZKNAMES_API_CONN_ERR = -101
};

typedef struct
{                       
        char ip[40];            
        unsigned short port;             
}ZkHost;  

/*
function int getHostByKey(const char* key, ZkHost* host)
param key: key name
param host:  host info
return Value: 
	0: success
	-1: the key configured empty value on this machine
	-2: get value from zk server failed
	-3: the key configures content parse error
	-4: param error
	-5: conflict when first access
*/

int getHostByKey(const char* key, ZkHost* host);

int getHostByKey2(const char* key, ZkHost* host , const char *ip);

/*
function int getValueByKey(const char* key, char* value)
param key: key name
param value:  value, max length=1K
param value_len: value buffer length 
return Value: 
	0: success
	-1: the key configured empty value on this machine
	-2: get value from zk server failed
	-3: the key configures content parse error
	-4: param error
	-5: conflict when first access
*/

int getValueByKey(const char* key, char* value, int value_len);

int getValueByKey2(int id, const char* key, char* value, int value_len);

#ifdef __cplusplus
}
#endif

#endif
