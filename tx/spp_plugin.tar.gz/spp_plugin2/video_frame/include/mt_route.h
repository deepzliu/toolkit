#ifndef _MT_ROUTE_H_
#define _MT_ROUTE_H_

#include <string>
#include <sys/time.h>
#include <map>
#include "mt_qos_client.h"
#include "mt_nameapi.h"

using namespace std;

class l5_factory
{
public:
    int getHostAndPort(const uint32_t modid,const uint32_t cmdid
                      ,std::string & str_host,uint32_t & port);


    int uploadResult(int err_no);

protected:

    struct timeval mStartTime;

    QOSREQUEST m_stQosReq;
};

struct ZkItem
{
    ZkItem()
        :port(0)
        ,loopCount(0)
    {
    
    }
    string zkname;
    string strip;
    int port;
    uint32_t loopCount;
};

extern map<string , ZkItem> g_zkCache;

int getHostByZkName(const string &zkname,string & strip,uint32_t & port);


#endif


