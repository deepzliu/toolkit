#ifndef _MT_SPP_MSG_H_
#define _MT_SPP_MSG_H_

#include <map>
#include "syncincl.h"
#include "mt_comm.h"
#include "mt_task_base.h"
#include "mt_jce_protocol.h"
#include "cs_packet2.h"

#define CREATE_MSG(msg_name)                    \
spp_msg* createMsg()				            \
{									            \
	msg_name *msg = new msg_name;	            \
	return msg;						            \
}                                               \
func_spp1 spp_init = &spp_handle_init;          \
func_spp3 spp_fini = &spp_handle_fini;          \
func_spp2 spp_input = &spp_handle_input;        \
func_spp2 spp_process = &spp_handle_process;

typedef int (*WorkFini)();

class spp_msg ;
typedef int (*JceFunc)(spp_msg * curMsg, const string& sReqBody, string & sRspBody);

class spp_msg : public CommMsg 
{
public:
    spp_msg()
    :mCmd(0)
    ,mNoResponse(false) //默认需要回包,业务可以自行回包，设置成true
    {
		//默认消息超时700ms
    	this->SetMsgTimeout(700);
    }

    /**
     * @brief 同步消息处理函数
     * @return 0, 成功-用户自己回包到前端,框架不负责回包处理
     *         其它, 失败-框架关闭与proxy连接, 但不负责回业务报文
     */
    virtual int HandleProcess()
    {
	    int iRet = 0;

	    //unpack the packet, get the command and type of packet(cs packet or common video packet)
	    iRet = process_unpack(this->GetReqPkg(), mCmd);
	    if(iRet < 0)
	    {
	        SF_ELOG("process_unpack error! iRet:%d", iRet);
	        return SERVICE_DECODE_PACKET_ERROR;
	    }

	    //logic process
	    string strRsp;
	    iRet = dispatch_cmd(mCmd, mHeader.body, strRsp);
	    if(iRet != 0)
	    {
	        SF_ELOG("dispatch CMD exec error! CMD:%d", mCmd);
	        return SERVICE_EXE_FUNC_ERROR;
	    }

		//pack the packet
		iRet = process_pack(strRsp);
		if(iRet != 0)
	    {
	        SF_ELOG("process_pack error! iRet:%d", iRet);
	        return SERVICE_ENCODE_PACKET_ERROR;;
	    }
	    
    	return 0;
	}

    int dispatch_cmd(uint32_t cmd ,const string &sReqBody, string & sRspBody)
    {
	    int iRet = 0;
	    map<uint32_t ,JceFunc >::iterator iter = mFuncList.find(cmd);
	    if(iter != mFuncList.end())
	    {
	        iRet = (*(iter->second))(this, sReqBody, sRspBody);
	    }
	    else
	    {
	        SF_ELOG("Not find command's func!");
	        return SERVICE_CMD_FUNC_NOT_FIND;
	    }
	    return iRet;
    }

	virtual int process_unpack(const std::string &strReqBuff, uint32_t &curCmd)
	{
		int iRet = 0;
		if(strReqBuff.size() == 0)
		{
			SF_ELOG("the req size is zero");
			return -1;
		}
		char pflag = *(strReqBuff.c_str());
	
		if(pflag == 0x0a)
		{
			//cs packet
			CCsPacket stCsPkg;
			stCsPkg.set_packet((uint8_t *)strReqBuff.c_str(),strReqBuff.size());
			iRet = stCsPkg.decode();
			if(iRet != 0)
			{
				SF_ELOG("csPackage decode error!iRet:%d", iRet);
				return iRet;
			}
			iRet = unpackJceVideoComm((const char*)stCsPkg.getBody(), stCsPkg.getBodyLen(), mHeader);
			mNoResponse = true;
			blob_type blob;    
			blob.data = NULL;
			blob.len  = 0;
			this->SendToClient(blob);
		}
		else if(pflag == 0x26)
		{
			//jce packet
			iRet = unpackJceVideoComm(strReqBuff.c_str(), strReqBuff.size(), mHeader);
			mNoResponse = false;
		}
		else 
		{
			SF_ELOG("this frame can not handle this packet! pflag:%c", pflag);
			return SERVICE_NOT_HANDLE_PACKET;
		}
		
		if(iRet < 0)
		{
			SF_ELOG("unpack jce video comm error!iRet:%d", iRet);
			return iRet;
		}
		
		curCmd = (uint16_t)mHeader.BasicInfo.Command;
		if(curCmd == 0)
			curCmd = mHeader.BasicInfo.SubCmd;
		
		return iRet;
	}

	virtual int process_pack(const std::string &strRsp)
	{
		int iRet = 0;
		if(mNoResponse == false)
	    {
		    mHeader.body = strRsp;

		    static char buffer[BUF_LEN_MAX];
		    int buf_len = sizeof(buffer);
		    iRet= packJceVideoComm(buffer,buf_len, mHeader);
		    if(iRet < 0)
		    {
		        return SERVICE_ENCODE_PACKET_ERROR;
		    }

	        blob_type blob;    
	        blob.data = buffer;
	        blob.len  = buf_len;
	        this->SendToClient(blob);
	    }
		return iRet;
	}

public:
    uint32_t mCmd;
	videocomm::VideoCommHeader mHeader;
	bool mNoResponse;
};

class BaseFunctor
{

public:
    BaseFunctor(uint32_t cmd, JceFunc func)
    {
        spp_msg::mFuncList[cmd] = func;
    }
};


#ifndef _BEGIN_DO_WHILE_FLASE_
#define _BEGIN_DO_WHILE_FLASE_  do{
#define _END_DO_WHILE_FALSE_    }while(false);
#endif

#endif

