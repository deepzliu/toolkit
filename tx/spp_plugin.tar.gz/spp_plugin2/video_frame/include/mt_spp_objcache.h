#ifndef _MT_SPP_OBJ_CACHE_H_
#define _MT_SPP_OBJ_CACHE_H_

#include <map>
#include <deque>
#include "tc_autoptr.h"
#include "bossapi.h"

using namespace std;

enum CONNECT_TYPE
{
	L5_TYPE		=	1,
	ZKNAME_TYPE	=	2,
	IP_PORT_TYPE	=	3,
};

#ifndef BUF_LEN_MAX
#define BUF_LEN_MAX 1048576
#endif

#ifndef BUF_LEN_DEFAULT
#define BUF_LEN_DEFAULT 30720
#endif

#ifndef TIME_OUT_DEFAULT
#define TIME_OUT_DEFAULT 300
#endif

class ConnectInfo
{
public:

	ConnectInfo():mType(IP_PORT_TYPE),mModid(0),mCmdid(0),mZkname(""),mIP(""),mPort(0){}
	
	void getL5(uint32_t &modid, uint32_t &cmdid)
	{
		modid = mModid;
		cmdid = mCmdid;
	}
	
	void getZkname(string &zkname)
	{
		zkname = mZkname;
	}

	void getIP(string &ip, uint32_t &port)
	{
		ip = mIP;
		port = mPort;
	}

	void setDestIP(string &ip, uint32_t &port)
	{
		mIP = ip;
		mPort = port;
	}

	string getDestIP()
	{
		return mIP;
	}

	uint32_t getDestPort()
	{
		return mPort;
	}

	string toStr()
	{
		char strConnInfo[256];
		if(mType == L5_TYPE)
			snprintf(strConnInfo, sizeof(strConnInfo), "L5[%d,%d]-->[%s:%d]", mModid, mCmdid, mIP.c_str(), mPort);
		else if(mType == ZKNAME_TYPE)
			snprintf(strConnInfo, sizeof(strConnInfo), "ZKNAME[%s]-->[%s:%d]", mZkname.c_str(), mIP.c_str(), mPort);
		else if(mType == IP_PORT_TYPE)
			snprintf(strConnInfo, sizeof(strConnInfo), "IP_PORT[%s:%d]", mIP.c_str(), mPort);
		return string(strConnInfo);
	}
	
	CONNECT_TYPE mType;
	uint32_t mModid;
	uint32_t mCmdid;
	string mZkname;
	string mIP;
	uint32_t mPort;
};


class BaseDataModel : virtual public taf::TC_HandleBase
{
public:
    BaseDataModel()
        :mTimeOut(TIME_OUT_DEFAULT),mBufMaxLen(BUF_LEN_DEFAULT),mResult(-1),mCostTime(0),mInCache(0),
        	mRecordTimeout(true),mReportL5(false),mInitModuleId(0),mInitInterfaceId(0),mPassiveModuleId(0),mPassiveInterfaceId(0)
    {}	
	
	virtual int RealProcess() = 0;
	
	int Process()
	{ 
		if(mRecordTimeout)
    	{
			gettimeofday(&mStartTime,NULL);
		}

	    int iRet = RealProcess();

		if(mRecordTimeout)
		{
			gettimeofday(&mEndTime, NULL);																				 
			mCostTime = (mEndTime.tv_sec - mStartTime.tv_sec) * 1000 + (mEndTime.tv_usec - mStartTime.tv_usec) / 1000;
		}
		return iRet;
	}

	//初始化和启动模调
	void initModCall(int initModuleId, int initInterfaceId, int passiveModuleId, int passiveInterfaceId)
	{
		mInitModuleId = initModuleId;
		mInitInterfaceId = initInterfaceId;
		mPassiveModuleId = passiveModuleId;
		mPassiveInterfaceId = passiveInterfaceId;
		if(mRecordTimeout)
    	{
			gettimeofday(&mStartTime,NULL);
		}
	}

	//上报模调错误码
	void endModCall(int iRet)
	{
		if(mRecordTimeout && 0 == mEndTime.tv_sec) //兼容不执行mt_access的场景
		{
			if(mRecordTimeout)
			{
				gettimeofday(&mEndTime, NULL);																				 
				mCostTime = (mEndTime.tv_sec - mStartTime.tv_sec) * 1000 + (mEndTime.tv_usec - mStartTime.tv_usec) / 1000;
			}
		}
		
		MODCALL_INIT_REPORT(mInitModuleId, mInitInterfaceId, mPassiveModuleId, mPassiveInterfaceId,mCostTime*1000, iRet, mConnInfo.mIP)
	}

    int getResult()
	{
		return mResult;
	}

	//单位为ms
	uint32_t getCostTime()
	{
		return mCostTime;
	}

	void openTimeOut()
	{
		mRecordTimeout = true;
	}
	
	//关闭网络操作计时，默认为打开模式
	void closeTimeOut()
	{
		mRecordTimeout = false;
	}
	
	//打开上报L5
	void openReportL5()
	{
		mReportL5 = true;
	}
	
	//关闭上报L5
	void closeReportL5()
	{
		mReportL5 = false;
	}
	
    virtual string GetModelType() const = 0;

	void setL5(uint32_t modid, uint32_t cmdid)
	{
		mConnInfo.mType = L5_TYPE;
		mConnInfo.mModid = modid;
		mConnInfo.mCmdid = cmdid;
	}

	void setL5(uint32_t modid, uint32_t cmdid, string &defaultIP, uint32_t defaultPort)
	{
		mConnInfo.mType = L5_TYPE;
		mConnInfo.mModid = modid;
		mConnInfo.mCmdid = cmdid;

		mConnInfo.mIP = defaultIP;
		mConnInfo.mPort = defaultPort;

		mReportL5 = true;		
	}
	
	void setZkname(const string &zkname)
	{
		mConnInfo.mType = ZKNAME_TYPE;
		mConnInfo.mZkname = zkname;
	}
	
	void setIP(const string &ip, uint32_t port)
	{
		mConnInfo.mType = IP_PORT_TYPE;
		mConnInfo.mIP = ip;
		mConnInfo.mPort = port;
	}

	void setTimeOut(int timeout)
	{
		mTimeOut = timeout;
	}

	void setBufMaxLen(int len)
	{
		mBufMaxLen = len;
	}

	ConnectInfo getConnInfo()
	{
		return mConnInfo;
	}

	void setCtx(const string &strCtx)
	{
		mCtx = strCtx;
	}

	string getCtx()
	{
		return mCtx;
	}
	
	ConnectInfo mConnInfo;
	int mTimeOut;
	int mBufMaxLen;
	int mResult;
	struct timeval mStartTime;	
	struct timeval mEndTime;	
    uint32_t mCostTime;
	
    string mCtx;
    volatile int mInCache ;//1:in cache;0:out cache
    bool mRecordTimeout; //default open
    bool mReportL5;	//default open

	//BossAPI::CModCacheApi mMasterCaller;
	int mInitModuleId;		//master caller module id
	int mInitInterfaceId;	//master caller interface id
	int mPassiveModuleId;	//passive caller module id
	int mPassiveInterfaceId;	//passive caller interface id
}; 


typedef taf::TC_AutoPtr<BaseDataModel> BaseDataModelPtr;


#define OBJ_CACHE_MAX_COUNT     1500
extern bool mt_g_objcache_flag;

class ObjCache 
{
public :
    void push(BaseDataModelPtr curModel)
    {
		if(mt_g_objcache_flag == false)
			return;

			
        if(!curModel)
            return;
        if(curModel->mInCache == 1)
            return ;
        curModel->mInCache = 1;
        string typeStr = curModel->GetModelType();
        if(typeStr == "")
            return;
        map<string, std::deque<BaseDataModelPtr> >::iterator iter = mTypeQueue.find(typeStr);
        if(iter == mTypeQueue.end())
        {
            std::deque<BaseDataModelPtr> curDeque;
            curDeque.push_back(curModel);
            mTypeQueue.insert(make_pair<string, std::deque<BaseDataModelPtr> >(typeStr, curDeque));
        }
        else
        {
            if(iter->second.size() > OBJ_CACHE_MAX_COUNT)
                return ;
            iter->second.push_back(curModel);
        }
    }

    BaseDataModelPtr pop(string typeStr)
    {
        BaseDataModelPtr retPtr;

		if(mt_g_objcache_flag == false)
			return retPtr;
		
        if(typeStr == "")
            return retPtr;
        map<string, std::deque<BaseDataModelPtr> >::iterator iter = mTypeQueue.find(typeStr);
        if(iter != mTypeQueue.end() && iter->second.size() > 0)
        {
            retPtr = iter->second.front();
            iter->second.pop_front();
        }
        if(retPtr)
            retPtr->mInCache = 0;
        return retPtr;
    }

protected:
    map<string, std::deque<BaseDataModelPtr> > mTypeQueue; 
};

extern ObjCache g_ObjCache;

template<typename SMART_T>
class creater
{
public :

    typedef typename SMART_T::element_type SRC_TYPE;

    SMART_T operator()()
    {
        SMART_T retT;
        SRC_TYPE tmpSrc;
        BaseDataModelPtr curInfo = g_ObjCache.pop(tmpSrc.GetModelType());
        if(curInfo)
        {
            SRC_TYPE * srcPtr = (SRC_TYPE *)curInfo.get();
            *srcPtr = tmpSrc;
            retT = SMART_T::dynamicCast(curInfo);
        }
        else
        {
            retT = new SRC_TYPE;
        }
        return retT;
    }

    SMART_T operator()(const string & mType)
    {
        SMART_T retT;
        //SRC_TYPE tmpSrc;
        BaseDataModelPtr curInfo = g_ObjCache.pop(mType);
        if(curInfo)
        {
        //    SRC_TYPE * srcPtr = (SRC_TYPE *)curInfo.get();
            //*srcPtr = tmpSrc;
            retT = SMART_T::dynamicCast(curInfo);
        }
        else
        {
            retT = new SRC_TYPE;
        }
        return retT;
    }
};

#include <map>
#include <stdint.h>
#include "syncincl.h"

class spp_msg ;
typedef int (*JceFunc)(spp_msg * curMsg, const string& sReqBody, string & sRspBody);


class CommMsg : public CSyncMsg
{
public:
    CommMsg()
        :mRemoteIP(0)
        ,mRemotePort(0)
    {
    }
    

public:
    uint32_t mRemoteIP;
	uint16_t mRemotePort;
	
public:
    static map<uint32_t ,JceFunc > mFuncList;
};


#endif



