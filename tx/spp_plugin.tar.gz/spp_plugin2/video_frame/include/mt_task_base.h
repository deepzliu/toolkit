#ifndef _MT_TASK_BASE_H_
#define _MT_TASK_BASE_H_

#include "syncincl.h"
#include "mt_spp_objcache.h"
#include "mt_route.h"
#include "mt_spp_msg.h"
#include "mt_jce_protocol.h"

class CommonTask : public NS_MICRO_THREAD::IMtTask
{
public:
	int Process()
	{
		int iRet = 0;
		if(basePtr == NULL)
		{
			SF_ELOG("baseDataModelPtr is null");
			return -1;
		}
		iRet = basePtr->Process();
		SetResult(iRet);
		SF_DLOG("modelType:%s[ctx:%s]\tconnInfo:%s\tret:%d\tcost:%u", basePtr->GetModelType().c_str(), basePtr->getCtx().c_str(), basePtr->getConnInfo().toStr().c_str(), iRet, basePtr->getCostTime());
		if(iRet != 0)
		{
			SF_ELOG("modelType:%s[ctx:%s]\tconnInfo:%s\tret:%d\tcost:%u", basePtr->GetModelType().c_str(), basePtr->getCtx().c_str(), basePtr->getConnInfo().toStr().c_str(), iRet, basePtr->getCostTime());
		}
		return iRet;
	}
	BaseDataModelPtr basePtr;
};


class TaskList  
{
public:
    void push_back(BaseDataModelPtr basePtr)
    {
        CommonTask taskitem;
		if(!basePtr)
			return;
        taskitem.basePtr = basePtr;
        mtasklist.push_back(taskitem);
    }

    virtual ~TaskList()
    {
        for(vector<CommonTask>::iterator iter = mtasklist.begin();
            iter != mtasklist.end();iter++)
        {
            g_ObjCache.push(iter->basePtr);
        }
        mtasklist.clear();
    }

    void clear()
    {
        for(vector<CommonTask>::iterator iter = mtasklist.begin();
            iter != mtasklist.end();iter++)
        {
            g_ObjCache.push(iter->basePtr);
        }
        mtasklist.clear();
    }

    vector<CommonTask> & getlist() 
    {
        return mtasklist;
    }
    
protected:
    vector<CommonTask> mtasklist;
};


#endif



