#include "mt_comm.h"
#include "mt_task_base.h"

using namespace NS_MICRO_THREAD;
bool mt_g_objcache_flag = true;

int multi_access(vector<CommonTask> &vec_task)
{
    int iRet = 0;
    size_t iSize = vec_task.size();
    
    if(iSize == 0)
    {
        SF_ELOG("NO TASK EXEC!");
        return SERVICE_NO_TASK_EXEC;
    }
    
    if(iSize == 1)
    {
        return vec_task[0].Process();
    }
    
	vector<IMtTask*> task_list;
	for(size_t i = 0; i < iSize; i++)
	{
		task_list.push_back(&vec_task[i]);
	}
    
	iRet = mt_exec_all_task(task_list);
    if(iRet != 0)
    {
        SF_ELOG("MT_EXEC_ALL_TASK ERROR!iRet:%d", iRet);
        return iRet;
    }
    return iRet;
}

int mt_access(TaskList & tasklist, spp_msg* curMsg)
{
    if(curMsg)
    {
        if(curMsg->CheckMsgTimeout())   //检查消息是否超时
        {
            SF_ELOG("msg time out! costTime:%d", curMsg->GetMsgCost());
            return MSG_TIME_OUT;
        }
    }
    return multi_access(tasklist.getlist());
}

extern int g_worker;

//获取当前进程类型
int mt_get_servertype()
{
    if(g_worker == 1)
    {
        return SERVER_TYPE_WORKER;
    }
    else
    {
        return SERVER_TYPE_PROXY;
    }
}

void mt_set_objcache(bool flag)
{
    mt_g_objcache_flag = flag;
}



