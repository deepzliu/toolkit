#include "mt_access_base.h"

using namespace NS_MICRO_THREAD;

int mt_access_tcp(const string &ip, uint32_t port, const char* req, int reqLen, char* rsp, int &rspLen,
                                MtFuncTcpMsgLen checkComplete, int timeout)
{
    int iRet = 0; 
    
    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip.c_str());
    dst.sin_port = htons(port);
    
    iRet = mt_tcpsendrcv(&dst, (char*)req, reqLen, (char*)rsp, rspLen, timeout, checkComplete);
   
    return iRet;
}


int mt_access_udp(const string &ip, uint32_t port, const char* req, int reqLen, char* rsp, int &rspLen, int timeout)
{
    int iRet = 0; 

    struct sockaddr_in dst;
    dst.sin_family = AF_INET;
    dst.sin_addr.s_addr = inet_addr(ip.c_str());
    dst.sin_port = htons(port);
    
    iRet = mt_udpsendrcv(&dst, (char*)req, reqLen, (char*)rsp, rspLen, timeout);
   
    return iRet;
}


