#include "mt_access_base.h"
#include "mt_access_redis.h"
#include "mt_helloredis.h"

using namespace helloredis;
using namespace NS_MICRO_THREAD;

static int redisLen(const char * buffer, int len)
{
	int ret = 0;
    
    if(len == 0)
        return 0;
    if(len < 0)
        return -1;
    
	char firstchar = *buffer;
	if(firstchar == '+' || firstchar == '-' || firstchar == ':')
	{
		const char * pstr = strstr(buffer + 1, REDIS_BR);
		if(pstr == NULL)
			return 0;
		int endpos = pstr - (buffer + 1);
		int packetLen = 1 + endpos + 2;
		return packetLen;
	}
	else if(firstchar == '$')
	{
		const char * pstr = strstr(buffer + 1, REDIS_BR);
		if(pstr == NULL)
			return 0;
		string strLen;
		strLen.assign(buffer + 1, pstr);
		int bulkLen = atoi(strLen.c_str());

		int packetLen = 0;
		if(bulkLen == -1)
		{
			packetLen = 1 + 2 + 2;
		}
		else 
		{
			packetLen = 1 + strLen.size() + 2 + bulkLen + 2;
		}
		return packetLen;
	}
	else if(firstchar == '*')
	{
		const char * pstr = strstr(buffer + 1, REDIS_BR);
		if(pstr == NULL)
			return 0;
		string strBulkCount;
		strBulkCount.assign(buffer + 1, pstr);
		int bulkCount = atoi(strBulkCount.c_str());
		int packetLen = 0;
		if(bulkCount == -1)
		{
			packetLen = 1 + 2 + 2;
		}
		else
		{
			buffer += 1 + strBulkCount.size() + 2;
			len -= (1 + strBulkCount.size() + 2);
			packetLen += 1 + strBulkCount.size() + 2;

			for(int i = 0;i < bulkCount;i++)
			{
				int bulkLen = redisLen(buffer,len);
                if(bulkLen > 1024000)
                {
                    //SF_ELOG(">1024k len:%d, packetLen:%d, bulkLen:%d",len, packetLen, bulkLen);
                }
				if(bulkLen <= 0)
				{   
                    if(bulkLen < 0)
                    {
                        //SF_ELOG("<0 len:%d, packetLen:%d, bulkLen:%d",len, packetLen, bulkLen);
                    }
					return 0;
				}
				else 
				{
					packetLen += bulkLen;
					buffer += bulkLen;
					len -= bulkLen;
				}
			}
		}
		return packetLen;
	}

	return ret;
}

static int redisComplete(void * buffer, int len)
{
	int rLen = redisLen((const char*)buffer,len);
    if(rLen < 0)
        return rLen;
    
	if(len >= rLen)
		return rLen;

	return 0;
}

int RedisDataModel::access_redis(const string &ip, uint32_t port, RedisCommand &mCommand, vector<DataUnit> &mResData, int mTimeOut, int mBufMaxLen)
{
    int iRet = 0;
    
    char *buf = NULL;
    char *rcv_buf = NULL;
    GET_BUFFER(mBufMaxLen,buf,rcv_buf)
        
	int len = mBufMaxLen;
	iRet = pack(mCommand, buf, len);
    if(iRet < 0)
    {
        SF_ELOG("pack redis command error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(),port);
        return iRet;
    }
    else if(iRet > 0)
    {
        SF_ELOG("pack redis command error, buffer is not enough! buf_len:%d\tcommand_len:%d\tip:%s\tport:%d",len, iRet, ip.c_str(), port);
        return iRet;
    }

	int buf_size = mBufMaxLen;

    iRet = mt_access_tcp(ip, port, (char*)buf, len, (char*)rcv_buf, buf_size, redisComplete, mTimeOut);
    if(iRet < 0)
    {
        SF_ELOG("tcp mt send to redis error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(),port);
        return iRet;
    }
    
	iRet = unpack(rcv_buf, buf_size, mResData);
    if(iRet < 0)
    {
        SF_ELOG("unpack redis result error! iRet:%d\tip:%s\tport:%d",iRet, ip.c_str(),port);
        return iRet;
    }

	return iRet;
}

int RedisDataModel::access_redis(string &zkname, RedisCommand &mCommand, vector<DataUnit> &mResData, int mTimeOut, int mBufMaxLen)
{
	int iRet = 0;
	string ip;
	uint32_t port = 0;
    iRet = getHostByZkName(zkname, ip, port);
    if(iRet < 0)
    {
        SF_ELOG("get redis host by zkname error! zkname:[%s] iRet:%d\tip:%s\tport:%d", zkname.c_str(), iRet, ip.c_str(),port);
        return GET_HOST_ERROR;
    }
    mConnInfo.setDestIP(ip, port);
    iRet = access_redis(ip, port, mCommand, mResData, mTimeOut, mBufMaxLen);
	return iRet;
}

