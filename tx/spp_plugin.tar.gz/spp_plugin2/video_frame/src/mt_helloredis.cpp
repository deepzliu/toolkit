#include "mt_helloredis.h"
#include <sstream>

namespace helloredis
{
    int pack(const RedisCommand &redisCommand, char *buffer, int &len)
    {
        if(redisCommand.cmd == "")
        {
            return -1;
        }
        ostringstream ostrbuffer;
        ostrbuffer << "*" << redisCommand.extkey.size() + 2<< "\r\n";
        ostrbuffer << "$" << redisCommand.cmd.size() << "\r\n" << redisCommand.cmd << "\r\n";
        ostrbuffer << "$" << redisCommand.key.size() << "\r\n" << redisCommand.key << "\r\n";
        for(vector<string>::const_iterator pstrparam = redisCommand.extkey.begin();
            pstrparam != redisCommand.extkey.end(); ++pstrparam)
        {
            ostrbuffer << "$" << pstrparam->size() << "\r\n" << *pstrparam << "\r\n";
        }
            
        if ((uint32_t)len < ostrbuffer.str().size())
        {
            return ostrbuffer.str().size();
        }
        len = ostrbuffer.str().size();
        memcpy(buffer, ostrbuffer.str().c_str(), len);
        return 0;
    }

    int unpackItem(const  char * buffer, int len, vector<helloredis::DataUnit> & resData)
    {
        if(len <= 0)
            return 0;
        char firstchar = *buffer;
        DataUnit unit;
        if(firstchar == '+' || firstchar == '-')
        {
            //status or error or inter
            const char * pstr = strstr(buffer + 1, REDIS_BR);
            if(pstr == NULL)
                return -__LINE__;
            int endpos = pstr - (buffer + 1);
            int packetLen = 1 + endpos + 2;
            if(firstchar == '+')
                unit.m_type = REDIS_REPLY_STATUS;
            else
                unit.m_type = REDIS_REPLY_ERROR;
            unit.m_stringdata.assign(buffer + 1, pstr);
            resData.push_back(unit);
            return packetLen;
        }
        else if(firstchar == ':')
        {
            //int value
            const char * pstr = strstr(buffer + 1, REDIS_BR);
            if(pstr == NULL)
                return -__LINE__;
            int endpos = pstr - (buffer + 1);
            int packetLen = 1 + endpos + 2;
            string strval;
            strval.assign(buffer + 1 , pstr);
            unit.m_type = REDIS_REPLY_INTEGER;
            unit.m_intdata = atoll(strval.c_str());     //64bit int value
            unit.m_stringdata = strval;                 //save int value to string value too 
            resData.push_back(unit);
            return packetLen;
        }
        else if(firstchar == '$')
        {
            //bulk reply
            const char * pstr = strstr(buffer + 1, REDIS_BR);
            if(pstr == NULL)
                return -__LINE__;
            string strLen;
            strLen.assign(buffer + 1 , pstr);
            int bulkLen = atoi(strLen.c_str());

            int packetLen = 0;
            if(bulkLen == -1)
            {
                packetLen = 1 + 2 + 2;
                string strEmpty("");
                unit.m_type = REDIS_REPLY_NIL;
                unit.m_stringdata = "";
                resData.push_back(unit);
            }
            else 
            {
                packetLen = 1 + strLen.size() + 2 + bulkLen + 2;
                unit.m_type = REDIS_REPLY_STRING;
                unit.m_stringdata.assign(buffer + 1 + strLen.size() + 2, buffer + 1 + strLen.size() + 2 + bulkLen);
                resData.push_back(unit);
            }
            return packetLen;
        }
        else if(firstchar == '*')
        {
            //multi bulk reply
            const char * pstr = strstr(buffer + 1, REDIS_BR);
            if(pstr == NULL)
                return -__LINE__;
            string strBulkCount;
            strBulkCount.assign(buffer + 1, pstr);

            int bulkCount = atoi(strBulkCount.c_str());

            int packetLen = 0;
            if(bulkCount == -1)
            {
                packetLen = 1 + 2 + 2;
            }
            else
            {
                unit.m_type = REDIS_REPLY_ARRAY;
                unit.m_intdata = bulkCount;
                resData.push_back(unit);
                buffer += 1 + strBulkCount.size() + 2;
                len -= (1 + strBulkCount.size() + 2);
                packetLen += 1 + strBulkCount.size() + 2;

                for(int i = 0;i < bulkCount;i++)
                {
                    int bulkLen = unpackItem(buffer,len, resData);
                    if(bulkLen == 0)
                    {
                        return -__LINE__;
                    }
                    else 
                    {
                        packetLen += bulkLen;
                        buffer += bulkLen;
                        len -= bulkLen;
                    }
                }
            }
            return packetLen;
        }
        return 0;
    }

    int unpack(const char * buffer, int len, vector<helloredis::DataUnit> & resData)
    {
        int packetLen = unpackItem(buffer, len, resData);
        if(packetLen <= 0)
        {
            return -__LINE__;
        }
        return 0;
    }
}
