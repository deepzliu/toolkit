#include "mt_route.h"
#include <set>

set<uint64_t> g_l5_init;

int l5_factory::getHostAndPort(const uint32_t modid,const uint32_t cmdid
                      ,std::string & str_host,uint32_t & port)
{
    int ret = 0;
    string errMsg;

    m_stQosReq._modid = modid;
    m_stQosReq._cmd = cmdid;

    uint64_t l5_key = modid;
    l5_key <<= 32;
    l5_key |= cmdid;
    set<uint64_t>::iterator iter = g_l5_init.find(l5_key);
    if(iter == g_l5_init.end())
    {
        ret = ApiInitRoute(modid, cmdid, 200, errMsg);
        if(ret >= 0)
        {
            g_l5_init.insert(l5_key);
        }
    }

    ret = ApiGetRoute(m_stQosReq, 100, errMsg);
    if(ret < 0 || m_stQosReq._host_ip.empty() || m_stQosReq._host_port <= 0)
    {
        return ret;
    }
    
    gettimeofday(&mStartTime,NULL);
    
    str_host = m_stQosReq._host_ip;
    port = m_stQosReq._host_port;
    ret = 0;
    return ret;
}


int l5_factory::uploadResult(int err_no)
{
    int ret = 0;
    if(mStartTime.tv_sec == 0)
        return 0;

    struct timeval endTime;
    gettimeofday(&endTime,NULL);

    uint32_t cost_time = (endTime.tv_sec - mStartTime.tv_sec) * 1000 + (endTime.tv_usec - mStartTime.tv_usec) / 1000; 
    string errMsg;
    ApiRouteResultUpdate(m_stQosReq,err_no,cost_time * 1000,errMsg);

    mStartTime.tv_sec = 0;
    mStartTime.tv_usec = 0;

    return ret;
}


map<string , ZkItem> g_zkCache;



int getHostByZkName(const string &zkname
                    ,string & strip
                    ,uint32_t & port)
{
    int ret = 0;

    map<string , ZkItem>::iterator iter = g_zkCache.find(zkname);
    if(iter != g_zkCache.end() && iter->second.loopCount < 10)
    {
        strip = iter->second.strip;
        port = iter->second.port;
        iter->second.loopCount++;
    }
    else
    {
        ZkHost host;
        ret = getHostByKey(zkname.c_str(),&host);
        string curip = host.ip;
		if(ret == 0 && curip.size() > 0 && host.port > 0 && host.port < 70000)
		{
			strip = host.ip;
			port = host.port;
			ZkItem item;
			item.strip = host.ip;
			item.port = host.port;
			g_zkCache[zkname] = item;
		}
		else
		{
		    return -__LINE__;
		}
    }
    
    return ret;
}

