#ifndef __cache_data_head_proto_H_
#define __cache_data_head_proto_H_

template<typename K, typename V >
struct cache_data_head_proto{
	unsigned int write_time;		// 写入时间
	unsigned int last_read_time; 	// 读入时间
	unsigned short read_times; 		// 最近一次写之后的读次数
	unsigned char rehash_times; 	// hash次数
	unsigned char version;			// 版本, 为0表示还未初始化
	V value_length;					// value的长度
	K key_length;					// key的长度
	char key_value[0];
};

typedef cache_data_head_proto<unsigned int, unsigned int> cache_data_head;
typedef cache_data_head_proto<unsigned int, unsigned int> cache_data_head_32;

#ifndef LONGSIZEOF
#define LONGSIZEOF(n) ( (sizeof(n) + sizeof(long) - 1) & ~(sizeof(long) - 1) ) 
#endif

#ifndef PACKET_SIZE
#define PACKET_SIZE(key_max_length, value_max_length) LONGSIZEOF(sizeof(cache_data_head) + key_max_length + value_max_length)
#endif

#ifndef PACKET_SIZE_32
#define PACKET_SIZE_32(key_max_length, value_max_length) LONGSIZEOF(sizeof(cache_data_head_32) + key_max_length + value_max_length)
#endif

#define size_legal(key_length, value_length, key_max_length, value_max_length)  LONGSIZEOF(sizeof(cache_data_head_32) + key_max_length + value_max_length) >= (key_length) + (value_length)

#endif