
#include "redis_cmd_base.h"
 
using namespace redis_service;
namespace redis_config{
	struct redis_monitor_config
	{				
		vector<long> monitor_success_attr_list;  //操作成功上报
		vector<long> monitor_error_attr_list;	//操作失败上报
		vector<long> monitor_delay_attr_list;	//耗时上报
	};

	struct redis_common_config
	{
		string config_key;  			//会去 ../client/XXX/conf/redis_config.ini 去查这个key的配置。
		vector<string> zkname_list;					
		redis_monitor_config monitor_config;
		vector<redis_judge_policy> redis_judge_type_list; 		//支持多个判决策略顺序使用，前面的如果无法裁决成功就用后面的策略。如果一个都没有，默认使用LAST_BEST。
		vector<int> timeout_list; //超时时间，单位毫秒，不填默认都50。
		int retry_times;				//重试次数，默认是0
	};

	struct read_cache_config
	{
		int	use_cache;			//0就不用cache，1就启用
		long max_key_length;		
		long max_value_length;	
		string cache_key;		//共享内存的key
		long cache_size;		//共享内存大小 单位字节
		long col_count;			//hash线性寻址列表长度
		long row_count;			//hash线性寻址列表个数，小于0会无限尝试hash。最好麻烦设置一个上限。
		long expire_time;	    //cache到期时间(单位秒)，不填就只会在冲突无法解决时才淘汰cache。
	};
	
	struct redis_read_config : public redis_common_config
	{
		read_cache_config cache_config;		//不设置就不启用cache
		long redis_mismatched_attr;			//读发现不一致时monitor上报属性
		long redis_mismatched_cmd;			//读发现不一致时丢中转的命令字，不填就不会发。发包内容是完整的读请求包。
	};
	
	

	struct redis_write_config : public redis_common_config
	{
		int require_judge_result;			//如果设置这个标记为非0，当写没有全部成功时，会进行一次读并检测裁决结果是否和写请求相符。
	};
	
	struct redis_set_config: public redis_write_config{
		
	};
	
	struct redis_get_config: public redis_read_config{
	
	};
	
}