#include  "redis_service_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "Attr_API.h"
#include "redis_del.h"
int redis_service_del(spp_msg* curMsg,const string & curReq, string & curRsp)
{
	mcall reporter;
	
    redis_service_msg * msg = (redis_service_msg *) curMsg;
	
    redis_del_req request;
    redis_del_resp response;
	int ret = jceUnPack<>(curReq, request);
    if(ret < 0){
		ELOG << "jceUnPack Error,ret:" << ret << std::endl;
        return ret;
	}
	request.display(DLOG);
	const string& config_key = request.config_key;
	
	redis_service_error result; 
	redis_common_config*  pconfig = redis_service_msg::getRedisConfig(config_key, result);
	if(result != redis_service::OK){
		response.ret = (int)result;
		response.msg = "Basic config information not found!";
		ELOG_VALUE(response.ret);
		ELOG_VALUE(response.msg);
		ret = jcePack<redis_del_resp>(response, curRsp);  
		return ret;
	}
	redis_common_config&  config = *pconfig;
	
	string ip;
	uint32_t port;
	
	struct timeval start;
    gettimeofday( &start, NULL );
	long current_timestamp = (((long)start.tv_sec)*1e5) + start.tv_usec;
	
	vector<string> key_list;
	key_list.push_back("DEL");
	key_list.push_back(request.data_key);
	
	TaskList task_list;
	int current_index = 0;

	for(vector<string>::iterator begin = config.zkname_list.begin(), end = config.zkname_list.end(); begin != end;++begin){
		MyRedisDMPtr redisPtr = creater<MyRedisDMPtr>()();
		redisPtr->int_data = current_index;
		get_name_result(*begin, ip, port);
		redisPtr->configCommand(key_list);
		redisPtr->setIP(ip,port);
		if(current_index < config.timeout_list.size()){
			redisPtr->setTimeOut(config.timeout_list[current_index]);
			DLOG_VALUE(config.timeout_list[current_index]);
		}
		
		++current_index;	
		task_list.push_back(redisPtr);
	}
	bool redis_result = false;
	int last_error = -1;
	string last_error_msg = "zk_name empty!";
	bool is_all_success = true;
	int current_retry = 0;
	while(! task_list.getlist().empty() && current_retry <= config.retry_times){
		TaskList new_task_list;
		ret = mt_access(task_list);
		if(ret != 0){
			ELOG << "mt_access error!ret:" << ret << endl;
			last_error = ret;
			is_all_success = false;
			current_retry++;
			continue;
		}
		vector<CommonTask> & res_task_list = task_list.getlist(); 
		for(size_t i = 0 ; i < res_task_list.size(); i++){
			MyRedisDMPtr setResPtr = MyRedisDMPtr::dynamicCast(res_task_list[i].basePtr);
			int index = setResPtr->int_data;
			last_error = setResPtr->getResult();
			string ip;
			uint32_t port;
			setResPtr->mConnInfo.getIP(ip, port);
			DLOG_VALUE(ip);
			DLOG_VALUE(port);
			DLOG_VALUE(setResPtr->getCostTime());
			Attr_API_Avg(config.monitor_config.monitor_delay_attr_list[index], setResPtr->getCostTime());
			if( last_error != 0){
				last_error_msg = "redis del error";
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				ELOG_VALUE(ip);
				ELOG_VALUE(port);
				ELOG_VALUE(setResPtr->getCostTime());
				ELOG_VALUE(setResPtr->mTimeOut);
				new_task_list.push_back(setResPtr);
				
				struct timeval start1;
				gettimeofday( &start1, NULL );
				long current_timestamp1 = (((long)start1.tv_sec)*1e5) + start1.tv_usec;
				ELOG_VALUE(current_timestamp1 - current_timestamp);
				
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
				is_all_success = false;
				continue;
			}
			last_error_msg = setResPtr->mResData[0].m_stringdata;
			if(setResPtr->mResData[0].m_type == REDIS_REPLY_INTEGER){
				
				int ret_code = setResPtr->mResData[0].m_intdata;
				switch(ret_code){
				case 0:
					last_error = 0;
					Attr_API(config.monitor_config.monitor_success_attr_list[index],1);
					break;
				case 1:
					last_error = KEY_NOT_FOUND;
					ELOG_VALUE(last_error);
					ELOG_VALUE(last_error_msg);
					Attr_API(config.monitor_config.monitor_success_attr_list[index],1);
					break;
				default:
					last_error = REDIS_CMD_ERROR;
					ELOG_VALUE(last_error);
					ELOG_VALUE(last_error_msg);
					Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
					break;
				}
				is_all_success = true;
			}
			
			else{
				last_error = REDIS_CMD_ERROR;
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
				is_all_success = false;
			}
			
			
		}
		vector<CommonTask> & res_new_task_list = new_task_list.getlist(); 
		res_task_list.assign(res_new_task_list.begin(),res_new_task_list.end());
		res_new_task_list.clear();
		//task_list = new_task_list;
		//--config.retry_times;
		++current_retry;
		//res_task_list.clear();
	}
	
	if(redis_result && is_all_success){
		response.ret = 0;
		response.msg="OK";
	}
	else{
		response.ret = last_error;
		response.msg = last_error_msg;
	}
	
	ret = jcePack<redis_del_resp>(response, curRsp);  
	
	if(response.ret == 0 ){
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_DEL, response.ret);
	}
	else{
		int keyoff = atoi(config_key.c_str());
		int keygen = keyoff > 0 ? (keyoff - 79302) * 1e5 + response.ret : -(keyoff * 1e5) + response.ret;
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_DEL, keygen);
	}
	return ret;
}



