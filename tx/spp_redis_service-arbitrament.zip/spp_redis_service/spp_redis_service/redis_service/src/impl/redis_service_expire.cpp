#include  "redis_service_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "Attr_API.h"

int redis_service_expire(const redis_common_config& config, const string& key, long seconds){
	TaskList task_list;
	vector<string> key_list;
	key_list.push_back("EXPIRE");
	key_list.push_back(key);
	
	char buf[32];
	snprintf(buf, 32, "%ld", seconds);
	key_list.push_back(buf);
	string ip;
	uint32_t port;
	int current_index = 0;
	for(vector<string>::const_iterator begin = config.zkname_list.begin(), end = config.zkname_list.end(); begin != end;++begin){
		MyRedisDMPtr redisPtr = creater<MyRedisDMPtr>()();
		redisPtr->int_data = current_index++;
		get_name_result(*begin, ip, port);
		redisPtr->configCommand(key_list);
		
		redisPtr->setIP(ip,port);	
		task_list.push_back(redisPtr);
	}
	
	int ret = mt_access(task_list);
	return ret;
}

