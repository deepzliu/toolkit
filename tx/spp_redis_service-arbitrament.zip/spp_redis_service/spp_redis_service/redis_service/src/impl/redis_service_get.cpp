
#include  "redis_service_msg.h"
#include "redis_data_set.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "Attr_API.h"

int redis_service_get(spp_msg* curMsg,const string & curReq, string & curRsp)
{
	mcall reporter;
    redis_service_msg * msg = (redis_service_msg *) curMsg;
	
    redis_get_req request;
    redis_get_resp response;
	DLOG<<"redis_service_get" << endl;
	int ret = jceUnPack<>(curReq, request);
    if(ret < 0){
		ELOG << "jceUnPack Error,ret:" << ret << std::endl;
        return ret;
	}
	request.display(DLOG);
	const string& config_key = request.config_key;

	redis_service_error result; 
	redis_common_config*  pconfig = redis_service_msg::getRedisConfig(config_key, result);
	if(result != redis_service::OK){
		response.ret = (int)result;
		response.msg = "Basic config information not found!";
		ELOG_VALUE(response.ret);
		ELOG_VALUE(response.msg);
		ret = jcePack<redis_get_resp>(response, curRsp);  
		return ret;
	}
	redis_common_config&  config = *pconfig;
	
	string ip;
	uint32_t port;
	
	struct timeval start;
    gettimeofday( &start, NULL );
	long current_timestamp = (((long)start.tv_sec)*1e5) + start.tv_usec;

	vector<string> key_list;
	key_list.push_back("GET");
	key_list.push_back(request.data_key);
	
	TaskList task_list;
	int current_index = 0;

	for(vector<string>::iterator begin = config.zkname_list.begin(), end = config.zkname_list.end(); begin != end;++begin){
		MyRedisDMPtr redisPtr = creater<MyRedisDMPtr>()();
		redisPtr->int_data = current_index;
		get_name_result(*begin, ip, port);
		redisPtr->configCommand(key_list);

		redisPtr->setIP(ip,port);
		redisPtr->initModCall(210101026,110302194,210101026,110311602);
		if(current_index < config.timeout_list.size()){
			redisPtr->setTimeOut(config.timeout_list[current_index]);
			DLOG_VALUE(config.timeout_list[current_index]);
		}
		++current_index;	
		task_list.push_back(redisPtr);
	}
	bool redis_result = false;
	int last_error = -1;
	int current_retry = 0;
	string last_error_msg = "zk_name empty!";
	vector<redis_data::redis_set_data> values;
	
	while(! task_list.getlist().empty() && current_retry <= config.retry_times){
		TaskList new_task_list;
		ret = mt_access(task_list);
		if(ret != 0){
			ELOG << "mt_access error!ret:" << ret << endl;
			last_error = ret;
			++current_retry;
			//continue;
		}
		vector<CommonTask> & res_task_list = task_list.getlist(); 
		for(size_t i = 0 ; i < res_task_list.size(); i++){
			MyRedisDMPtr getResPtr = MyRedisDMPtr::dynamicCast(res_task_list[i].basePtr);
			last_error = getResPtr->getResult();
			int index = getResPtr->int_data;
			string ip;
			uint32_t port;
			getResPtr->mConnInfo.getIP(ip, port);
			DLOG_VALUE(ip);
			DLOG_VALUE(port);
			DLOG_VALUE(getResPtr->getCostTime());
			getResPtr->endModCall(last_error);
			Attr_API_Avg(config.monitor_config.monitor_delay_attr_list[index], getResPtr->getCostTime());
			if( last_error != 0){
				DLOG_VALUE(1);
				last_error_msg = "redis get error";
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				ELOG_VALUE(ip);
				ELOG_VALUE(port);
				ELOG_VALUE(getResPtr->getCostTime());
				ELOG_VALUE(getResPtr->mTimeOut);
				new_task_list.push_back(getResPtr);
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);

				struct timeval start1;
				gettimeofday( &start1, NULL );
				long current_timestamp1 = (((long)start1.tv_sec)*1e5) + start1.tv_usec;
				ELOG_VALUE(current_timestamp1 - current_timestamp);
				continue;
			}
			
			if(getResPtr->mResData[0].m_type == REDIS_REPLY_ERROR){
				DLOG_VALUE(2);
				last_error_msg = getResPtr->mResData[0].m_stringdata;
				last_error = REDIS_CMD_ERROR;
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				ELOG_VALUE(ip);
				ELOG_VALUE(port);
				ELOG_VALUE(getResPtr->getCostTime());
				new_task_list.push_back(getResPtr);
				
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
				
				continue;
			}
			
			if( getResPtr->mResData[0].m_type == REDIS_REPLY_STRING){
				DLOG_VALUE(3);
				redis_result = true;
				const string& get_value = getResPtr->mResData[0].getStrValue();
				redis_data::redis_set_data jce_value;
				int ret = jceUnPack<>(get_value, jce_value);
				if(ret != 0){
					ELOG_VALUE(ret);
					last_error_msg = "Invalid redis data! Maybe not set according to redis_service!";
					continue;
				}
				Attr_API(config.monitor_config.monitor_success_attr_list[index],1);
				values.push_back(jce_value);
				jce_value.display(DLOG);
			}
			
			if( getResPtr->mResData[0].m_type == REDIS_REPLY_NIL){
				DLOG_VALUE(31);
				//redis_result = true;
				last_error_msg = "KEY_NOT_FOUND";
				last_error = KEY_NOT_FOUND;
				DLOG_VALUE(last_error);
				DLOG_VALUE(last_error_msg);
				DLOG_VALUE(ip);
				DLOG_VALUE(port);
				DLOG_VALUE(getResPtr->getCostTime());
				
			}

			DLOG_VALUE(getResPtr->mResData[0].m_type);
			DLOG_VALUE(4);
		}
		vector<CommonTask> & res_new_task_list = new_task_list.getlist(); 
		res_task_list.assign(res_new_task_list.begin(),res_new_task_list.end());
		res_new_task_list.clear();
		++current_retry;
	}
	DLOG_VALUE(values.size());
	DLOG_VALUE(redis_result);
	if(redis_result){
		const redis_data::redis_set_data* data_result = NULL;
		if(config.redis_judge_type_list.empty()){
			ELOG << "empty redis_judge_type_list! use NEWEST_BEST policy" << endl;
			config.redis_judge_type_list.push_back(NEWEST_BEST);
		}
		redis_judge_policy judge_result = redis_service_judge(values,  data_result, config.redis_judge_type_list);
		
		if(judge_result == JUDGE_FAILED || data_result == NULL){
			ELOG_VALUE(judge_result);
			response.ret = REDIS_JUDGE_FAILED;
			response.msg = "JUDGE_FAILED";
		}
		else{
			response.ret = 0;
			response.msg = "OK";
			response.read_response.judge_policy = judge_result;
			response.read_response.time_stamp = data_result->head.current_timestamp;
			response.read_response.judge_intdata = data_result->head.judge_intdata;
			response.read_response.judge_bytedata = data_result->head.judge_bytedata;
			response.data_value = data_result->data_value;
			DLOG_VALUE(data_result->head.current_timestamp);
			DLOG_VALUE(data_result->head.judge_intdata);
			DLOG_VALUE(data_result->head.judge_bytedata);
		}
	}
	else{
		response.ret = last_error;
		response.msg = last_error_msg;
	}

	ret = jcePack<redis_get_resp>(response, curRsp);  
	if(response.ret == 0 ){
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_GET, response.ret);
	}
	else{
		int keyoff = atoi(config_key.c_str());
		int keygen = keyoff > 0 ? (keyoff - 79302) * 1e5 + response.ret : -(keyoff * 1e5) + response.ret;
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_GET, keygen);
	}
	
	return ret;
}

