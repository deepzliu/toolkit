#include  "redis_service_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "Attr_API.h"
#include "redis_data_set.h"

int redis_service_set(spp_msg* curMsg,const string & curReq, string & curRsp)
{
	mcall reporter;
    redis_service_msg * msg = (redis_service_msg *) curMsg;
	
    redis_set_req request;
    redis_set_resp response;
	DLOG<<"redis_service_set" << endl;
	int ret = jceUnPack<>(curReq, request);
    if(ret < 0){
		ELOG << "jceUnPack Error,ret:" << ret << std::endl;
        return ret;
	}
	request.display(DLOG);
	const string& config_key = request.config_key;
	
	redis_service_error result; 
	redis_common_config*  pconfig = redis_service_msg::getRedisConfig(config_key, result);
	if(result != redis_service::OK){
		response.ret = (int)result;
		response.msg = "Basic config information not found!";
		ELOG_VALUE(response.ret);
		ELOG_VALUE(response.msg);
		ret = jcePack<redis_set_resp>(response, curRsp);  
		return ret;
	}
	redis_common_config&  config = *pconfig;
	
	string ip;
	uint32_t port;
	
	struct timeval start;
    gettimeofday( &start, NULL );
	long current_timestamp = (((long)start.tv_sec)*1e6) + start.tv_usec;
	
	redis_data::redis_set_data value;
	value.head.current_timestamp = current_timestamp;
	value.data_value = request.data_value;

	vector<redis_judge_policy>::iterator begin = config.redis_judge_type_list.begin(), end = config.redis_judge_type_list.end();
	
	//if(std::find(begin, end, INTDATA_GREATER_BETTER) != end || std::find(begin, end, INTDATA_SMALLER_BETTER) != end ){
	value.head.judge_intdata = request.write_request.judge_intdata;
	//}

	//if(std::find(begin, end, BYTEDATA_GREATER_BETTER) != end || std::find(begin, end, BYTEDATA_SMALLER_BETTER) != end ){
	value.head.judge_bytedata = request.write_request.judge_bytedata;
	//}
	
	value.display(DLOG);
	string realvalue;
	jcePack<redis_data::redis_set_data>(value, realvalue);
	
	vector<string> key_list;
	key_list.push_back("SET");
	key_list.push_back(request.data_key);
	key_list.push_back(realvalue);
	
	TaskList task_list;
	int current_index = 0;

	for(vector<string>::iterator begin = config.zkname_list.begin(), end = config.zkname_list.end(); begin != end;++begin){
		MyRedisDMPtr redisPtr = creater<MyRedisDMPtr>()();
		redisPtr->int_data = current_index;
		get_name_result(*begin, ip, port);
		redisPtr->configCommand(key_list);
		
		redisPtr->setIP(ip,port);
		if(current_index < config.timeout_list.size()){
			redisPtr->setTimeOut(config.timeout_list[current_index]);
			DLOG_VALUE(config.timeout_list[current_index]);
		}
		
		++current_index;	
		task_list.push_back(redisPtr);
	}
	bool redis_result = false;
	int last_error = -1;
	string last_error_msg = "zk_name empty!";
	response.write_response.is_all_success = 1;
	int current_retry = 0;
	while(! task_list.getlist().empty() && current_retry <= config.retry_times){
		TaskList new_task_list;
		ret = mt_access(task_list);
		if(ret != 0){
			ELOG << "mt_access error!ret:" << ret << endl;
			last_error = ret;
			current_retry++;
			continue;
		}
		vector<CommonTask> & res_task_list = task_list.getlist(); 
		for(size_t i = 0 ; i < res_task_list.size(); i++){
			MyRedisDMPtr setResPtr = MyRedisDMPtr::dynamicCast(res_task_list[i].basePtr);
			int index = setResPtr->int_data;
			last_error = setResPtr->getResult();
			string ip;
			uint32_t port;
			setResPtr->mConnInfo.getIP(ip, port);
			DLOG_VALUE(ip);
			DLOG_VALUE(port);
			DLOG_VALUE(setResPtr->getCostTime());
			Attr_API_Avg(config.monitor_config.monitor_delay_attr_list[index], setResPtr->getCostTime());
			if( last_error != 0){
				last_error_msg = "redis set error";
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				ELOG_VALUE(ip);
				ELOG_VALUE(port);
				ELOG_VALUE(setResPtr->getCostTime());
				ELOG_VALUE(setResPtr->mTimeOut);
				new_task_list.push_back(setResPtr);
				
				struct timeval start1;
				gettimeofday( &start1, NULL );
				long current_timestamp1 = (((long)start1.tv_sec)*1e5) + start1.tv_usec;
				ELOG_VALUE(current_timestamp1 - current_timestamp);
				
				if(current_retry == config.retry_times){
					response.write_response.is_all_success = 0;
				}
				
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
				
				continue;
			}
			
			if(setResPtr->mResData[0].m_type == REDIS_REPLY_ERROR){
				last_error_msg = setResPtr->mResData[0].m_stringdata;
				last_error = REDIS_REPLY_ERROR;
				ELOG_VALUE(last_error);
				ELOG_VALUE(last_error_msg);
				ELOG_VALUE(ip);
				ELOG_VALUE(port);
				ELOG_VALUE(setResPtr->getCostTime());
				new_task_list.push_back(setResPtr);
				if(current_retry == config.retry_times){
					response.write_response.is_all_success = 0;
				}
				
				Attr_API(config.monitor_config.monitor_error_attr_list[index],1);
				
				continue;
			}
			
			
			
			if( setResPtr->mResData[0].m_type == REDIS_REPLY_STATUS){
				redis_result = true;
			}
			
			Attr_API(config.monitor_config.monitor_success_attr_list[index],1);
			
		}
		vector<CommonTask> & res_new_task_list = new_task_list.getlist(); 
		res_task_list.assign(res_new_task_list.begin(),res_new_task_list.end());
		res_new_task_list.clear();
		//task_list = new_task_list;
		//--config.retry_times;
		++current_retry;
		//res_task_list.clear();
	}
	
	if(redis_result){
		response.ret = 0;
		response.msg="OK";
	}
	else{
		response.ret = last_error;
		response.msg = last_error_msg;
	}
	//RedisPtr->endPasModCall(0,0,REDIS_MODULE,INTERFACE_SET,response.ret  ,spp_msg->mRemoteIP);
	
	response.write_response.time_stamp = current_timestamp;
	DLOG_VALUE(current_timestamp);
	ret = jcePack<redis_set_resp>(response, curRsp);  
	
	if(request.write_request.key_expired_seconds != 0){
		curMsg->process_pack(curRsp);
		curMsg->mNoResponse = true;
		redis_service_expire(config, request.data_key, request.write_request.key_expired_seconds);
	}
	if(response.ret == 0){
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_SET, response.ret);
	}
	else{
		int keyoff = atoi(config_key.c_str());
		int keygen = keyoff > 0 ? (keyoff - 79302) * 1e5 + response.ret : -(keyoff * 1e5) + response.ret;
		reporter.report(curMsg->mRemoteIP, REDIS_MODULE, INTERFACE_SET, keygen);
	}
	return ret;
}



