#include "redis_service_msg.h"
#include "mt_access.h"
#include "mt_access_ex.h"
#include "local_logger.h"
#include "remote_logger.h"

#include "Attr_API.h"

CREATE_MSG(redis_service_msg)


extern int mt_g_max_anti_snow;

using namespace redis_service;

extern int redis_service_del(spp_msg* curMsg,const string & curReq, string & curRsp);
extern int redis_service_get(spp_msg* curMsg,const string & curReq, string & curRsp);
extern int redis_service_set(spp_msg* curMsg,const string & curReq, string & curRsp);

int mt_init(const char * etc)
{
    /*
   common logger
   example config file: base.ini
   [LOG_CONFIG]
   level=3
    */

    MyConfigFile cCBaseIni;
	cCBaseIni.ParseFile(etc);

	ELOG << "init etc:" << etc << std::endl;
	
	int iRet = 0;
	redis_service_msg::initConfig(cCBaseIni);

    MODCALL_INIT();
	ELOG << "init succeed:"  << std::endl;
	mt_g_max_anti_snow = 35000;
	BaseFunctor myFunctor_del(CMD_DEL,&redis_service_del);
	BaseFunctor myFunctor_get(CMD_GET,&redis_service_get);
	BaseFunctor myFunctor_get1(CMD_GET_OLD,&redis_service_get);
	BaseFunctor myFunctor_set(CMD_SET,&redis_service_set);
	BaseFunctor myFunctor_set2(CMD_SET_OLD,&redis_service_set);
	return 0; 
}

string redis_service_msg::redis_config_file;
MyConfigFile *redis_service_msg::redis_config = NULL;
int redis_service_msg::redis_config_refresh_time;
time_t redis_service_msg::redis_config_last_loading_time;
map<int, redis_common_config*> redis_service_msg::config_cache; 
map<string, read_cache_config> redis_service_msg::readcache_cache;

static map<string, pair<string, uint32_t> > zk_name_result_cache;
static time_t last_update_name_time = 0;

int get_name_result(const string& name, string& ip, uint32_t &port){
	time_t current_time = time(NULL);
	if(current_time - last_update_name_time > 1){
		last_update_name_time = current_time;
		zk_name_result_cache.clear();
	}
	 map<string, pair<string, uint32_t> >::iterator it = zk_name_result_cache.find(name);
	if( it != zk_name_result_cache.end()){
		ip = it->second.first;
		port = it->second.second;
	}
	else{
		int iRet = getHostByZkName(name, ip, port);
		if(iRet < 0)
		{
			ELOG << "get redis host by zkname error" << endl;
			return REDIS_GET_HOST_ERROR;
		}
		
		zk_name_result_cache[name] = (make_pair(ip, port));
		
	}
	return 0;
}

//#include "redis_service_judge.cpp"
//#include "redis_service_set.cpp"
//#include "redis_service_get.cpp"
//BaseFunctor myFunctor_set(CMD_SET,&redis_service_set);
//BaseFunctor myFunctor_get(CMD_GET,&redis_service_get);





