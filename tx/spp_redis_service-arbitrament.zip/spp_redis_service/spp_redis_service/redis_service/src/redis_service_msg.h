#ifndef _BASE_SVR_MSG_H_
#define _BASE_SVR_MSG_H_

#define private protected
#include "mt_spp_msg.h"


#include "bossapi.h"

#include "redis_service.h"
#include "config.h"
#include "local_logger.h"
#include "remote_logger.h"
#include "redis_config.h"
#include "redis_cmd_base.h"
#include "mt_access_redis.h"

using namespace redis_service;

#undef private

#define DLOG_VALUE(x) DLOG << #x ":" << x << endl
#define ELOG_VALUE(x) ELOG << #x ":" << x << endl

class MyConfigFile : public CConfigFile{
public:
	
	string GetConfValue(const string& szSection,const string&  szName,const char * szDefaultValue)
	{
		const string & key = szSection + '.' + szName;
		const string & value = m_ConfigMap[key];
		DLOG_VALUE(key);
		if(value.empty())
		{
		   return szDefaultValue;
		}
		else
		{
			return value;
		}

		return "";
	}
	
	
	template<typename T>
	T GetConfValue(const string&  szSection,const string&  szName,const T& szDefaultValue)
	{
		const string & key = szSection + '.' + szName;
		const string & value = m_ConfigMap[key];
		DLOG_VALUE(key);
		if(value.empty())
		{
		   return szDefaultValue;
		}
		else
		{
			return atoll(value.c_str());
		}
		return T(0);
	}
};

using namespace redis_service;
using namespace redis_config;
class redis_service_msg : public spp_msg
{
public :
	
	
    static string redis_config_file;
	static MyConfigFile* redis_config;
	static time_t redis_config_last_loading_time;
	static int redis_config_refresh_time;
	
	static map<int, redis_common_config*> config_cache;
	static map<string, read_cache_config> readcache_cache;
	
	static void initConfig(MyConfigFile& cCBaseIni){
		redis_config_file = cCBaseIni.GetConfValue("CONFIG", "redis_config_file", "../client/redis_service/conf/redis_config_file.ini");
		redis_config_refresh_time = cCBaseIni.GetConfValue("CONFIG", "redis_config_refresh_time", 300);
		initRedisConfig();
	}

	static void initRedisConfig(){
		//time_t current_time = time(NULL);
		//if(current_time - redis_config_last_loading_time >= redis_config_refresh_time){
		//	delete redis_config;
			redis_config = new MyConfigFile();
			int result = redis_config->ParseFile(redis_config_file.c_str());
			DLOG_VALUE(result);
			DLOG_VALUE(redis_config_file);
		//	redis_config_last_loading_time = current_time;
		//	config_cache.clear();
		//}
	}
	/*static void initRedisConfig(){
		time_t current_time = time(NULL);
		if(redis_config == NULL){
			redis_config = new MyConfigFile();
			int result = redis_config->ParseFile(redis_config_file.c_str());
			DLOG_VALUE(result);
			DLOG_VALUE(redis_config_file);
			redis_config_last_loading_time = current_time;
			config_cache.clear();
		}
	}*/
	
	
	static redis_service::redis_service_error fillRedisConfig(const string& config_key_infile, redis_common_config& config){
		if(!config_key_infile.empty()){
			//initRedisConfig();
			//if(config_cache.find(config_key_infile) != config_cache.end()){
			//	config = config_cache[config_key_infile];
			//	return redis_service::OK;
			//}

			const char* config_key = config_key_infile.c_str();
			const char* zkname_pattern = "zkname_%d";
			for(int i = 0; true; ++i){
				char  buff[32] = {0};
				snprintf(buff, 32, zkname_pattern, i);
			    const string& zkname = redis_config->GetConfValue(config_key, buff, "");
				DLOG_VALUE(config_key);
				DLOG_VALUE(buff);
				if(zkname.empty()){
					break;
				}
				DLOG_VALUE(zkname);
				config.zkname_list.push_back(zkname);
			}

			int redis_count = config.zkname_list.size();
			if(redis_count == 0){
				ELOG << "redis name empty!" << endl;
				return redis_service::NO_REDIS_NAME ;
			}

			const char* monitor_success_attr_pattern = "monitor_success_attr_%d";
			for(int i = 0; true; ++i){
				char  buff[32] = {0};
				snprintf(buff, 32, monitor_success_attr_pattern, i);
			    const int monitor_success_attr_id = redis_config->GetConfValue(config_key, buff, 0);
				if(monitor_success_attr_id == 0){
					break;
				}
				DLOG_VALUE(monitor_success_attr_id);
				config.monitor_config.monitor_success_attr_list.push_back(monitor_success_attr_id);
			}

			if(config.monitor_config.monitor_success_attr_list.size() != redis_count){
				ELOG << config.monitor_config.monitor_success_attr_list.size() <<"!=" <<redis_count
				<<"count of monitor_success_attr  != redis_count" << endl;
			}

			const char* monitor_error_attr_pattern = "monitor_error_attr_%d";
			for(int i = 0; true; ++i){
				char  buff[32] = {0};
				snprintf(buff, 32, monitor_error_attr_pattern, i);
			    const int monitor_error_attr_id = redis_config->GetConfValue(config_key, buff, 0);
				if(monitor_error_attr_id == 0){
					break;
				}
				DLOG_VALUE(monitor_error_attr_id);
				config.monitor_config.monitor_error_attr_list.push_back(monitor_error_attr_id);
			}

			if(config.monitor_config.monitor_error_attr_list.size() != redis_count){
				ELOG << config.monitor_config.monitor_error_attr_list.size() <<"!=" <<redis_count
				<<"count of monitor_error_attr != redis_count" << endl;
			}

			const char* monitor_delay_attr_pattern = "monitor_delay_attr_%d";
			for(int i = 0; true; ++i){
				char  buff[32] = {0};
				snprintf(buff, 32, monitor_delay_attr_pattern, i);
			    const int monitor_delay_attr_id = redis_config->GetConfValue(config_key, buff, 0);
				if(monitor_delay_attr_id == 0){
					break;
				}
				DLOG_VALUE(monitor_delay_attr_id);
				config.monitor_config.monitor_delay_attr_list.push_back(monitor_delay_attr_id);
			}
			if(config.monitor_config.monitor_delay_attr_list.size() != redis_count){
				ELOG << config.monitor_config.monitor_delay_attr_list.size() <<"!=" <<redis_count
				<<"count of monitor_delay_attr != redis_count" << endl;
			}

			int common_timeout = redis_config->GetConfValue(config_key, "timeout", 0);
			if(common_timeout > 0){
				for(int i = 0; i < redis_count; ++i){
					config.timeout_list.push_back(common_timeout);
				}
			}
			else{
				const char* timeout_pattern = "timeout_%d";
				for(int i = 0; true; ++i){
					char  buff[32] = {0};
					snprintf(buff, 32, timeout_pattern, i);
					const int timeout = redis_config->GetConfValue(config_key, buff, 0);
					if(timeout == 0){
						break;
					}
					DLOG_VALUE(timeout);
					config.timeout_list.push_back(timeout);
				}
				if(config.monitor_config.monitor_delay_attr_list.size() != redis_count){
					ELOG << config.monitor_config.monitor_delay_attr_list.size() <<"!=" <<redis_count
					<<"count of time_out != redis_count" << endl;
				}
			}

			const char* judge_policy_pattern = "judge_policy_%d";
			for(int i = 0; true; ++i){
				char  buff[32] = {0};
				snprintf(buff, 32, judge_policy_pattern, i);
			    const string& judge_policy = redis_config->GetConfValue(config_key, buff, "");
				if(judge_policy.empty()){
					break;
				}
				DLOG_VALUE(judge_policy);
				config.redis_judge_type_list.push_back((redis_judge_policy)(atoi(judge_policy.c_str())));
			}
			config.retry_times = redis_config->GetConfValue(config_key, "retry_times", 0);
			//config_cache[config_key_infile] = config;
			return redis_service::OK;
		}
		ELOG << "config_key empty!" << endl;
		return redis_service::NO_CONFIG_KEY;
	}
	
	static redis_service::redis_service_error fillRedisConfig(const string& config_key_infile, redis_write_config& config){
		redis_service_error result = fillRedisConfig(config_key_infile, (redis_common_config&)config);
		DLOG_VALUE(config_key_infile);
		if(result != redis_service::OK){
			return result;
		}
		const char* config_key = config_key_infile.c_str();
		config.require_judge_result = redis_config->GetConfValue(config_key, "require_judge_result", 0);
		return result;
	}
	
	
	static redis_service::redis_service_error fillReadCacheConfig(const string& config_key_infile, redis_read_config& config){
		if(readcache_cache.find(config_key_infile) != readcache_cache.end()){
			config.cache_config = readcache_cache[config_key_infile];
			return redis_service::OK;
		}
		const char* config_key = config_key_infile.c_str();
		config.cache_config.use_cache = redis_config->GetConfValue(config_key, "use_cache", 0);
		if(config.cache_config.use_cache != 0){
			read_cache_config& cache_config = config.cache_config;
			cache_config.cache_key =  redis_config->GetConfValue(config_key, "cache_key", "");
			cache_config.max_key_length = redis_config->GetConfValue(config_key, "max_key_length", 0);
			cache_config.max_value_length = redis_config->GetConfValue(config_key, "max_value_length", 0);
			cache_config.cache_size = redis_config->GetConfValue(config_key, "cache_size", 0);
			cache_config.col_count = redis_config->GetConfValue(config_key, "col_count", 0);
			cache_config.row_count = redis_config->GetConfValue(config_key, "row_count", 0);
			cache_config.expire_time = redis_config->GetConfValue(config_key, "expire_time", 0);
			DLOG_VALUE (cache_config.cache_key);
			DLOG_VALUE (cache_config.max_key_length);
			DLOG_VALUE ( cache_config.max_value_length);
			DLOG_VALUE ( cache_config.cache_size);
			DLOG_VALUE ( cache_config.col_count);
			DLOG_VALUE ( cache_config.row_count);
			DLOG_VALUE ( cache_config.expire_time);

			if(cache_config.max_key_length <= 0 || cache_config.max_value_length <= 0 || cache_config.cache_size <= 0 || cache_config.col_count <= 0 || cache_config.row_count <= 0 ||
				cache_config.cache_key.empty()){
				return redis_service::BAD_CONFIG_INPUT;
			}
		}
		
		return redis_service::OK;
	}
	
	static redis_service::redis_service_error fillRedisConfig(const string& config_key_infile, redis_read_config& config){
		redis_service_error result = fillRedisConfig(config_key_infile, (redis_common_config&)config);
		if(result != redis_service::OK){
			return result;
		}
		
		result = fillReadCacheConfig(config_key_infile, config);
		if(result != redis_service::OK){
			return result;
		}
		const char* config_key = config_key_infile.c_str();
		config.redis_mismatched_attr = redis_config->GetConfValue(config_key, "redis_mismatched_attr", 0);
		config.redis_mismatched_cmd = redis_config->GetConfValue(config_key, "redis_mismatched_cmd", 0);

		return result;
	}
	
	static redis_common_config* getRedisConfig(const string& config_key_infile, redis_service::redis_service_error& err_result){
		redis_common_config* result = NULL;
		if(!config_key_infile.empty()){
			//initRedisConfig();
			int key = atoi(config_key_infile.c_str());
			
			if(config_cache.find(key) != config_cache.end()){
				result = config_cache[key];
				err_result = OK;
				return result;
			}
			result = new redis_common_config();
			redis_service_error err = fillRedisConfig(config_key_infile, *result);
			if(err != redis_service::OK){
				delete result;
				err_result = err;
				return NULL;
			}
			
			/*result = fillReadCacheConfig(config_key_infile, config);
			if(result != redis_service::OK){
				return result;
			}*/
			err_result = OK;
			config_cache[key] = result;
			//result->redis_mismatched_attr = redis_config.GetIniInt(config_key, "redis_mismatched_attr", 0);
			//result->redis_mismatched_cmd = redis_config.GetIniInt(config_key, "redis_mismatched_cmd", 0);
			//result->monitor_ignore_value_empty = redis_config.GetIniInt(config_key, "monitor_ignore_value_empty", 0);
			return result;
		}
		err_result = NO_CONFIG_KEY;
		return result;
		
	}
};

extern int get_name_result(const string& name, string& ip, uint32_t &port);

struct MyRedisDataModel : public RedisDataModel{
	int int_data;
};
typedef taf::TC_AutoPtr<MyRedisDataModel> MyRedisDMPtr;

template<class T>
redis_judge_policy redis_service_judge_NEWEST_BEST(const vector<T> & values_list, const T* &judge_result){
	redis_judge_policy result = NO_JUDGE;
	DLOG<<("redis_service_judge_NEWEST_BEST!");
	const T* judge_result_ptr = NULL;
	long newest = 0;
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		long timestamp = begin->head.current_timestamp;
		if(timestamp > newest){
			newest = timestamp;
			judge_result_ptr = &(*begin);
			result = NEWEST_BEST;
			DLOG<<("got!");
		}
	}
	if(judge_result_ptr != NULL){
		judge_result = judge_result_ptr;
	}
	return result;
}


template<class K, class V>
bool operator < (const pair<long, pair<K,V> > & left, const pair<long, pair<K,V> > & right) {
	return left.second.first < right.second.first;
}

template<class T>
redis_judge_policy redis_service_judge_MAJORITY_LOGIC(const vector<T> & values_list,  const T* &judge_result){
	redis_judge_policy result = JUDGE_FAILED;
	const T* judge_result_ptr = NULL;
	map<long, pair<int, const T*> > counter;
	DLOG<<("redis_service_judge_MAJORITY_LOGIC!");
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		long timestamp = begin->head.current_timestamp;
		typename map<long, pair<int, const T*> >::iterator f = counter.find(timestamp);
		if(f == counter.end()){
			counter.insert(make_pair(timestamp, make_pair(0, &(*begin))));
		}
		else{
			++f->second.first;
		}
	}
	if(!counter.empty()){
		const T* judge_result_ptr1 = max_element(counter.begin(), counter.end())->second.second;
		const T* judge_result_ptr2 = max_element(counter.begin(), counter.end())->second.second;
		if(judge_result_ptr2 == judge_result_ptr1){
			judge_result_ptr = judge_result_ptr1;
			judge_result = judge_result_ptr;
			result = MAJORITY_LOGIC;
		}
	}
	return result;
}


		
template<class T>
redis_judge_policy redis_service_judge_INTDATA_GREATER_BETTER(const vector<T> &values_list,  const T* &judge_result){
	redis_judge_policy result = JUDGE_FAILED;
	const T* judge_result_ptr = NULL;
	const long* current_judgedata = NULL;
	DLOG<<("redis_service_judge_INTDATA_GREATER_BETTER!");
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		const long* judgedata = &(begin->head.judge_intdata);
		
		if(current_judgedata == NULL || *judgedata > *current_judgedata){
			judge_result_ptr = &(*begin);
			current_judgedata = judgedata;
			result = INTDATA_GREATER_BETTER;
		}
		else if(current_judgedata != NULL && (*judgedata == *current_judgedata && judge_result_ptr->head.current_timestamp !=  begin->head.current_timestamp)){
			judge_result_ptr = NULL; // 鎸佹湁绁ㄦ嵁鐩稿悓浣嗘暟鎹笉鍚岋紝鍚﹀畾浠讳綍涓�涓粨鏋溿��
		}
	}
	if(!judge_result_ptr == NULL){
		judge_result = judge_result_ptr;
	}
	return result;
}

template<class T>
redis_judge_policy redis_service_judge_BYTEDATA_GREATER_BETTER(const vector<T> &values_list,  const T* &judge_result){
	redis_judge_policy result = JUDGE_FAILED;
	const T* judge_result_ptr = NULL;
	const string* current_judgedata = NULL;
	DLOG<<("redis_service_judge_BYTEDATA_GREATER_BETTER!");
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		const string* judgedata = &(begin->head.judge_bytedata);
		
		if(current_judgedata == NULL || *judgedata > *current_judgedata){
			judge_result_ptr = &(*begin);
			current_judgedata = judgedata;
			result = BYTEDATA_GREATER_BETTER;
		}
		else if(current_judgedata != NULL && (*judgedata == *current_judgedata && judge_result_ptr->head.current_timestamp !=  begin->head.current_timestamp)){
			judge_result_ptr = NULL; // 鎸佹湁绁ㄦ嵁鐩稿悓浣嗘暟鎹笉鍚岋紝鍚﹀畾浠讳綍涓�涓粨鏋溿��
		}
	}
	if(!judge_result_ptr == NULL){
		judge_result = judge_result_ptr;
	}
	return result;
}

template<class T>
redis_judge_policy redis_service_judge_INTDATA_SMALLER_BETTER(const vector<T> &values_list,  const T* &judge_result){
	redis_judge_policy result = JUDGE_FAILED;
	const T* judge_result_ptr = NULL;
	const long* current_judgedata = NULL;
	DLOG<<("redis_service_judge_INTDATA_SMALLER_BETTER!");
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		const long* judgedata = &(begin->head.judge_intdata);
		
		if(current_judgedata == NULL || *judgedata < *current_judgedata){
			judge_result_ptr = &(*begin);
			current_judgedata = judgedata;
			DLOG_VALUE(*judgedata);
			result = INTDATA_SMALLER_BETTER;
		}
		else if(current_judgedata != NULL && (*judgedata == *current_judgedata && judge_result_ptr->head.current_timestamp !=  begin->head.current_timestamp)){
			judge_result_ptr = NULL; // 鎸佹湁绁ㄦ嵁鐩稿悓浣嗘暟鎹笉鍚岋紝鍚﹀畾浠讳綍涓�涓粨鏋溿��
			DLOG_VALUE(*current_judgedata);
			DLOG_VALUE(*judgedata);
			DLOG_VALUE(judge_result_ptr->head.current_timestamp);
			DLOG_VALUE(begin->head.current_timestamp);
		}
	}
	if(!judge_result_ptr == NULL){
		judge_result = judge_result_ptr;
	}
	return result;
}

template<class T>
redis_judge_policy redis_service_judge_BYTEDATA_SMALLER_BETTER(const vector<T> &values_list,  const T* &judge_result){
	redis_judge_policy result = JUDGE_FAILED;
	const T* judge_result_ptr = NULL;
	const string* current_judgedata = NULL;
	DLOG<<("redis_service_judge_BYTEDATA_SMALLER_BETTER!");
	for(typename vector<T>::const_iterator begin = values_list.begin(), end = values_list.end(); begin != end; ++begin){
		const string* judgedata = &(begin->head.judge_bytedata);
		
		if(current_judgedata == NULL || *judgedata < *current_judgedata){
			judge_result_ptr = &(*begin);
			current_judgedata = judgedata;
			DLOG_VALUE(*judgedata);
			result = BYTEDATA_SMALLER_BETTER;
		}
		else if(current_judgedata != NULL && (*judgedata == *current_judgedata && judge_result_ptr->head.current_timestamp !=  begin->head.current_timestamp)){
			judge_result_ptr = NULL; // 鎸佹湁绁ㄦ嵁鐩稿悓浣嗘暟鎹笉鍚岋紝鍚﹀畾浠讳綍涓�涓粨鏋溿��
			DLOG_VALUE(*current_judgedata);
			DLOG_VALUE(*judgedata);
			DLOG_VALUE(judge_result_ptr->head.current_timestamp);
			DLOG_VALUE(begin->head.current_timestamp);
		}
	}
	if(!judge_result_ptr == NULL){
		judge_result = judge_result_ptr;
	}
	return result;
}

template<class T>
redis_judge_policy redis_service_judge(const vector<T> & values_list,  const T* &judge_result, const vector<redis_judge_policy>& redis_judge_policy_list)
{
	redis_judge_policy result = JUDGE_FAILED;
	if(!values_list.empty()){
		for(vector<redis_judge_policy>::const_iterator begin = redis_judge_policy_list.begin(), end = redis_judge_policy_list.end(); begin != end; ++begin){
			DLOG_VALUE(*begin);
			switch(*begin){
				case NO_JUDGE:
					result = NO_JUDGE;
					break;
				case MAJORITY_LOGIC:
					result = redis_service_judge_MAJORITY_LOGIC(values_list, judge_result);
					break;
				case NEWEST_BEST:
					result = redis_service_judge_NEWEST_BEST(values_list, judge_result);
					break;
				case INTDATA_GREATER_BETTER:
					result = redis_service_judge_INTDATA_GREATER_BETTER(values_list, judge_result);
					break;
				case INTDATA_SMALLER_BETTER:
					result = redis_service_judge_INTDATA_SMALLER_BETTER(values_list, judge_result);
					break;
				case BYTEDATA_GREATER_BETTER:
					result = redis_service_judge_BYTEDATA_GREATER_BETTER(values_list, judge_result);
					break;
				case BYTEDATA_SMALLER_BETTER:
					result = redis_service_judge_BYTEDATA_SMALLER_BETTER(values_list, judge_result);
					break;
				default:
					break;
			}
			if(result != JUDGE_FAILED){
				break;
			}
		}
	}
	return result;
		
}

int redis_service_expire(const redis_common_config& config, const string& key, long seconds);

struct mcall{
	mcall(){
		mPassiveCaller.start();
	}
	void report(unsigned int ip, int moduleid, int cmdid, int ret){
		struct in_addr addr1;
		memcpy(&addr1, &ip, sizeof(ip));
		mPassiveCaller.end(0, 0, moduleid, cmdid, ret, inet_ntoa(addr1));
	}
	BossAPI::CModCallTimer mPassiveCaller;
};
#endif

