#include "func_factory.h"
#include "mt_access.h"
#include <sstream>
#include <stdlib.h>
#include "redis_service.h"
#include <iostream>
using namespace std;
using namespace redis_service;


typedef taf::TC_AutoPtr<JceTcpDataModel<redis_set_req,redis_set_resp> > SetPtr;
typedef taf::TC_AutoPtr<JceTcpDataModel<redis_get_req,redis_get_resp> > GetPtr;
typedef taf::TC_AutoPtr<JceTcpDataModel<redis_del_req,redis_del_resp> > DelPtr;

int testDoubleRedis(int argc, char *argv[])
{
    int ret = 0;

    TaskList tasklist;
	
    SetPtr setPtr = creater<SetPtr>()();
    setPtr->mReq.config_key = argv[1];
    setPtr->mReq.data_key = argv[2];
    setPtr->mReq.data_value = "config_test1";

    setPtr->setIP(argv[0],13830);
    //setPtr->setL5(529985, 65536);
	setPtr->setTimeOut(100);
    setPtr->mHeader.BasicInfo.Command = CMD_SET;

    tasklist.push_back(setPtr);
	
	ret = mt_access(tasklist);

    setPtr->mRsp.display(std::cout);
	tasklist.clear();
	GetPtr getPtr = creater<GetPtr>()();
    getPtr->mReq.config_key = argv[1];
    getPtr->mReq.data_key = argv[2];
   // getPtr->mReq.data_value= "config_test";
	//getPtr->setL5(529985, 65536);
    getPtr->setIP(argv[0],13830);
    getPtr->setTimeOut(100);
    getPtr->mHeader.BasicInfo.Command = CMD_GET;
    tasklist.push_back(getPtr);
	
	ret = mt_access(tasklist);

    getPtr->mRsp.display(std::cout);
    
    return ret;
}


int testtestDoubleRedisSet(int argc, char *argv[])
{
    int ret = 0;

    TaskList tasklist;

    SetPtr setPtr = creater<SetPtr>()();
    setPtr->mReq.config_key = argv[1];
    setPtr->mReq.data_key = argv[2];
    setPtr->mReq.data_value = "config_test";
	//setPtr->setL5(529985, 65536);
    setPtr->setIP(argv[0],13830);
    setPtr->setTimeOut(1000);
    setPtr->mHeader.BasicInfo.Command = CMD_SET;
    

    tasklist.push_back(setPtr);
	
	ret = mt_access(tasklist);

    setPtr->mRsp.display(std::cout);
    
    return ret;
}

int testtestDoubleRedisDel(int argc, char *argv[])
{
    int ret = 0;

    TaskList tasklist;

    DelPtr setPtr = creater<DelPtr>()();
    setPtr->mReq.config_key = argv[1];
    setPtr->mReq.data_key = argv[2];
    //setPtr->mReq.data_value = "config_test";
	//setPtr->setL5(529985, 65536);
    setPtr->setIP(argv[0],13830);
    setPtr->setTimeOut(1000);
    setPtr->mHeader.BasicInfo.Command = CMD_DEL;
    

    tasklist.push_back(setPtr);
	
	ret = mt_access(tasklist);

    setPtr->mRsp.display(std::cout);
    
    return ret;
}

int testDoubleRedisSet(int argc, char *argv[])
{
	if(argc < 2)
	{
		printf("usage:./unit_test testDoubleRedisSet ip port configkey data_key data_value\n");
		printf("usage:./unit_test testDoubleRedisSet 10.120.100.31 13830 79319  data_key data_value\n");
		printf("usage:./unit_test testDoubleRedisSet 9.66.104.13 13830 79319   data_key data_value\n");
		return -1;
	}
    int ret = 0;

    TaskList tasklist;

    SetPtr setPtr = creater<SetPtr>()();
    setPtr->mReq.config_key = argv[2];
    setPtr->mReq.data_key = argv[3];
    setPtr->mReq.data_value = argv[4];
	//setPtr->setL5(529985, 65536);
    setPtr->setIP(argv[0],atoi(argv[1]));
    setPtr->setTimeOut(100);
    setPtr->mHeader.BasicInfo.Command = CMD_SET;
    

    tasklist.push_back(setPtr);
	
	ret = mt_access(tasklist);

    setPtr->mRsp.display(std::cout);
    
    return ret;
}

int testDoubleRedisRead(int argc, char *argv[])
{
	if(argc < 2)
	{
		printf("usage:./unit_test testDoubleRedisRead ip port configkey data_key\n");
		printf("usage:./unit_test testDoubleRedisRead 10.120.100.31 13830 79319  data_key\n");
		printf("usage:./unit_test testDoubleRedisRead 9.66.104.13 13830 79319   data_key\n");
		return -1;
	}
    int ret = 0;

    TaskList tasklist;

	GetPtr getPtr = creater<GetPtr>()();
    getPtr->mReq.config_key = argv[2];
    getPtr->mReq.data_key = argv[3];
	
   // getPtr->mReq.data_value= "config_test";
	//getPtr->setL5(529985, 65536);
    getPtr->setIP(argv[0],atoi(argv[1]));
    getPtr->initModCall(210101026,110316015,210101026,110316016);
    getPtr->setTimeOut(100);
    getPtr->mHeader.BasicInfo.Command = CMD_GET;

    tasklist.push_back(getPtr);
	
	ret = mt_access(tasklist);
    getPtr->endModCall(ret);
    getPtr->mRsp.display(std::cout);
    
    return ret;
}

#include "func_factory.h"
#include "mt_access.h"
#include <fstream>

int redis(int argc, char *argv[])
{
    int ret = 0;
	if(argc < 2)
	{
		cout << "usage ./unit_test redis ${zkname} ${command}" << endl;
		return 0;
	}
	
    TaskList tasklist;

	RedisDMPtr redisPtr = creater<RedisDMPtr>()();
    redisPtr->setZkname(argv[0]);
    redisPtr->configCommand(argv[1]);
	
    tasklist.push_back(redisPtr);
    ret = mt_access(tasklist);
	
	vector<helloredis::DataUnit> &result = redisPtr->getResData();
	for(size_t i = 0; i < result.size(); i ++)
	{
		if(result[i].getType() == REDIS_REPLY_STRING)
		{
			cout << "\"" << result[i].getStrValue() << "\"" << endl;
		}
		else if(result[i].getType() == REDIS_REPLY_INTEGER)
		{
			cout << result[i].getIntValue() << endl;
		}
		else if(result[i].getType() == REDIS_REPLY_STATUS)
		{
			cout << "status:" << result[i].getIntValue() << endl;
		}
		else if(result[i].getType() == REDIS_REPLY_ERROR)
		{
			cout << "error:" << result[i].getIntValue() << endl;
		}
		else if(result[i].getType() == REDIS_REPLY_ARRAY)
		{
			cout << "array num:" << result[i].getIntValue() << endl;
		}
		else if(result[i].getType() == REDIS_REPLY_NIL)
		{
			cout << "null type!!" << endl;
		}
	}
	
    return ret;
}

int redis1(int argc, char *argv[])
{
     TaskList tasklist;

	GetPtr getPtr = creater<GetPtr>()();
    getPtr->mReq.config_key = argv[1];
    getPtr->mReq.data_key = argv[2];
	
   // getPtr->mReq.data_value= "config_test";
	//getPtr->setL5(529985, 65536);
    getPtr->setIP(argv[0],9999);
    getPtr->setTimeOut(100);
    getPtr->mHeader.BasicInfo.Command = 0x1;

    tasklist.push_back(getPtr);
	
	int ret = mt_access(tasklist);

    getPtr->mRsp.display(std::cout);  
	
    return 0;
}


int redis_test(int argc, char *argv[])
{
     TaskList tasklist;

	SetPtr getPtr = creater<SetPtr>()();
    getPtr->mReq.config_key = "79325";
    getPtr->mReq.data_key = "2335_hlw_payinfo_226069212_0_2njjhmf9tk6rzxx1";
	getPtr->mReq.write_request.key_expired_seconds = 3600*24;
    getPtr->mReq.data_value= "config_test123456789890";
	//getPtr->setL5(529985, 65536);
    getPtr->setIP("172.27.200.203",13830);
    getPtr->setTimeOut(100);
    getPtr->mHeader.BasicInfo.Command = 0x1;

    tasklist.push_back(getPtr);
	
	int ret = mt_access(tasklist);

    getPtr->mRsp.display(std::cout);  
	
    return 0;
}
REG_FUNC(redis_test);
REG_FUNC(redis1);
REG_FUNC(redis);
REG_FUNC(testDoubleRedisSet);
REG_FUNC(testDoubleRedisRead);
REG_FUNC(testDoubleRedis);
REG_FUNC(testtestDoubleRedisSet);
REG_FUNC(testtestDoubleRedisDel);
